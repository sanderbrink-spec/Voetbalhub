package nl.voetbalhub.app;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Html;
import android.text.TextUtils;
import android.util.Xml;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.*;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import org.xmlpull.v1.XmlPullParser;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {
    private static class Article {
        final String title, link, source, date, imageUrl;

        Article(String title, String link, String source, String date, String imageUrl) {
            this.title = title;
            this.link = link;
            this.source = source;
            this.date = date;
            this.imageUrl = imageUrl == null ? "" : imageUrl;
        }
    }

    private final ExecutorService executor = Executors.newFixedThreadPool(4);
    private final Handler main = new Handler(Looper.getMainLooper());
    private final List<Article> articles = new ArrayList<>();
    private final List<Article> shown = new ArrayList<>();
    private final String[] feedNames = {"VI", "VoetbalPrimeur", "VoetbalNieuws"};
    // Alleen feeds waarvan de uitgever publiek een RSS-feed aanbiedt voor het tonen van nieuwslinks.
    private final String[] feedUrls = {
            "https://www.vi.nl/feed/news.xml",
            "https://www.voetbalprimeur.nl/feed/news.xml",
            "https://www.voetbalnieuws.nl/feed/news.xml"
    };
    private String active = "Voor jou";
    private boolean loading = false;
    private boolean articleOpen = false;
    private WebView activeWebView;
    private FrameLayout content;
    private LinearLayout chips, nav;
    private SharedPreferences prefs;
    private final Runnable periodicRefresh = new Runnable() {
        @Override public void run() {
            refreshNews();
            main.postDelayed(this, 10 * 60 * 1000L);
        }
    };
    private long lastRefresh = 0L;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        content = findViewById(R.id.content);
        chips = findViewById(R.id.chips);
        nav = findViewById(R.id.nav);
        View header = findViewById(R.id.header);
        ViewCompat.setOnApplyWindowInsetsListener(header, (v, insets) -> {
            int top = insets.getInsets(WindowInsetsCompat.Type.statusBars()).top;
            v.setPadding(v.getPaddingLeft(), top, v.getPaddingRight(), v.getPaddingBottom());
            ViewGroup.LayoutParams lp = v.getLayoutParams();
            lp.height = dp(64) + top;
            v.setLayoutParams(lp);
            return insets;
        });
        ViewCompat.setOnApplyWindowInsetsListener(nav, (v, insets) -> {
            int bottom = insets.getInsets(WindowInsetsCompat.Type.navigationBars()).bottom;
            int extra = dp(10);
            v.setPadding(v.getPaddingLeft(), dp(4), v.getPaddingRight(), bottom + extra);
            ViewGroup.LayoutParams lp = v.getLayoutParams();
            lp.height = dp(76) + bottom;
            v.setLayoutParams(lp);
            return insets;
        });
        ViewCompat.requestApplyInsets(header);
        ViewCompat.requestApplyInsets(nav);
        prefs = getSharedPreferences("voethub", MODE_PRIVATE);
        lastRefresh = prefs.getLong("lastRefresh", 0L);
        loadCachedArticles();
        buildChips();
        buildNav();
        findViewById(R.id.search).setOnClickListener(v -> showSearch());
        findViewById(R.id.settings).setOnClickListener(v -> showSettings());
        showNews();
        refreshNews();
        main.postDelayed(periodicRefresh, 10 * 60 * 1000L);
        showIntro();
    }

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    private TextView tv(String text, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setIncludeFontPadding(false);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private void buildChips() {
        chips.removeAllViews();
        String[] labels = {"Voor jou", "Laatste nieuws", "Transfers", "Eredivisie", "Buitenland", "Video"};
        for (String label : labels) {
            TextView b = tv(label, 13, label.equals(active) ? C.BG : C.TEXT, false);
            b.setGravity(Gravity.CENTER);
            b.setPadding(dp(13), 0, dp(13), 0);
            b.setBackground(ContextCompat.getDrawable(this, label.equals(active) ? R.drawable.rounded_active : R.drawable.rounded_chip));
            b.setOnClickListener(v -> {
                active = label;
                buildChips();
                if (label.equals("Video")) showVideos(); else showNews();
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, dp(34));
            lp.setMargins(0, 0, dp(8), 0);
            chips.addView(b, lp);
        }
    }

    private void buildNav() {
        nav.removeAllViews();
        String[][] items = {{"⌂", "Nieuws"}, {"▣", "Uitslagen"}, {"◉", "Competities"}, {"★", "Favorieten"}, {"☰", "Meer"}};
        for (int i = 0; i < items.length; i++) {
            final String page = items[i][1];
            final int index = i;
            LinearLayout box = new LinearLayout(this);
            box.setOrientation(LinearLayout.VERTICAL);
            box.setGravity(Gravity.CENTER);
            box.setClickable(true);
            box.addView(tv(items[i][0], 21, index == 0 ? C.GREEN : C.MUTED, true), new LinearLayout.LayoutParams(-1, dp(28)));
            box.addView(tv(page, 10, index == 0 ? C.GREEN : C.MUTED, index == 0), new LinearLayout.LayoutParams(-1, dp(18)));
            box.setOnClickListener(v -> {
                switch (page) {
                    case "Nieuws": active = "Voor jou"; buildChips(); showNews(); break;
                    case "Uitslagen": showScores(); break;
                    case "Competities": showCompetitions(); break;
                    case "Favorieten": showFavorites(); break;
                    default: showMore();
                }
            });
            nav.addView(box, new LinearLayout.LayoutParams(0, -1, 1));
        }
    }

    private LinearLayout sectionHeader(String title, String action, final Runnable click) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(16), dp(10), dp(16), dp(10));
        row.addView(tv(title, 22, C.TEXT, true), new LinearLayout.LayoutParams(0, dp(40), 1));
        if (action != null) {
            TextView a = tv(action, 12, C.GREEN, true);
            a.setGravity(Gravity.CENTER);
            a.setOnClickListener(v -> { if (click != null) click.run(); });
            row.addView(a, new LinearLayout.LayoutParams(dp(90), dp(36)));
        }
        return row;
    }

    private LinearLayout sectionHeader(String title) { return sectionHeader(title, null, null); }

    private void showNews() {
        articleOpen = false;
        activeWebView = null;
        content.removeAllViews();
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.addView(sectionHeader("Laatste voetbalnieuws", "VERVERS", this::refreshNews));
        TextView status = tv(loading ? "Nieuws wordt bijgewerkt…" : "Live RSS  •  VI  •  VoetbalPrimeur  •  VoetbalNieuws" + (lastRefresh > 0 ? "  •  " + formatLastRefresh() : ""), 11, C.MUTED, false);
        status.setPadding(dp(16), 0, dp(16), dp(10));
        root.addView(status);
        ScrollView scroll = new ScrollView(this);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(16), 0, dp(16), dp(24));
        if (active.equals("Voor jou") || active.equals("Eredivisie")) {
            addEredivisieLiveBlock(list);
        }
        List<Article> filtered = filterArticles(active);
        shown.clear(); shown.addAll(filtered);
        if (filtered.isEmpty()) {
            list.addView(tv("Nog geen nieuws geladen. Tik op VERVERS.", 15, C.MUTED, false), new LinearLayout.LayoutParams(-1, dp(60)));
        } else {
            for (int i = 0; i < Math.min(30, filtered.size()); i++) addArticleCard(list, filtered.get(i), i == 0 && active.equals("Voor jou"));
        }
        scroll.addView(list);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        content.addView(root);
    }


    /** Toont actuele Eredivisie-wedstrijden vanuit een experimentele ESPN-scoreboardfeed.
     * De feed is niet officieel gegarandeerd; bij fouten tonen we geen verzonnen scores. */
    private void addEredivisieLiveBlock(LinearLayout parent) {
        LinearLayout block = new LinearLayout(this);
        block.setOrientation(LinearLayout.VERTICAL);
        block.setPadding(dp(14), dp(12), dp(14), dp(12));
        block.setBackground(cardBackground());
        TextView title = tv("●  LIVE EREDIVISIE", 15, C.GREEN, true);
        block.addView(title);
        TextView hint = tv("Actuele tussenstanden en wedstrijden laden…", 12, C.MUTED, false);
        hint.setPadding(0, dp(8), 0, dp(4));
        block.addView(hint);
        TextView more = tv("ALLE UITSLAGEN  ›", 12, C.GREEN, true);
        more.setPadding(0, dp(8), 0, 0);
        more.setOnClickListener(v -> showScores());
        block.addView(more);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(4), 0, dp(14));
        parent.addView(block, 0, lp);

        executor.execute(() -> {
            String result = null;
            try {
                URL url = new URL("https://site.api.espn.com/apis/site/v2/sports/soccer/ned.1/scoreboard");
                HttpURLConnection c = (HttpURLConnection) url.openConnection();
                c.setRequestMethod("GET");
                c.setConnectTimeout(7000);
                c.setReadTimeout(7000);
                c.setRequestProperty("User-Agent", "VoetbalHub/2.6 Android");
                try (InputStream in = c.getInputStream(); java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream()) {
                    byte[] buffer = new byte[4096]; int n;
                    while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
                    JSONObject json = new JSONObject(out.toString("UTF-8"));
                    JSONArray events = json.optJSONArray("events");
                    StringBuilder b = new StringBuilder();
                    if (events != null) {
                        for (int i = 0; i < events.length() && i < 6; i++) {
                            JSONObject event = events.optJSONObject(i);
                            if (event == null) continue;
                            JSONArray comps = event.optJSONArray("competitions");
                            if (comps == null || comps.length() == 0) continue;
                            JSONObject comp = comps.optJSONObject(0);
                            JSONArray teams = comp == null ? null : comp.optJSONArray("competitors");
                            if (teams == null || teams.length() < 2) continue;
                            JSONObject home = teams.optJSONObject(0), away = teams.optJSONObject(1);
                            String homeName = home == null ? "Thuis" : home.optJSONObject("team") == null ? "Thuis" : home.optJSONObject("team").optString("shortDisplayName", home.optJSONObject("team").optString("displayName", "Thuis"));
                            String awayName = away == null ? "Uit" : away.optJSONObject("team") == null ? "Uit" : away.optJSONObject("team").optString("shortDisplayName", away.optJSONObject("team").optString("displayName", "Uit"));
                            String hs = home == null ? "-" : home.optString("score", "-");
                            String as = away == null ? "-" : away.optString("score", "-");
                            JSONObject status = event.optJSONObject("status");
                            JSONObject type = status == null ? null : status.optJSONObject("type");
                            String state = type == null ? "" : type.optString("shortDetail", type.optString("detail", ""));
                            b.append(homeName).append("  ").append(hs).append(" - ").append(as).append("  ").append(awayName);
                            if (!state.isEmpty()) b.append("   ·   ").append(state);
                            b.append("\n");
                        }
                    }
                    result = b.length() == 0 ? "Geen Eredivisie-wedstrijden gevonden voor dit moment." : b.toString().trim();
                } finally { c.disconnect(); }
            } catch (Exception ignored) { result = "Live standen tijdelijk niet beschikbaar. Probeer later opnieuw."; }
            final String finalResult = result;
            main.post(() -> {
                if (isFinishing() || isDestroyed()) return;
                hint.setText(finalResult);
            });
        });
    }

    private GradientDrawable cardBackground() {
        GradientDrawable g = new GradientDrawable();
        g.setColor(C.CARD);
        g.setCornerRadius(dp(18));
        g.setStroke(dp(1), C.BORDER);
        return g;
    }

    private void addArticleCard(LinearLayout list, Article a, boolean hero) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(10), dp(10), dp(10), dp(12));
        card.setClickable(true);
        card.setBackground(cardBackground());
        card.setOnClickListener(v -> openArticle(a.link, a.title));

        ImageView image = new ImageView(this);
        image.setScaleType(ImageView.ScaleType.CENTER_CROP);
        image.setBackgroundColor(C.IMAGE_PLACEHOLDER);
        image.setTag(a.imageUrl);
        int imageHeight = hero ? dp(190) : dp(125);
        card.addView(image, new LinearLayout.LayoutParams(-1, imageHeight));
        loadArticleImage(image, a.imageUrl);

        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(4), dp(9), dp(4), 0);

        LinearLayout sourceRow = new LinearLayout(this);
        sourceRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView source = tv(a.source.toUpperCase(Locale.getDefault()), 9, C.GREEN, true);
        sourceRow.addView(source, new LinearLayout.LayoutParams(0, dp(20), 1));
        TextView date = tv(formatDate(a.date), 9, C.MUTED, false);
        sourceRow.addView(date, new LinearLayout.LayoutParams(-2, dp(20)));
        TextView bookmark = tv(isArticleSaved(a.link) ? "★" : "☆", 20, isArticleSaved(a.link) ? C.GREEN : C.MUTED, true);
        bookmark.setGravity(Gravity.CENTER);
        bookmark.setContentDescription(isArticleSaved(a.link) ? "Verwijder uit bewaarde artikelen" : "Bewaar artikel");
        bookmark.setOnClickListener(v -> {
            toggleSavedArticle(a.link);
            bookmark.setText(isArticleSaved(a.link) ? "★" : "☆");
            bookmark.setTextColor(isArticleSaved(a.link) ? C.GREEN : C.MUTED);
            bookmark.setContentDescription(isArticleSaved(a.link) ? "Verwijder uit bewaarde artikelen" : "Bewaar artikel");
            Toast.makeText(this, isArticleSaved(a.link) ? "Artikel bewaard" : "Artikel verwijderd uit bewaard", Toast.LENGTH_SHORT).show();
        });
        LinearLayout.LayoutParams bookmarkLp = new LinearLayout.LayoutParams(dp(32), dp(28));
        bookmarkLp.setMargins(dp(6), 0, 0, 0);
        sourceRow.addView(bookmark, bookmarkLp);
        body.addView(sourceRow);

        TextView title = tv(a.title, hero ? 18 : 15, C.TEXT, true);
        title.setMaxLines(hero ? 4 : 3);
        title.setEllipsize(TextUtils.TruncateAt.END);
        title.setPadding(0, dp(5), 0, dp(6));
        body.addView(title);
        body.addView(tv("Lees bij de oorspronkelijke uitgever  ›", 10, C.MUTED, false));
        card.addView(body);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, dp(10));
        list.addView(card, lp);
    }

    private void loadArticleImage(ImageView target, String imageUrl) {
        if (imageUrl == null || imageUrl.trim().isEmpty()) return;
        executor.execute(() -> {
            Bitmap bitmap = null;
            try {
                URL u = new URL(imageUrl);
                HttpURLConnection c = (HttpURLConnection) u.openConnection();
                c.setConnectTimeout(7000);
                c.setReadTimeout(7000);
                c.setInstanceFollowRedirects(true);
                c.setRequestProperty("User-Agent", "VoetbalHub/2.3");
                c.connect();
                if (c.getResponseCode() >= 200 && c.getResponseCode() < 400) {
                    bitmap = BitmapFactory.decodeStream(c.getInputStream());
                }
                c.disconnect();
            } catch (Exception ignored) { }
            final Bitmap result = bitmap;
            if (result != null) {
                main.post(() -> {
                    Object tag = target.getTag();
                    if (imageUrl.equals(tag)) target.setImageBitmap(result);
                });
            }
        });
    }

    private String formatDate(String raw) {
        if (raw == null || raw.trim().isEmpty()) return "";
        String x = raw.trim();
        return x.length() > 24 ? x.substring(0, 24) : x;
    }

    private List<Article> filterArticles(String category) {
        List<Article> base = new ArrayList<>(articles);
        Collections.sort(base, (a, b) -> b.date.compareTo(a.date));
        if (category.equals("Transfers")) return filter(base, "transfer|transferv|deal|akkoord|vertrekt|tekent|contract");
        if (category.equals("Eredivisie")) return filter(base, "Ajax|PSV|Feyenoord|Groningen|AZ|Twente|Utrecht|Heerenveen|NEC|Sparta|Eredivisie|RKC|Go Ahead|Fortuna|PEC|NAC|Volendam|Heracles");
        if (category.equals("Buitenland")) return filter(base, "Premier League|La Liga|Barcelona|Real Madrid|Liverpool|Arsenal|Manchester|Bayern|Dortmund|Serie A|Milan|Inter|PSG|Champions League");
        return base;
    }

    private List<Article> filter(List<Article> base, String regex) {
        List<Article> r = new ArrayList<>();
        for (Article a : base) if (a.title.matches("(?i).*?(" + regex + ").*")) r.add(a);
        return r;
    }

    private void refreshNews() {
        if (loading) return;
        loading = true;
        showNews();
        executor.execute(() -> {
            List<Article> fresh = new ArrayList<>();
            for (int i = 0; i < feedUrls.length; i++) {
                try { fresh.addAll(parseFeed(feedNames[i], feedUrls[i])); } catch (Exception ignored) { }
            }
            LinkedHashMap<String, Article> unique = new LinkedHashMap<>();
            for (Article a : fresh) {
                String key = a.link == null || a.link.isEmpty() ? a.title.toLowerCase(Locale.ROOT) : a.link;
                if (!unique.containsKey(key)) unique.put(key, a);
            }
            fresh = new ArrayList<>(unique.values());
            Collections.sort(fresh, (a, b) -> b.date.compareTo(a.date));
            final List<Article> resultArticles = fresh;
            main.post(() -> {
                if (!resultArticles.isEmpty()) {
                    articles.clear();
                    articles.addAll(resultArticles);
                    saveCachedArticles(resultArticles);
                    lastRefresh = System.currentTimeMillis();
                    prefs.edit().putLong("lastRefresh", lastRefresh).apply();
                }
                loading = false;
                showNews();
            });
        });
    }

    private void loadCachedArticles() {
        String raw = prefs.getString("articleCache", "");
        if (raw.isEmpty()) return;
        try {
            JSONArray arr = new JSONArray(raw);
            articles.clear();
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                articles.add(new Article(o.optString("title"), o.optString("link"), o.optString("source"), o.optString("date"), o.optString("imageUrl")));
            }
        } catch (Exception ignored) { }
    }

    private void saveCachedArticles(List<Article> items) {
        try {
            JSONArray arr = new JSONArray();
            for (int i = 0; i < Math.min(items.size(), 60); i++) {
                Article a = items.get(i);
                JSONObject o = new JSONObject();
                o.put("title", a.title); o.put("link", a.link); o.put("source", a.source); o.put("date", a.date); o.put("imageUrl", a.imageUrl);
                arr.put(o);
            }
            prefs.edit().putString("articleCache", arr.toString()).apply();
        } catch (Exception ignored) { }
    }

    private String formatLastRefresh() {
        return android.text.format.DateFormat.format("HH:mm", new Date(lastRefresh)).toString();
    }

    private List<Article> parseFeed(String source, String url) throws Exception {
        List<Article> result = new ArrayList<>();
        XmlPullParser parser = Xml.newPullParser();
        URL u = new URL(url);
        java.net.URLConnection c = u.openConnection();
        c.setConnectTimeout(8000); c.setReadTimeout(8000); c.setRequestProperty("User-Agent", "VoetbalHub/2.0");
        parser.setInput(c.getInputStream(), null);
        boolean inside = false;
        String title = "", link = "", date = "", imageUrl = "";
        int event = parser.getEventType();
        while (event != XmlPullParser.END_DOCUMENT) {
            String name = parser.getName() == null ? "" : parser.getName();
            String lower = name.toLowerCase(Locale.ROOT);
            if (event == XmlPullParser.START_TAG && (lower.equals("item") || lower.equals("entry"))) inside = true;
            if (inside && event == XmlPullParser.START_TAG) {
                if (lower.equals("title")) { title = nextText(parser); }
                else if (lower.equals("link")) {
                    String href = parser.getAttributeValue(null, "href");
                    link = href != null ? href : nextText(parser);
                } else if (lower.equals("pubdate") || lower.equals("published") || lower.equals("updated") || lower.equals("dc:date")) {
                    date = nextText(parser);
                } else if (lower.equals("media:content") || lower.equals("media:thumbnail") || lower.equals("enclosure") || lower.equals("image")) {
                    String type = parser.getAttributeValue(null, "type");
                    String medium = parser.getAttributeValue(null, "medium");
                    String urlAttr = parser.getAttributeValue(null, "url");
                    if (urlAttr != null && (imageUrl.isEmpty() || "image".equalsIgnoreCase(medium) || (type != null && type.toLowerCase(Locale.ROOT).startsWith("image/")))) imageUrl = urlAttr;
                }
            }
            if (inside && event == XmlPullParser.END_TAG && (lower.equals("item") || lower.equals("entry"))) {
                if (!title.isEmpty() && link.startsWith("https://")) result.add(new Article(clean(title), link, source, date, imageUrl));
                title = ""; link = ""; date = ""; imageUrl = ""; inside = false;
            }
            event = parser.next();
        }
        return result;
    }

    private String nextText(XmlPullParser parser) throws Exception {
        String value = parser.nextText();
        return value == null ? "" : value.trim();
    }

    private String clean(String s) { return s.replaceAll("\\s+", " ").trim(); }

    @SuppressLint("SetJavaScriptEnabled")
    private void openArticle(String url, String title) {
        articleOpen = true;
        content.removeAllViews();
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        LinearLayout toolbar = new LinearLayout(this);
        toolbar.setGravity(Gravity.CENTER_VERTICAL);
        toolbar.setPadding(dp(8), dp(4), dp(8), dp(4));
        TextView back = tv("‹", 34, C.TEXT, false);
        back.setGravity(Gravity.CENTER);
        back.setOnClickListener(v -> showNews());
        toolbar.addView(back, new LinearLayout.LayoutParams(dp(48), dp(48)));
        TextView heading = tv(title, 15, C.TEXT, true);
        heading.setMaxLines(2);
        heading.setEllipsize(TextUtils.TruncateAt.END);
        toolbar.addView(heading, new LinearLayout.LayoutParams(0, dp(52), 1));
        TextView share = tv("↗", 22, C.GREEN, true);
        share.setGravity(Gravity.CENTER);
        share.setOnClickListener(v -> shareArticle(url));
        toolbar.addView(share, new LinearLayout.LayoutParams(dp(48), dp(48)));
        root.addView(toolbar);

        WebView web = new WebView(this);
        activeWebView = web;
        web.setBackgroundColor(C.BG);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setLoadsImagesAutomatically(true);
        web.getSettings().setMediaPlaybackRequiresUserGesture(true);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) { return false; }
        });
        web.loadUrl(url);
        root.addView(web, new LinearLayout.LayoutParams(-1, 0, 1));
        content.addView(root);
    }

    private void shareArticle(String url) {
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_TEXT, url);
        startActivity(Intent.createChooser(send, "Deel artikel"));
    }

    private void showIntro() {
        final FrameLayout overlay = new FrameLayout(this);
        overlay.setBackgroundColor(C.BG);
        overlay.setElevation(dp(50));

        LinearLayout center = new LinearLayout(this);
        center.setOrientation(LinearLayout.VERTICAL);
        center.setGravity(Gravity.CENTER_HORIZONTAL);
        center.setPadding(dp(24), dp(24), dp(24), dp(24));

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.ic_launcher);
        center.addView(logo, new LinearLayout.LayoutParams(dp(82), dp(82)));

        TextView title = tv("VOETBALHUB", 27, C.TEXT, true);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, dp(12), 0, dp(2));
        center.addView(title, new LinearLayout.LayoutParams(-1, dp(38)));

        TextView subtitle = tv("Onafhankelijke verzameling van nieuwslinks", 12, C.MUTED, false);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setMaxLines(2);
        center.addView(subtitle, new LinearLayout.LayoutParams(-1, dp(42)));

        LinearLayout sources = new LinearLayout(this);
        sources.setOrientation(LinearLayout.VERTICAL);
        sources.setGravity(Gravity.CENTER_HORIZONTAL);
        sources.setPadding(0, dp(22), 0, dp(14));
        String[] names = {"VI", "VoetbalPrimeur", "VoetbalNieuws"};
        for (String name : names) {
            TextView source = tv(name, 13, C.TEXT, true);
            source.setGravity(Gravity.CENTER);
            source.setBackground(cardBackground());
            source.setPadding(dp(18), 0, dp(18), 0);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(190), dp(38));
            lp.setMargins(0, 0, 0, dp(7));
            sources.addView(source, lp);
            AlphaAnimation a = new AlphaAnimation(0f, 1f);
            a.setDuration(320);
            a.setStartOffset(name.equals("VI") ? 180 : name.equals("VoetbalPrimeur") ? 430 : 680);
            source.startAnimation(a);
        }
        center.addView(sources);

        TextView arrow = tv("↓", 25, C.GREEN, true);
        arrow.setGravity(Gravity.CENTER);
        center.addView(arrow, new LinearLayout.LayoutParams(-1, dp(30)));

        TextView result = tv("VOETBALHUB  •  ONAFHANKELIJK", 15, C.GREEN, true);
        result.setGravity(Gravity.CENTER);
        GradientDrawable resultBg = new GradientDrawable();
        resultBg.setColor(C.CARD);
        resultBg.setCornerRadius(dp(20));
        resultBg.setStroke(dp(1), C.GREEN);
        result.setBackground(resultBg);
        center.addView(result, new LinearLayout.LayoutParams(dp(220), dp(48)));

        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(-1, -2, Gravity.CENTER);
        overlay.addView(center, cp);
        addContentView(overlay, new ViewGroup.LayoutParams(-1, -1));

        overlay.setAlpha(1f);
        overlay.postDelayed(() -> {
            AlphaAnimation fade = new AlphaAnimation(1f, 0f);
            fade.setDuration(360);
            fade.setInterpolator(new DecelerateInterpolator());
            fade.setAnimationListener(new Animation.AnimationListener() {
                public void onAnimationStart(Animation animation) {}
                public void onAnimationRepeat(Animation animation) {}
                public void onAnimationEnd(Animation animation) {
                    ViewGroup parent = (ViewGroup) overlay.getParent();
                    if (parent != null) parent.removeView(overlay);
                }
            });
            overlay.startAnimation(fade);
        }, 1640);
    }

    private void showVideos() {
        content.removeAllViews();
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.addView(sectionHeader("Voetbalvideo", "VERVERS", this::showVideos));
        TextView sub = tv("Video's blijven binnen VoetbalHub beschikbaar.", 12, C.MUTED, false);
        sub.setPadding(dp(16), 0, dp(16), dp(12)); root.addView(sub);
        ScrollView scroll = new ScrollView(this);
        LinearLayout list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); list.setPadding(dp(16), 0, dp(16), dp(24));
        String[][] videos = {{"VI Video", "https://www.youtube.com/results?search_query=Voetbal+International+VI+Video"}, {"VoetbalPrimeur Video", "https://www.youtube.com/results?search_query=VoetbalPrimeur"}, {"Voetbalzone Video", "https://www.youtube.com/results?search_query=Voetbalzone+voetbal"}};
        for (String[] v : videos) {
            LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setGravity(Gravity.CENTER_VERTICAL); card.setPadding(dp(18), dp(18), dp(18), dp(18)); card.setBackground(cardBackground()); card.setOnClickListener(x -> openArticle(v[1], v[0]));
            card.addView(tv("▶", 28, C.GREEN, true));
            TextView t = tv(v[0], 18, C.TEXT, true); t.setPadding(0, dp(8), 0, dp(4)); card.addView(t);
            card.addView(tv("Afspelen binnen de app  ›", 12, C.MUTED, false));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(120)); lp.setMargins(0, 0, 0, dp(12)); list.addView(card, lp);
        }
        scroll.addView(list); root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1)); content.addView(root);
    }

    private void showScores() {
        content.removeAllViews();
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.addView(sectionHeader("Uitslagen & programma", "VERVERS", this::showScores));
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(16), 0, dp(16), dp(24));
        TextView intro = tv("Bekijk actuele uitslagen en speelschema's bij de oorspronkelijke aanbieders. VoetbalHub toont hier geen verzonnen of verouderde scores.", 13, C.MUTED, false);
        intro.setPadding(0, dp(4), 0, dp(16));
        list.addView(intro);
        addAction(list, "⚡ Flashscore · live scores, statistieken & opstellingen", "https://www.flashscore.nl/");
        addAction(list, "VI wedstrijdcentrum · live uitslagen", "https://www.vi.nl/wedstrijden");
        addAction(list, "Eredivisie · programma en uitslagen", "https://eredivisie.nl/competitie/wedstrijden/");
        addAction(list, "UEFA · Europese wedstrijden", "https://www.uefa.com/uefachampionsleague/fixtures-results/");
        addAction(list, "Premier League · wedstrijden", "https://www.premierleague.com/fixtures");
        addAction(list, "La Liga · wedstrijden", "https://www.laliga.com/en-GB/laliga-easports/results");
        ScrollView scroll = new ScrollView(this);
        scroll.addView(list);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        content.addView(root);
    }

    private void showCompetitions() { content.removeAllViews(); LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.addView(sectionHeader("Competities")); LinearLayout list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); list.setPadding(dp(16), 0, dp(16), dp(24)); String[][] c = {{"🇳🇱 Eredivisie", "https://eredivisie.nl/"}, {"🇳🇱 Keuken Kampioen Divisie", "https://keukenkampioendivisie.nl/"}, {"🏆 Champions League", "https://www.uefa.com/uefachampionsleague/"}, {"🏆 Europa League", "https://www.uefa.com/uefaeuropaleague/"}, {"🏆 Conference League", "https://www.uefa.com/uefaconferenceleague/"}, {"🏴 Premier League", "https://www.premierleague.com/"}, {"🇪🇸 La Liga", "https://www.laliga.com/"}, {"🇮🇹 Serie A", "https://www.legaseriea.it/"}, {"🇩🇪 Bundesliga", "https://www.bundesliga.com/"}, {"🇫🇷 Ligue 1", "https://www.ligue1.com/"}}; for (String[] x : c) addAction(list, x[0], x[1]); ScrollView s = new ScrollView(this); s.addView(list); root.addView(s, new LinearLayout.LayoutParams(-1, 0, 1)); content.addView(root); }

    private Set<String> getSavedArticleLinks() {
        Set<String> stored = prefs.getStringSet("savedArticles", Collections.<String>emptySet());
        return new HashSet<>(stored);
    }

    private boolean isArticleSaved(String link) {
        return link != null && getSavedArticleLinks().contains(link);
    }

    private void toggleSavedArticle(String link) {
        Set<String> saved = getSavedArticleLinks();
        if (saved.contains(link)) saved.remove(link); else saved.add(link);
        prefs.edit().putStringSet("savedArticles", saved).apply();
    }

    private void showFavorites() {
        content.removeAllViews();
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.addView(sectionHeader("Favorieten"));
        ScrollView scroll = new ScrollView(this);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(16), 0, dp(16), dp(24));

        TextView clubTitle = tv("JOUW CLUBS", 12, C.GREEN, true);
        clubTitle.setPadding(0, dp(8), 0, dp(8));
        list.addView(clubTitle);
        Set<String> favs = new HashSet<>(prefs.getStringSet("clubs", Collections.<String>emptySet()));
        TextView h = tv(favs.isEmpty() ? "Kies clubs voor persoonlijker voetbalnieuws." : "Gekozen: " + join(favs, "  •  "), 14, C.TEXT, true);
        h.setPadding(0, 0, 0, dp(12));
        list.addView(h);
        String[] clubs = {"FC Groningen", "Ajax", "PSV", "Feyenoord", "AZ", "FC Twente", "SC Heerenveen", "FC Utrecht", "NEC", "Sparta Rotterdam", "Heracles Almelo", "Go Ahead Eagles", "Fortuna Sittard", "PEC Zwolle", "NAC Breda", "Willem II", "Real Madrid", "FC Barcelona", "Liverpool", "Arsenal", "Manchester City", "Bayern München"};
        for (final String club : clubs) {
            boolean favorite = favs.contains(club);
            TextView button = tv((favorite ? "★  " : "☆  ") + club, 14, favorite ? C.GREEN : C.TEXT, favorite);
            button.setGravity(Gravity.CENTER_VERTICAL);
            button.setPadding(dp(14), 0, dp(14), 0);
            button.setBackground(cardBackground());
            button.setOnClickListener(v -> {
                Set<String> current = new HashSet<>(prefs.getStringSet("clubs", Collections.<String>emptySet()));
                if (current.contains(club)) current.remove(club); else current.add(club);
                prefs.edit().putStringSet("clubs", current).apply();
                showFavorites();
            });
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, dp(46));
            cp.setMargins(0, 0, 0, dp(6));
            list.addView(button, cp);
        }

        TextView savedTitle = tv("BEWAARDE ARTIKELEN", 12, C.GREEN, true);
        savedTitle.setPadding(0, dp(20), 0, dp(10));
        list.addView(savedTitle);
        Set<String> savedLinks = getSavedArticleLinks();
        int savedCount = 0;
        for (Article a : articles) {
            if (savedLinks.contains(a.link)) {
                addArticleCard(list, a, false);
                savedCount++;
            }
        }
        if (savedCount == 0) {
            TextView empty = tv("Je hebt nog geen artikelen bewaard. Tik op ☆ bij een nieuwsbericht om het hier terug te vinden.", 13, C.MUTED, false);
            empty.setPadding(0, 0, 0, dp(12));
            list.addView(empty);
        }
        scroll.addView(list);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        content.addView(root);
    }

    private String join(Set<String> s, String sep) { StringBuilder b = new StringBuilder(); for (String x : s) { if (b.length() > 0) b.append(sep); b.append(x); } return b.toString(); }

    private void showMore() {
        content.removeAllViews();
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.addView(sectionHeader("Meer"));
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(16), 0, dp(16), dp(24));
        addAction(list, "⚡ Flashscore openen · live scores & wedstrijddetails", "https://www.flashscore.nl/");
        addAction(list, "VI.nl openen", "https://www.vi.nl/");
        addAction(list, "VoetbalPrimeur openen", "https://www.voetbalprimeur.nl/");
        addAction(list, "VoetbalNieuws openen", "https://www.voetbalnieuws.nl/");
        addAction(list, "Auteursrecht & bronnen", null);
        addAction(list, "Feedback sturen", "mailto:voetbalhub.app@gmail.com?subject=VoetbalHub%20feedback");
        TextView info = tv("VoetbalHub 2.6\nOnafhankelijke voetbalnieuws-hub. VoetbalHub kopieert geen volledige artikelen of afbeeldingen. Per bericht tonen we de bron en openen we het originele artikel bij de oorspronkelijke uitgever.\n\nVoetbalHub is niet officieel verbonden aan VI, VoetbalPrimeur of VoetbalNieuws.", 12, C.MUTED, false);
        info.setPadding(0, dp(24), 0, 0);
        list.addView(info);
        ScrollView scroll = new ScrollView(this);
        scroll.addView(list);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        content.addView(root);
    }

    private void addAction(LinearLayout list, String label, String url) { TextView b = tv(label + "  ›", 15, C.TEXT, false); b.setGravity(Gravity.CENTER_VERTICAL); b.setPadding(dp(18), 0, dp(18), 0); b.setBackground(cardBackground()); b.setOnClickListener(v -> { if (url != null && url.startsWith("mailto:")) { try { Intent i = new Intent(Intent.ACTION_SENDTO, Uri.parse(url)); startActivity(i); } catch (Exception ignored) {} } else if (url != null) { openArticle(url, label); } else { showLegalInfo(); } }); LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(58)); lp.setMargins(0, 0, 0, dp(10)); list.addView(b, lp); }

    private void showLegalInfo() {
        new AlertDialog.Builder(this)
                .setTitle("Auteursrecht & bronnen")
                .setMessage("VoetbalHub is een onafhankelijke nieuwsaggregator. We tonen per bericht de oorspronkelijke bron en link. Volledige artikelen, foto’s en andere beschermde content blijven op de website van de oorspronkelijke uitgever.\n\nBronnen: VI, VoetbalPrimeur en VoetbalNieuws. VoetbalHub claimt geen officiële samenwerking of vertegenwoordiging van deze partijen.\n\nVoor publicatie in Google Play moeten daarnaast de vereiste News & Magazine-verklaring, actuele contactgegevens en andere Play Console-verplichtingen worden ingevuld.")
                .setPositiveButton("OK", null)
                .show();
    }

    private void showSearch() { EditText input = new EditText(this); input.setHint("Zoek speler, club of onderwerp"); input.setSingleLine(true); input.setPadding(dp(16), 0, dp(16), 0); new AlertDialog.Builder(this).setTitle("Zoeken in VoetbalHub").setView(input).setNegativeButton("Annuleren", null).setPositiveButton("Zoeken", (d, w) -> search(input.getText().toString().trim())).show(); }

    private void search(String q) {
        if (q.isEmpty()) return;
        content.removeAllViews();
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.addView(sectionHeader("Zoekresultaten", "NIEUW ZOEKEN", this::showSearch));
        TextView query = tv("Zoekterm: " + q, 12, C.MUTED, false);
        query.setPadding(dp(16), 0, dp(16), dp(12));
        root.addView(query);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(16), 0, dp(16), dp(24));
        List<Article> matches = new ArrayList<>();
        String needle = q.toLowerCase(Locale.ROOT);
        for (Article a : articles) {
            if (a.title.toLowerCase(Locale.ROOT).contains(needle) || a.source.toLowerCase(Locale.ROOT).contains(needle)) matches.add(a);
        }
        Collections.sort(matches, (a, b) -> b.date.compareTo(a.date));
        for (int i = 0; i < Math.min(30, matches.size()); i++) addArticleCard(list, matches.get(i), false);
        if (matches.isEmpty()) list.addView(tv("Geen resultaten voor \"" + q + "\". Probeer een clubnaam of onderwerp.", 15, C.MUTED, false));
        ScrollView scroll = new ScrollView(this);
        scroll.addView(list);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        content.addView(root);
    }

    private void showSettings() { new AlertDialog.Builder(this).setTitle("VoetbalHub instellingen").setItems(new String[]{"Nieuws vernieuwen", "Favorieten beheren", "Bronnen bekijken", "Over VoetbalHub"}, (d, which) -> { if (which == 0) refreshNews(); else if (which == 1) showFavorites(); else showMore(); }).show(); }

    private void openUrl(String url) { if (url == null || url.isEmpty()) return; openArticle(url, "VoetbalHub"); }

    private boolean backPressedOnce = false;

    @Override
    public void onBackPressed() {
        // Eerst terug door de geschiedenis van een geopend artikel.
        if (activeWebView != null && activeWebView.canGoBack()) {
            activeWebView.goBack();
            return;
        }

        // Vanuit een artikel eerst terug naar het nieuws, niet de app afsluiten.
        if (articleOpen) {
            showNews();
            return;
        }

        // Op het hoofdscherm moet TERUG twee keer binnen 2 seconden worden ingedrukt.
        if (backPressedOnce) {
            main.removeCallbacks(resetBackPressed);
            finish();
            return;
        }

        backPressedOnce = true;
        Toast.makeText(this, "Druk nogmaals op TERUG om VoetbalHub af te sluiten", Toast.LENGTH_SHORT).show();
        main.postDelayed(resetBackPressed, 2000);
    }

    private final Runnable resetBackPressed = () -> backPressedOnce = false;

    @Override protected void onDestroy() { main.removeCallbacks(periodicRefresh); executor.shutdownNow(); super.onDestroy(); }

    private static final class C {
        static final int GREEN = 0xFF25F06B;
        static final int TEXT = 0xFFF6FAF7;
        static final int MUTED = 0xFF8E9B95;
        static final int BG = 0xFF050807;
        static final int CARD = 0xFF0C1210;
        static final int BORDER = 0xFF1B2822;
        static final int IMAGE_PLACEHOLDER = 0xFF17211C;
    }
}
