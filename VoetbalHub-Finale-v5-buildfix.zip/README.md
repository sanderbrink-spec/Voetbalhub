# VoetbalHub 2.1

Android voetbalnieuws-app met nieuws uit VI, VoetbalPrimeur en Voetbalzone, weergegeven binnen VoetbalHub.

## Wijzigingen
- Compactere nieuwsweergave zodat meer content zichtbaar is.
- Extra veilige ruimte onderin voor Samsung-navigatieknoppen.
- Samsung-terugknop blijft binnen de app en navigeert terug in artikelen waar mogelijk.
- Korte intro van circa 2 seconden bij het starten.
- Intro toont VI, VoetbalPrimeur en Voetbalzone als bronnen die samenkomen in VoetbalHub.
- Appversie 2.1.
