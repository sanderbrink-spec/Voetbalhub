# VoetbalHub build

GitHub Actions bouwt automatisch de debug APK.

Workflow: `.github/workflows/build-voetbalhub.yml`

APK-uitvoer: `app/build/outputs/apk/debug/app-debug.apk`

Projectnaam: `VoetbalHub`

Application ID: `nl.voetbalhub.app`
