# VoetbalHub

Online voetbalnieuws-app voor Android. Bundelt RSS-nieuws van Voetbal International en VoetbalPrimeur en gebruikt een Google News RSS-route voor Voetbalzone. Artikelen openen bij de oorspronkelijke uitgever.

## Functies
- Automatische update elke 10 minuten.
- Filters: Alles, VI, VoetbalPrimeur, Voetbalzone.
- Video-tab met directe YouTube-zoekpagina's voor actuele voetbalvideo's.
- Donkere, compacte mobiele interface.
- Geen eigen server of database nodig.

## APK via GitHub
1. Upload deze map naar een GitHub repository.
2. Open **Actions**.
3. Kies **Build Android APK**.
4. De workflow bouwt `app-debug.apk` en zet die als artifact klaar.

## Bronnen
- VI RSS: https://www.vi.nl/feed/news.xml
- VoetbalPrimeur RSS: https://www.voetbalprimeur.nl/feed/news.xml
- Voetbalzone: Google News RSS-filter op voetbalzone.nl

Controleer voor publieke distributie de actuele voorwaarden van de betrokken uitgevers en videoplatforms.
