package nl.voetbalhub.app

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import org.xmlpull.v1.XmlPullParser
import android.util.Xml
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.Executors

private data class NewsItem(val title:String,val link:String,val source:String,val date:String,val image:String?,val description:String?)

class MainActivity: AppCompatActivity() {
    private lateinit var list: RecyclerView
    private lateinit var adapter: NewsAdapter
    private lateinit var status: TextView
    private val executor=Executors.newFixedThreadPool(3)
    private val handler=Handler(Looper.getMainLooper())
    private var current="Alles"
    private val sources=linkedMapOf(
        "VI" to "https://www.vi.nl/feed/news.xml",
        "VoetbalPrimeur" to "https://www.voetbalprimeur.nl/feed/news.xml",
        "Voetbalzone" to "https://news.google.com/rss/search?q=site%3Avoetbalzone.nl%2Fnieuws&hl=nl&gl=NL&ceid=NL%3Anl"
    )
    private val refresh=object:Runnable{override fun run(){load();handler.postDelayed(this,10*60*1000)}}

    override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState); buildUi(); load(); handler.postDelayed(refresh,10*60*1000)}
    override fun onDestroy(){handler.removeCallbacks(refresh);executor.shutdownNow();super.onDestroy()}

    private fun buildUi(){
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(Color.rgb(8,8,8));setPadding(16,18,16,0)}
        val head=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val title=TextView(this).apply{text="VOETBALHUB";setTextColor(Color.WHITE);textSize=26f;typeface=android.graphics.Typeface.DEFAULT_BOLD}
        head.addView(title,LinearLayout.LayoutParams(0,60,1f))
        val reload=TextView(this).apply{text="↻";textSize=32f;setTextColor(Color.WHITE);gravity=Gravity.CENTER;setOnClickListener{load()}}
        head.addView(reload,LinearLayout.LayoutParams(54,60))
        root.addView(head)
        val sub=TextView(this).apply{text="VI  •  VoetbalPrimeur  •  Voetbalzone";setTextColor(Color.LTGRAY);textSize=12f}
        root.addView(sub)
        val chips=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;setPadding(0,14,0,10)}
        listOf("Alles","VI","VoetbalPrimeur","Voetbalzone","Video").forEach{label->
            val b=TextView(this).apply{text=label;textSize=13f;gravity=Gravity.CENTER;setTextColor(if(label=="Alles")Color.BLACK else Color.WHITE);backgroundResource=if(label=="Alles")R.drawable.bg_chip_active else R.drawable.bg_chip;setOnClickListener{current=label;updateChips(chips); if(label=="Video")showVideos() else load()}}
            b.tag=label;chips.addView(b,LinearLayout.LayoutParams(-2,44).apply{rightMargin=8})
        }
        root.addView(chips)
        status=TextView(this).apply{text="Nieuws laden…";setTextColor(Color.GRAY);textSize=12f;setPadding(2,0,0,8)};root.addView(status)
        list=RecyclerView(this).apply{layoutManager=LinearLayoutManager(this@MainActivity);adapter=NewsAdapter{openArticle(it)}}
        root.addView(list,LinearLayout.LayoutParams(-1,0,1f));setContentView(root)
    }
    private fun updateChips(chips:LinearLayout){for(i in 0 until chips.childCount){val v=chips.getChildAt(i) as TextView;val active=v.tag==current;v.backgroundResource=if(active)R.drawable.bg_chip_active else R.drawable.bg_chip;v.setTextColor(if(active)Color.BLACK else Color.WHITE)}}
    private fun load(){status.text="Bijwerken…";executor.execute{val all=mutableListOf<NewsItem>();sources.forEach{(name,url)->try{all+=parse(url,name)}catch(_:Exception){}};all.sortByDescending{it.date};runOnUiThread{if(current=="Video")showVideos() else {val filtered=if(current=="Alles")all else all.filter{it.source==current};adapter.submit(filtered.distinctBy{it.link});status.text="Bijgewerkt om "+SimpleDateFormat("HH:mm",Locale.NL).format(Date())+" • automatisch elke 10 min"}}}}
    private fun parse(url:String,source:String):List<NewsItem>{val c=URL(url).openConnection() as HttpURLConnection;c.connectTimeout=12000;c.readTimeout=12000;c.setRequestProperty("User-Agent","VoetbalHub/1.0");c.connect();val p=Xml.newPullParser();p.setInput(c.inputStream,"UTF-8");val out=mutableListOf<NewsItem>();var title="";var link="";var date="";var desc="";var image:String?=null;var inside=false;var tag="";while(p.eventType!=XmlPullParser.END_DOCUMENT){when(p.eventType){XmlPullParser.START_TAG->{tag=p.name;if(tag.equals("item",true)||tag.equals("entry",true)){inside=true;title="";link="";date="";desc="";image=null}else if(inside&&(tag=="title"||tag=="link"||tag=="pubDate"||tag=="published"||tag=="updated"||tag=="description"||tag=="content")){val text=p.nextText();when(tag){"title"->title=text;"link"->link=text;"pubDate","published","updated"->date=text;"description","content"->desc=text}}else if(inside&&(tag.contains("content")||tag=="enclosure")){image=p.getAttributeValue(null,"url")}},XmlPullParser.END_TAG->{if((p.name.equals("item",true)||p.name.equals("entry",true))&&inside){if(link.isNotBlank()&&title.isNotBlank())out.add(NewsItem(clean(title),link,source,date,image,clean(desc)));inside=false}}};p.next()};c.disconnect();return out.take(30)}
    private fun clean(s:String)=android.text.Html.fromHtml(s,android.text.Html.FROM_HTML_MODE_LEGACY).toString().trim()
    private fun openArticle(item:NewsItem){startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(item.link)))}
    private fun showVideos(){status.text="Video's van voetbalbronnen";adapter.submit(listOf(NewsItem("VI • nieuwste voetbalvideo's","https://www.youtube.com/results?search_query=Voetbal+International","Video","",null,"Open YouTube en speel de nieuwste VI-video's af."),NewsItem("VoetbalPrimeur • nieuwste video's","https://www.youtube.com/results?search_query=VoetbalPrimeur","Video","",null,"Open YouTube en speel de nieuwste VP-video's af."),NewsItem("Voetbalzone • nieuwste video's","https://www.youtube.com/results?search_query=Voetbalzone+voetbal","Video","",null,"Open YouTube en speel actuele voetbalvideo's af."))}
}

private class NewsAdapter(val click:(NewsItem)->Unit):RecyclerView.Adapter<NewsAdapter.H>(){
 private val data=mutableListOf<NewsItem>()
 fun submit(x:List<NewsItem>){data.clear();data.addAll(x);notifyDataSetChanged()}
 override fun onCreateViewHolder(p:ViewGroup,v:Int):H{val box=LinearLayout(p.context).apply{orientation=LinearLayout.HORIZONTAL;setPadding(12,12,12,12);backgroundResource=R.drawable.bg_card};return H(box)}
 override fun getItemCount()=data.size
 override fun onBindViewHolder(h:H,i:Int){h.bind(data[i])}
 inner class H(v:View):RecyclerView.ViewHolder(v){val box=v as LinearLayout;fun bind(n:NewsItem){box.removeAllViews();val img=ImageView(box.context).apply{scaleType=ImageView.ScaleType.CENTER_CROP};box.addView(img,LinearLayout.LayoutParams(108,108));if(!n.image.isNullOrBlank())Glide.with(box.context).load(n.image).centerCrop().into(img);val text=LinearLayout(box.context).apply{orientation=LinearLayout.VERTICAL;setPadding(12,0,0,0)};val s=TextView(box.context).apply{text=n.source.uppercase();textSize=10f;setTextColor(Color.GRAY)};val t=TextView(box.context).apply{text=n.title;textSize=16f;setTextColor(Color.WHITE);typeface=android.graphics.Typeface.DEFAULT_BOLD;setPadding(0,5,0,4)};val d=TextView(box.context).apply{text=if(n.date.isBlank())"" else n.date;textSize=10f;setTextColor(Color.GRAY)};text.addView(s);text.addView(t);text.addView(d);box.addView(text,LinearLayout.LayoutParams(0,-2,1f));box.setOnClickListener{click(n)};val lp=itemView.layoutParams;lp?.let{it as? ViewGroup.MarginLayoutParams}?.setMargins(0,0,0,10)}}
}
