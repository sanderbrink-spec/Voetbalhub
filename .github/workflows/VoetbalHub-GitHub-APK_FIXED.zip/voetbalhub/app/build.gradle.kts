plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android { namespace = "nl.voetbalhub.app"; compileSdk = 35
    defaultConfig { applicationId = "nl.voetbalhub.app"; minSdk = 24; targetSdk = 35; versionCode = 1; versionName = "1.0" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("com.google.android.material:material:1.12.0")
    implementation("com.github.bumptech.glide:glide:4.16.0")
}
