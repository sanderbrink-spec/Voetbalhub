package nl.voetbalhub.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Xml
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.WebSettings
import android.webkit.WebView
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.net.URL
import java.util.Locale
import java.util.concurrent.Executors

private data class Article(val title: String, val link: String, val source: String, val date: String = "")

class MainActivity : AppCompatActivity() {
    private val executor = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private val articles = mutableListOf<Article>()
    private val shown = mutableListOf<Article>()
    private var active = "Voor jou"
    private var loading = false
    private lateinit var content: FrameLayout
    private lateinit var chips: LinearLayout
    private lateinit var nav: LinearLayout
    private val prefs by lazy { getSharedPreferences("voethub", MODE_PRIVATE) }

    private val feeds = listOf(
        "VI" to "https://www.vi.nl/feed/news.xml",
        "VoetbalPrimeur" to "https://www.voetbalprimeur.nl/feed/news.xml",
        "Voetbalzone" to "https://news.google.com/rss/search?q=site%3Avoetbalzone.nl&hl=nl&gl=NL&ceid=NL:nl"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        content = findViewById(R.id.content)
        chips = findViewById(R.id.chips)
        nav = findViewById(R.id.nav)
        buildChips()
        buildNav()
        findViewById<View>(R.id.search).setOnClickListener { showSearch() }
        findViewById<View>(R.id.settings).setOnClickListener { showSettings() }
        showNews()
        refreshNews()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun tv(text: String, size: Float, color: Int, bold: Boolean = false): TextView = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        includeFontPadding = false
    }

    private fun buildChips() {
        chips.removeAllViews()
        listOf("Voor jou", "Laatste nieuws", "Transfers", "Eredivisie", "Buitenland", "Video").forEach { label ->
            val b = TextView(this).apply {
                text = label
                textSize = 13f
                gravity = Gravity.CENTER
                setPadding(dp(16), 0, dp(16), 0)
                setTextColor(if (label == active) ColorConst.BG else ColorConst.TEXT)
                background = ContextCompat.getDrawable(this@MainActivity, if (label == active) R.drawable.rounded_active else R.drawable.rounded_chip)
                setOnClickListener { active = label; buildChips(); if (label == "Video") showVideos() else showNews() }
            }
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(38))
            lp.setMargins(0, 0, dp(8), 0)
            chips.addView(b, lp)
        }
    }

    private fun buildNav() {
        nav.removeAllViews()
        val items = listOf("⌂" to "Nieuws", "▣" to "Uitslagen", "◉" to "Competities", "★" to "Favorieten", "☰" to "Meer")
        items.forEachIndexed { index, pair ->
            val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; isClickable = true }
            val icon = tv(pair.first, 21f, if (index == 0) ColorConst.GREEN else ColorConst.MUTED, true)
            val label = tv(pair.second, 10f, if (index == 0) ColorConst.GREEN else ColorConst.MUTED, index == 0)
            box.addView(icon, LinearLayout.LayoutParams(-1, dp(28)))
            box.addView(label, LinearLayout.LayoutParams(-1, dp(18)))
            box.setOnClickListener {
                when (pair.second) {
                    "Nieuws" -> { active = "Voor jou"; buildChips(); showNews() }
                    "Uitslagen" -> showScores()
                    "Competities" -> showCompetitions()
                    "Favorieten" -> showFavorites()
                    "Meer" -> showMore()
                }
            }
            nav.addView(box, LinearLayout.LayoutParams(0, -1, 1f))
        }
    }

    private fun sectionHeader(title: String, action: String? = null, click: (() -> Unit)? = null): LinearLayout {
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(16), dp(10), dp(16), dp(10)) }
        row.addView(tv(title, 22f, ColorConst.TEXT, true), LinearLayout.LayoutParams(0, dp(40), 1f))
        if (action != null) {
            val a = tv(action, 12f, ColorConst.GREEN, true).apply { gravity = Gravity.CENTER }
            a.setOnClickListener { click?.invoke() }
            row.addView(a, LinearLayout.LayoutParams(dp(80), dp(36)))
        }
        return row
    }

    private fun showNews() {
        content.removeAllViews()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(sectionHeader("Laatste voetbalnieuws", "VERVERS", ::refreshNews))
        val status = tv(if (loading) "Nieuws wordt bijgewerkt…" else "VI  •  VoetbalPrimeur  •  Voetbalzone", 11f, ColorConst.MUTED).apply { setPadding(dp(16), 0, dp(16), dp(10)) }
        root.addView(status)
        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), 0, dp(16), dp(24)) }
        val filtered = filterArticles(active)
        shown.clear(); shown.addAll(filtered)
        if (filtered.isEmpty()) {
            list.addView(tv("Nog geen nieuws geladen. Tik op VERVERS.", 15f, ColorConst.MUTED).apply { setPadding(0, dp(30), 0, 0) })
        } else {
            filtered.take(30).forEachIndexed { i, article -> addArticleCard(list, article, i == 0 && active == "Voor jou") }
        }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        content.addView(root)
    }

    private fun addArticleCard(list: LinearLayout, a: Article, hero: Boolean) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = ContextCompat.getDrawable(this@MainActivity, R.drawable.rounded_card)
            setPadding(dp(16), dp(15), dp(16), dp(15))
            isClickable = true
            setOnClickListener { openUrl(a.link) }
        }
        val meta = tv("${a.source.uppercase(Locale.getDefault())}${if (a.date.isNotBlank()) "  •  ${a.date}" else ""}", 10f, ColorConst.GREEN, true)
        val title = tv(a.title, if (hero) 20f else 16f, ColorConst.TEXT, true).apply { setPadding(0, dp(8), 0, dp(5)) }
        val read = tv("Lees het volledige artikel bij ${a.source}  ›", 11f, ColorConst.MUTED)
        card.addView(meta)
        card.addView(title)
        card.addView(read)
        val lp = LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.setMargins(0, 0, 0, dp(10))
        list.addView(card, lp)
    }

    private fun filterArticles(category: String): List<Article> {
        val base = articles.sortedByDescending { it.date }
        return when (category) {
            "Transfers" -> base.filter { it.title.contains("transfer|transferv|deal|akkoord|vertrekt|tekent|contract", true) }
            "Eredivisie" -> base.filter { it.title.contains("Ajax|PSV|Feyenoord|Groningen|AZ|Twente|Utrecht|Heerenveen|NEC|Sparta|Eredivisie|RKC|Go Ahead|Fortuna|PEC|NAC|Volendam|Heracles", true) }
            "Buitenland" -> base.filter { it.title.contains("Premier League|La Liga|Barcelona|Real Madrid|Liverpool|Arsenal|Manchester|Bayern|Dortmund|Serie A|Milan|Inter|PSG|Champions League", true) }
            else -> base
        }
    }

    private fun refreshNews() {
        if (loading) return
        loading = true
        showNews()
        executor.execute {
            val fresh = mutableListOf<Article>()
            feeds.forEach { (source, url) ->
                try { fresh += parseFeed(source, url).take(20) } catch (_: Exception) { }
            }
            fresh.sortByDescending { it.date }
            main.post {
                articles.clear(); articles.addAll(fresh)
                loading = false
                showNews()
            }
        }
    }

    private fun parseFeed(source: String, url: String): List<Article> {
        val result = mutableListOf<Article>()
        val parser = Xml.newPullParser()
        URL(url).openConnection().apply { connectTimeout = 8000; readTimeout = 8000; setRequestProperty("User-Agent", "VoetbalHub/1.0") }.getInputStream().use { stream ->
            parser.setInput(stream, null)
            var event = parser.eventType
            var title = ""; var link = ""; var date = ""; var inside = false
            while (event != org.xmlpull.v1.XmlPullParser.END_DOCUMENT) {
                if (event == org.xmlpull.v1.XmlPullParser.START_TAG && (parser.name.equals("item", true) || parser.name.equals("entry", true))) inside = true
                if (inside && event == org.xmlpull.v1.XmlPullParser.START_TAG) {
                    when (parser.name.lowercase()) {
                        "title" -> { parser.next(); if (parser.eventType == org.xmlpull.v1.XmlPullParser.TEXT) title = parser.text.trim() }
                        "link" -> {
                            val href = parser.getAttributeValue(null, "href")
                            if (!href.isNullOrBlank()) link = href else { parser.next(); if (parser.eventType == org.xmlpull.v1.XmlPullParser.TEXT) link = parser.text.trim() }
                        }
                        "pubdate", "published", "updated", "dc:date" -> { parser.next(); if (parser.eventType == org.xmlpull.v1.XmlPullParser.TEXT) date = parser.text.trim() }
                    }
                }
                if (inside && event == org.xmlpull.v1.XmlPullParser.END_TAG && (parser.name.equals("item", true) || parser.name.equals("entry", true))) {
                    if (title.isNotBlank() && link.startsWith("http")) result.add(Article(clean(title), link, source, date))
                    title = ""; link = ""; date = ""; inside = false
                }
                event = parser.next()
            }
        }
        return result
    }

    private fun clean(s: String) = s.replace(Regex("\\s+"), " ").trim()

    private fun showVideos() {
        content.removeAllViews()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(sectionHeader("Voetbalvideo", "VERVERS") { showVideos() })
        root.addView(tv("Officiële voetbalvideo's en shows", 12f, ColorConst.MUTED).apply { setPadding(dp(16), 0, dp(16), dp(12)) })
        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), 0, dp(16), dp(24)) }
        val videos = listOf(
            "VI Video" to "https://www.youtube.com/results?search_query=Voetbal+International+VI+Video",
            "VoetbalPrimeur Video" to "https://www.youtube.com/results?search_query=VoetbalPrimeur",
            "Voetbalzone Video" to "https://www.youtube.com/results?search_query=Voetbalzone+voetbal"
        )
        videos.forEach { (name, url) ->
            val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL; background = ContextCompat.getDrawable(this@MainActivity, R.drawable.rounded_card); setPadding(dp(18), dp(18), dp(18), dp(18)); setOnClickListener { openUrl(url) } }
            card.addView(tv("▶", 28f, ColorConst.GREEN, true))
            card.addView(tv(name, 18f, ColorConst.TEXT, true).apply { setPadding(0, dp(8), 0, dp(4)) })
            card.addView(tv("Open officiële videopagina  ›", 12f, ColorConst.MUTED))
            val lp = LinearLayout.LayoutParams(-1, dp(120)); lp.setMargins(0,0,0,dp(12)); list.addView(card, lp)
        }
        scroll.addView(list); root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f)); content.addView(root)
    }

    private fun showScores() {
        content.removeAllViews()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(sectionHeader("Uitslagen & programma", "LIVE") { openUrl("https://www.vi.nl/wedstrijden") })
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16),0,dp(16),dp(24)) }
        list.addView(tv("Wedstrijdcentrum", 20f, ColorConst.TEXT, true).apply { setPadding(0,dp(10),0,dp(8)) })
        list.addView(tv("Bekijk actuele standen, programma's en live uitslagen via het wedstrijdcentrum.", 14f, ColorConst.MUTED).apply { setPadding(0,0,0,dp(18)) })
        addAction(list, "OPEN WEDSTRIJDCENTRUM", "https://www.vi.nl/wedstrijden")
        addAction(list, "EREdivisie programma", "https://eredivisie.nl/competitie/wedstrijden/")
        val scroll = ScrollView(this); scroll.addView(list); root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f)); content.addView(root)
    }

    private fun showCompetitions() {
        content.removeAllViews()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(sectionHeader("Competities"))
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16),0,dp(16),dp(24)) }
        listOf("🇳🇱 Eredivisie" to "https://eredivisie.nl/", "🏆 Champions League" to "https://www.uefa.com/uefachampionsleague/", "🏴 Premier League" to "https://www.premierleague.com/", "🇪🇸 La Liga" to "https://www.laliga.com/", "🇮🇹 Serie A" to "https://www.legaseriea.it/").forEach { addAction(list,it.first,it.second) }
        val scroll=ScrollView(this);scroll.addView(list);root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f));content.addView(root)
    }

    private fun showFavorites() {
        content.removeAllViews(); val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        root.addView(sectionHeader("Favorieten"))
        val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),0,dp(16),dp(24))}
        val favs=prefs.getStringSet("clubs", emptySet()) ?: emptySet()
        list.addView(tv(if(favs.isEmpty()) "Nog geen favoriete clubs." else "Jouw clubs: ${favs.joinToString("  •  ")}",16f,ColorConst.TEXT,true).apply{setPadding(0,dp(16),0,dp(18))})
        listOf("FC Groningen","Ajax","PSV","Feyenoord","AZ").forEach { club ->
            val b=Button(this).apply{text=(if(favs.contains(club)) "★ " else "☆ ")+club; setTextColor(if(favs.contains(club)) ColorConst.GREEN else ColorConst.TEXT); setOnClickListener{val n=(prefs.getStringSet("clubs",emptySet())?:emptySet()).toMutableSet();if(!n.add(club))n.remove(club);prefs.edit().putStringSet("clubs",n).apply();showFavorites()}}
            list.addView(b,LinearLayout.LayoutParams(-1,dp(52)))
        }
        val scroll=ScrollView(this);scroll.addView(list);root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f));content.addView(root)
    }

    private fun showMore() {
        content.removeAllViews(); val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        root.addView(sectionHeader("Meer")); val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),0,dp(16),dp(24))}
        addAction(list,"VI.nl openen","https://www.vi.nl/");addAction(list,"VoetbalPrimeur openen","https://www.voetbalprimeur.nl/");addAction(list,"Voetbalzone openen","https://www.voetbalzone.nl/")
        addAction(list,"Feedback sturen","mailto:voetbalhub.app@gmail.com?subject=VoetbalHub%20feedback")
        list.addView(tv("VoetbalHub 1.0\nEen onafhankelijke nieuwsverzamelaar. Artikelen blijven bij de oorspronkelijke uitgever.",12f,ColorConst.MUTED).apply{setPadding(0,dp(24),0,0)})
        val scroll=ScrollView(this);scroll.addView(list);root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f));content.addView(root)
    }

    private fun addAction(list: LinearLayout, label: String, url: String) {
        val b=TextView(this).apply{text=label+"  ›";textSize=15f;setTextColor(ColorConst.TEXT);gravity=Gravity.CENTER_VERTICAL;setPadding(dp(18),0,dp(18),0);background=ContextCompat.getDrawable(this@MainActivity,R.drawable.rounded_card);setOnClickListener{openUrl(url)}}
        val lp=LinearLayout.LayoutParams(-1,dp(58));lp.setMargins(0,0,0,dp(10));list.addView(b,lp)
    }

    private fun showSearch() {
        val input=EditText(this).apply{hint="Zoek speler, club of onderwerp";setSingleLine();setPadding(dp(16),0,dp(16),0)}
        AlertDialog.Builder(this).setTitle("Zoeken in VoetbalHub").setView(input).setNegativeButton("Annuleren",null).setPositiveButton("Zoeken"){_,_->
            val q=input.text.toString().trim();if(q.isBlank())return@setPositiveButton
            active="Voor jou";buildChips();content.removeAllViews();val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};root.addView(sectionHeader("Zoekresultaten"));val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),0,dp(16),dp(24))};articles.filter{it.title.contains(q,true)}.take(30).forEach{addArticleCard(list,it,false)};if(list.childCount==0)list.addView(tv("Geen resultaten voor \"$q\".",15f,ColorConst.MUTED).apply{setPadding(0,dp(24),0,0)});val scroll=ScrollView(this);scroll.addView(list);root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f));content.addView(root)
        }.show()
    }

    private fun showSettings() {
        AlertDialog.Builder(this).setTitle("VoetbalHub instellingen").setItems(arrayOf("Nieuws vernieuwen","Favorieten beheren","Bronnen bekijken","Over VoetbalHub")){_,which->when(which){0->refreshNews();1->showFavorites();2->showMore();3->showMore()}}.show()
    }

    private fun openUrl(url:String){startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))}

    override fun onDestroy(){executor.shutdownNow();super.onDestroy()}

    private object ColorConst { const val GREEN=0xFF25F06B.toInt(); const val TEXT=0xFFF6FAF7.toInt(); const val MUTED=0xFF8E9B95.toInt(); const val BG=0xFF050807.toInt() }
}
