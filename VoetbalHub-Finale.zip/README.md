# VoetbalHub

Professionele donkere voetbalnieuws-app voor Android.

## Functies
- Gecombineerd nieuws van VI, VoetbalPrimeur en Voetbalzone.
- Automatisch vernieuwen via officiële RSS-bronnen voor VI en VoetbalPrimeur.
- Voetbalzone via Google News RSS als aanvullende feed.
- Tabs voor nieuws, uitslagen, competities, favorieten, video en meer.
- Zoekfunctie.
- Favoriete clubs worden lokaal opgeslagen.
- Artikelen openen bij de oorspronkelijke uitgever.
- Officiële videopagina's openen vanuit de Video-tab.
- Professionele donkere UI met groen neon-accent.
- Eigen VoetbalHub app-pictogram.

## GitHub APK build
De workflow staat in `.github/workflows/build.yml`.

De workflow gebruikt Java 17 en Gradle 8.9. Er is bewust geen `gradlew` nodig, zodat de repository geen wrapper-map of wrapper-jar hoeft te bevatten.

APK artifact:
`app/build/outputs/apk/debug/app-debug.apk`

## Bronnen
VI: https://www.vi.nl/feed/news.xml
VoetbalPrimeur: https://www.voetbalprimeur.nl/feed/news.xml
Voetbalzone: Google News RSS zoekfeed voor site:voetbalzone.nl

De app toont koppen en metadata en opent het volledige artikel bij de oorspronkelijke uitgever.
