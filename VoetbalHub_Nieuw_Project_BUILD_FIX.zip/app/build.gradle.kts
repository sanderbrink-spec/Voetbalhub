plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "nl.voetbalhub.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "nl.voetbalhub.app"
        minSdk = 24
        targetSdk = 35
        versionCode = 51
        versionName = "5.1"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}
