package nl.voetbalhub.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.Typeface
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val bg = Color.rgb(5, 10, 8)
    private val panel = Color.rgb(13, 22, 19)
    private val green = Color.rgb(34, 230, 105)
    private val white = Color.WHITE
    private lateinit var content: LinearLayout
    private lateinit var scroll: ScrollView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg; window.navigationBarColor = bg
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(bg) }
        val splash = TextView(this).apply {
            text = "✦\nVOETBALHUB\nAlles wat voetbal beweegt"
            gravity = Gravity.CENTER; textSize=25f; setTextColor(white); setBackgroundColor(bg)
            setTypeface(null, Typeface.BOLD)
        }
        root.addView(splash, LinearLayout.LayoutParams(-1,0,1f)); setContentView(root)
        splash.postDelayed({
            root.removeAllViews()
            scroll = ScrollView(this)
            content = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(18,18,18,24); setBackgroundColor(bg) }
            scroll.addView(content); root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))
            header()
            section("LIVE EREDIVISIE", "Live standen en uitslagen")
            loadScores()
            section("EUROPA · NEDERLANDSE CLUBS", "Europese wedstrijden")
            loadEurope()
            section("LAATSTE VOETBALNIEUWS", "Nieuwsfeeds")
            addText("Nieuwsbronnen: VI, VoetbalPrimeur, VoetbalNieuws, ESPN en UEFA.", 14, Color.LTGRAY)
            addText("Nieuwsfeedkoppelingen kunnen per bron wijzigen. Gebruik de bronknoppen om het actuele artikeloverzicht te openen.", 13, Color.GRAY)
            addText("VI.nl  •  VoetbalPrimeur  •  ESPN  •  UEFA", 14, green)
            nav(root)
        }, 3000)
    }
    private fun header() {
        addText("✦  VOETBALHUB", 27, white, true)
        addText("Alles wat voetbal beweegt", 15, Color.LTGRAY)
        val row = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        listOf("Voor jou","Laatste nieuws","Transfers","Eredivisie").forEach { label ->
            val b=Button(this).apply { text=label; setTextColor(if(label=="Voor jou") bg else white); setBackgroundColor(if(label=="Voor jou") green else panel); isAllCaps=false }
            row.addView(b, LinearLayout.LayoutParams(0,48,1f).apply { setMargins(2,8,2,10) })
        }
        content.addView(row)
        addText("Laatste voetbalnieuws     VERVERS", 22, white, true)
        addText("Live data wordt opgehaald via openbare ESPN-scorebordfeeds.", 12, Color.GRAY)
    }
    private fun section(title:String, subtitle:String) {
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(14,10,14,10); setBackgroundColor(panel) }
        box.addView(TextView(this).apply { text=title; textSize=19f; setTextColor(green); setTypeface(null,Typeface.BOLD) })
        box.addView(TextView(this).apply { text=subtitle; textSize=13f; setTextColor(Color.LTGRAY) })
        content.addView(box, LinearLayout.LayoutParams(-1,-2).apply { setMargins(0,12,0,4) })
    }
    private fun loadScores() {
        val placeholder = addText("Wedstrijdgegevens laden…", 14, Color.LTGRAY)
        fetch("https://site.api.espn.com/apis/site/v2/sports/soccer/ned.1/scoreboard") { json ->
            runOnUiThread {
                content.removeView(placeholder)
                val events = json?.optJSONArray("events")
                if (events == null || events.length()==0) {
                    addText("Vandaag geen wedstrijden. Er zijn momenteel geen live wedstrijden of uitslagen voor deze competitie.", 14, Color.LTGRAY)
                } else {
                    for (i in 0 until events.length()) {
                        val event=events.optJSONObject(i) ?: continue
                        val comp=event.optJSONArray("competitions")?.optJSONObject(0)
                        val competitors=comp?.optJSONArray("competitors")
                        val status=comp?.optJSONObject("status")?.optJSONObject("type")?.optString("shortDetail","")
                        val names= mutableListOf<String>()
                        if (competitors != null) for(j in 0 until competitors.length()) {
                            val team=competitors.optJSONObject(j)
                            names.add("${team?.optJSONObject("team")?.optString("displayName","Club")} ${team?.optString("score","-")}")
                        }
                        addText(names.joinToString("   •   ") + "\n" + (status ?: ""), 15, white)
                    }
                }
            }
        }
    }
    private fun loadEurope() {
        val p=addText("Europese wedstrijdgegevens laden…",14,Color.LTGRAY)
        // Separate competition feeds; the list is merged and filtered to Dutch clubs.
        val leagues=listOf("uefa.champions","uefa.europa","uefa.europa.conf")
        val results= mutableListOf<String>()
        var remaining=leagues.size
        leagues.forEach { league ->
            fetch("https://site.api.espn.com/apis/site/v2/sports/soccer/$league/scoreboard") { json ->
                synchronized(results) {
                    val events=json?.optJSONArray("events")
                    if(events!=null) for(i in 0 until events.length()) {
                        val e=events.optJSONObject(i) ?: continue
                        val c=e.optJSONArray("competitions")?.optJSONObject(0)?.optJSONArray("competitors")
                        if(c!=null) {
                            val teams=(0 until c.length()).mapNotNull { c.optJSONObject(it)?.optJSONObject("team")?.optString("displayName") }
                            val dutch=listOf("Ajax","PSV","Feyenoord","AZ","Twente","Go Ahead Eagles","Utrecht","Heerenveen","Groningen")
                            if(teams.any { t -> dutch.any { d -> t.contains(d,true) } }) {
                                results.add(teams.joinToString("  •  ") + "  |  " + e.optString("date",""))
                            }
                        }
                    }
                    remaining--
                    if(remaining==0) runOnUiThread {
                        content.removeView(p)
                        if(results.isEmpty()) addText("Geen Europese wedstrijden van Nederlandse clubs gevonden in de actuele feeds. Als er geen wedstrijden zijn, blijft dit blok compact.",14,Color.LTGRAY)
                        else results.distinct().forEach { addText(it,14,white) }
                    }
                }
            }
        }
    }
    private fun fetch(url:String, done:(JSONObject?)->Unit) {
        thread {
            var result:JSONObject?=null
            try {
                val conn=URL(url).openConnection() as HttpURLConnection
                conn.connectTimeout=7000; conn.readTimeout=7000
                conn.setRequestProperty("User-Agent","VoetbalHub/5.0")
                if(conn.responseCode in 200..299) result=JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
                conn.disconnect()
            } catch (_:Exception) {}
            done(result)
        }
    }
    private fun addText(value:String, size:Int, color:Int, bold:Boolean=false): TextView {
        val t=TextView(this).apply { text=value; textSize=size.toFloat(); setTextColor(color); setPadding(8,8,8,8); if(bold)setTypeface(null,Typeface.BOLD) }
        content.addView(t, LinearLayout.LayoutParams(-1,-2))
        return t
    }
    private fun nav(root:LinearLayout) {
        val bar=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; setBackgroundColor(panel) }
        listOf("⌂\nNieuws","▣\nUitslagen","◉\nCompetities","★\nFavorieten","☰\nMeer").forEachIndexed { i,s ->
            bar.addView(TextView(this).apply { text=s; gravity=Gravity.CENTER; textSize=12f; setTextColor(if(i==0)green else Color.LTGRAY); setPadding(2,10,2,10) }, LinearLayout.LayoutParams(0,64,1f))
        }
        root.addView(bar)
    }
}
