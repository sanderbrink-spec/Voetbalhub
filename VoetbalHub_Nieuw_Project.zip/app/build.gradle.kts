plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "nl.voetbalhub.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "nl.voetbalhub.app"
        minSdk = 24
        targetSdk = 35
        versionCode = 50
        versionName = "5.0"
    }
}
