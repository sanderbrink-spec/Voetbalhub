# VoetbalHub 4.19

- Version code: 52
- Based on the supplied VoetbalHub source ZIP; existing app structure and features are retained.
- Google News remains removed; direct VI, VoetbalPrimeur and VoetbalNieuws RSS feeds remain configured.
- European fixtures and KNVB Cup sections remain configured using the existing ESPN scoreboard endpoints.
- Intro loading animation shortened from 4 seconds to 3 seconds.
- Empty fixture sections use less vertical space.

## Build

Push this project to a GitHub repository and run the existing GitHub Actions workflow (`Build VoetbalHub`). The workflow builds a debug APK and release AAB and uploads both as artifacts.

**Important:** Android compilation has not been run locally in this environment. The European fixture API behaviour and live standings/results still need to be verified on a device; this ZIP does not claim those feeds are confirmed fixed.
