package nl.voetbalhub.app;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Html;
import android.text.TextUtils;
import android.util.Xml;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.*;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.LoadAdError;
import android.util.Log;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;

import androidx.appcompat.app.AlertDialog;
import androidx.browser.customtabs.CustomTabsIntent;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import org.xmlpull.v1.XmlPullParser;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {
    private static class Article {
        final String title, link, source, date, imageUrl;

        Article(String title, String link, String source, String date, String imageUrl) {
            this.title = title;
            this.link = link;
            this.source = source;
            this.date = date;
            this.imageUrl = imageUrl == null ? "" : imageUrl;
        }
    }

    private final ExecutorService executor = Executors.newFixedThreadPool(4);
    private final Handler main = new Handler(Looper.getMainLooper());
    private final List<Article> articles = new ArrayList<>();
    private final List<Article> shown = new ArrayList<>();
    private final String[] feedNames = {"VI", "VoetbalPrimeur", "VoetbalNieuws"};
    // Alleen feeds waarvan de uitgever publiek een RSS-feed aanbiedt voor het tonen van nieuwslinks.
    private final String[] feedUrls = {
            "https://www.vi.nl/feed/news.xml",
            "https://www.voetbalprimeur.nl/feed/news.xml",
            "https://www.voetbalnieuws.nl/feed/news.xml"
    };
    private String active = "Voor jou";
    private boolean loading = false;
    private boolean articleOpen = false;
    private WebView activeWebView;
    private Dialog articleDialog;
    private FrameLayout content;
    private LinearLayout chips, nav;
    private SharedPreferences prefs;
    private AdView bannerAdView;
    private final Runnable periodicRefresh = new Runnable() {
        @Override public void run() {
            refreshNews();
            main.postDelayed(this, 10 * 60 * 1000L);
        }
    };
    private long lastRefresh = 0L;

    private void initializeAds() {
        // Mobile Ads SDK initialization is asynchronous. The banner is kept separate
        // from the bottom navigation so it cannot cover app controls.
        MobileAds.initialize(this, initializationStatus -> {
            FrameLayout adContainer = findViewById(R.id.adContainer);
            if (adContainer == null || isFinishing()) return;
            bannerAdView = new AdView(this);
            // Google's official test banner ID: guarantees a visible test ad while debugging.
            // Replace with the production ad-unit ID only after the test banner is confirmed.
            bannerAdView.setAdUnitId("ca-app-pub-3940256099942544/6300978111");
            bannerAdView.setAdSize(AdSize.BANNER);
            bannerAdView.setAdListener(new AdListener() {
                @Override public void onAdLoaded() {
                    Log.d("VoetbalHubAds", "Test banner loaded successfully");
                    adContainer.setVisibility(View.VISIBLE);
                }
                @Override public void onAdFailedToLoad(LoadAdError error) {
                    Log.e("VoetbalHubAds", "Banner failed: " + error.getCode() + " / " + error.getMessage());
                    Toast.makeText(MainActivity.this, "Testadvertentie laden mislukt (" + error.getCode() + ")", Toast.LENGTH_LONG).show();
                }
            });
            adContainer.removeAllViews();
            adContainer.addView(bannerAdView, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.CENTER));
            bannerAdView.loadAd(new AdRequest.Builder().build());
        });
    }

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initializeAds();
        content = findViewById(R.id.content);
        chips = findViewById(R.id.chips);
        nav = findViewById(R.id.nav);
        View header = findViewById(R.id.header);
        ViewCompat.setOnApplyWindowInsetsListener(header, (v, insets) -> {
            int top = insets.getInsets(WindowInsetsCompat.Type.statusBars()).top;
            v.setPadding(v.getPaddingLeft(), top, v.getPaddingRight(), v.getPaddingBottom());
            ViewGroup.LayoutParams lp = v.getLayoutParams();
            lp.height = dp(64) + top;
            v.setLayoutParams(lp);
            return insets;
        });
        ViewCompat.setOnApplyWindowInsetsListener(nav, (v, insets) -> {
            int bottom = insets.getInsets(WindowInsetsCompat.Type.navigationBars()).bottom;
            int extra = dp(10);
            v.setPadding(v.getPaddingLeft(), dp(4), v.getPaddingRight(), bottom + extra);
            ViewGroup.LayoutParams lp = v.getLayoutParams();
            lp.height = dp(76) + bottom;
            v.setLayoutParams(lp);
            return insets;
        });
        ViewCompat.requestApplyInsets(header);
        ViewCompat.requestApplyInsets(nav);
        prefs = getSharedPreferences("voethub", MODE_PRIVATE);
        lastRefresh = prefs.getLong("lastRefresh", 0L);
        loadCachedArticles();
        buildChips();
        buildNav();
        findViewById(R.id.logo).setOnClickListener(v -> { active = "Voor jou"; buildChips(); showNews(); });
        findViewById(R.id.title).setOnClickListener(v -> { active = "Voor jou"; buildChips(); showNews(); });
        findViewById(R.id.search).setOnClickListener(v -> showSearch());
        findViewById(R.id.settings).setOnClickListener(v -> showSettings());
        showNews();
        refreshNews();
        main.postDelayed(periodicRefresh, 10 * 60 * 1000L);
        showIntro();
    }

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    private TextView tv(String text, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setIncludeFontPadding(false);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private void buildChips() {
        chips.removeAllViews();
        String[] labels = {"Voor jou", "Laatste nieuws", "Transfers", "Eredivisie", "Buitenland", "Video"};
        for (String label : labels) {
            TextView b = tv(label, 13, label.equals(active) ? C.BG : C.TEXT, false);
            b.setGravity(Gravity.CENTER);
            b.setPadding(dp(13), 0, dp(13), 0);
            b.setBackground(ContextCompat.getDrawable(this, label.equals(active) ? R.drawable.rounded_active : R.drawable.rounded_chip));
            b.setOnClickListener(v -> {
                active = label;
                buildChips();
                if (label.equals("Video")) showVideos(); else showNews();
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, dp(34));
            lp.setMargins(0, 0, dp(8), 0);
            chips.addView(b, lp);
        }
    }

    private void buildNav() {
        nav.removeAllViews();
        String[][] items = {{"⌂", "Nieuws"}, {"▣", "Uitslagen"}, {"◉", "Competities"}, {"★", "Favorieten"}, {"☰", "Meer"}};
        for (int i = 0; i < items.length; i++) {
            final String page = items[i][1];
            final int index = i;
            LinearLayout box = new LinearLayout(this);
            box.setOrientation(LinearLayout.VERTICAL);
            box.setGravity(Gravity.CENTER);
            box.setClickable(true);
            box.addView(tv(items[i][0], 21, index == 0 ? C.GREEN : C.MUTED, true), new LinearLayout.LayoutParams(-1, dp(28)));
            box.addView(tv(page, 10, index == 0 ? C.GREEN : C.MUTED, index == 0), new LinearLayout.LayoutParams(-1, dp(18)));
            box.setOnClickListener(v -> {
                switch (page) {
                    case "Nieuws": active = "Voor jou"; buildChips(); showNews(); break;
                    case "Uitslagen": showScores(); break;
                    case "Competities": showCompetitions(); break;
                    case "Favorieten": showFavorites(); break;
                    default: showMore();
                }
            });
            nav.addView(box, new LinearLayout.LayoutParams(0, -1, 1));
        }
    }

    private LinearLayout sectionHeader(String title, String action, final Runnable click) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(16), dp(10), dp(16), dp(10));
        row.addView(tv(title, 22, C.TEXT, true), new LinearLayout.LayoutParams(0, dp(40), 1));
        if (action != null) {
            TextView a = tv(action, 12, C.GREEN, true);
            a.setGravity(Gravity.CENTER);
            a.setOnClickListener(v -> { if (click != null) click.run(); });
            row.addView(a, new LinearLayout.LayoutParams(dp(90), dp(36)));
        }
        return row;
    }

    private LinearLayout sectionHeader(String title) { return sectionHeader(title, null, null); }

    private void showNews() {
        articleOpen = false;
        activeWebView = null;
        content.removeAllViews();
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.addView(sectionHeader("Laatste voetbalnieuws", "VERVERS", this::refreshNews));
        TextView status = tv(loading ? "Nieuws wordt bijgewerkt…" : "Live RSS  •  VI  •  VoetbalPrimeur  •  VoetbalNieuws" + (lastRefresh > 0 ? "  •  " + formatLastRefresh() : ""), 11, C.MUTED, false);
        status.setPadding(dp(16), 0, dp(16), dp(10));
        root.addView(status);
        ScrollView scroll = new ScrollView(this);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(16), 0, dp(16), dp(24));
        if (active.equals("Voor jou") || active.equals("Eredivisie")) {
            addEredivisieLiveBlock(list);
        }
        List<Article> filtered = filterArticles(active);
        shown.clear(); shown.addAll(filtered);
        if (filtered.isEmpty()) {
            list.addView(tv("Nog geen nieuws geladen. Tik op VERVERS.", 15, C.MUTED, false), new LinearLayout.LayoutParams(-1, dp(60)));
        } else {
            for (int i = 0; i < Math.min(30, filtered.size()); i++) addArticleCard(list, filtered.get(i), i == 0 && active.equals("Voor jou"));
        }
        scroll.addView(list);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        content.addView(root);
    }


    /** Live Eredivisieblok met aftraptijd, status en wedstrijdminuut uit de scoreboardfeed. */
    private void addEredivisieLiveBlock(LinearLayout parent) {
        LinearLayout block = new LinearLayout(this);
        block.setOrientation(LinearLayout.VERTICAL);
        block.setPadding(dp(14), dp(12), dp(14), dp(12));
        block.setBackground(cardBackground());

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = tv("LIVE  EREDIVISIE", 19, C.TEXT, true);
        header.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        TextView refresh = tv("↻  VERVERS", 12, C.GREEN, true);
        header.addView(refresh);
        block.addView(header);

        TextView hint = tv("LIVE SCORES  •  PROGRAMMA  •  EINDSTANDEN", 11, C.MUTED, true);
        hint.setPadding(0, dp(8), 0, dp(4));
        block.addView(hint);
        LinearLayout matches = new LinearLayout(this);
        matches.setOrientation(LinearLayout.VERTICAL);
        block.addView(matches);
        TextView more = tv("ALLE UITSLAGEN  ›", 12, C.GREEN, true);
        more.setPadding(0, dp(10), 0, 0);
        more.setOnClickListener(v -> showScores());
        block.addView(more);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(4), 0, dp(14));
        parent.addView(block, 0, lp);

        Runnable load = () -> {
            hint.setVisibility(View.VISIBLE);
            hint.setText("Wedstrijden en tijden bijwerken…");
            matches.removeAllViews();
            executor.execute(() -> {
                final List<String[]> rows = new ArrayList<>();
                String error = null;
                HttpURLConnection c = null;
                try {
                    URL url = new URL("https://site.api.espn.com/apis/site/v2/sports/soccer/ned.1/scoreboard");
                    c = (HttpURLConnection) url.openConnection();
                    c.setRequestMethod("GET");
                    c.setRequestProperty("Cache-Control", "no-cache");
                    c.setConnectTimeout(8000);
                    c.setReadTimeout(8000);
                    c.setRequestProperty("User-Agent", "VoetbalHub/2.8 Android");
                    try (InputStream in = c.getInputStream(); java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream()) {
                        byte[] buffer = new byte[4096]; int n;
                        while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
                        JSONObject json = new JSONObject(out.toString("UTF-8"));
                        JSONArray events = json.optJSONArray("events");
                        if (events != null) {
                            // Toon bewust slechts één wedstrijddag: de eerste datum die de feed teruggeeft.
                            String selectedMatchDay = "";
                            for (int i = 0; i < events.length(); i++) {
                                JSONObject candidate = events.optJSONObject(i);
                                if (candidate != null) {
                                    String candidateDate = candidate.optString("date", "");
                                    if (candidateDate.length() >= 10) { selectedMatchDay = candidateDate.substring(0, 10); break; }
                                }
                            }
                            for (int i = 0; i < events.length() && rows.size() < 12; i++) {
                                JSONObject event = events.optJSONObject(i);
                                if (event == null) continue;
                                String eventDate = event.optString("date", "");
                                if (!selectedMatchDay.isEmpty() && (eventDate.length() < 10 || !selectedMatchDay.equals(eventDate.substring(0, 10)))) continue;
                                JSONArray comps = event.optJSONArray("competitions");
                                if (comps == null || comps.length() == 0) continue;
                                JSONObject comp = comps.optJSONObject(0);
                                JSONArray competitors = comp == null ? null : comp.optJSONArray("competitors");
                                if (competitors == null || competitors.length() < 2) continue;
                                JSONObject a = competitors.optJSONObject(0), b = competitors.optJSONObject(1);
                                JSONObject at = a == null ? null : a.optJSONObject("team");
                                JSONObject bt = b == null ? null : b.optJSONObject("team");
                                String home = at == null ? "Thuis" : at.optString("displayName", at.optString("shortDisplayName", "Thuis"));
                                String away = bt == null ? "Uit" : bt.optString("displayName", bt.optString("shortDisplayName", "Uit"));
                                String homeLogo = at == null ? "" : at.optString("logo", "");
                                String awayLogo = bt == null ? "" : bt.optString("logo", "");
                                String hs = a == null ? "–" : a.optString("score", "–");
                                String as = b == null ? "–" : b.optString("score", "–");
                                JSONObject status = event.optJSONObject("status");
                                JSONObject type = status == null ? null : status.optJSONObject("type");
                                String state = type == null ? "" : type.optString("state", "");
                                String statusName = type == null ? "" : type.optString("name", "");
                                String statusDetail = type == null ? "" : type.optString("detail", "");
                                String statusShortDetail = type == null ? "" : type.optString("shortDetail", "");
                                String statusText = (statusName + " " + statusDetail + " " + statusShortDetail).toLowerCase(java.util.Locale.ROOT);
                                boolean halftime = "halftime".equalsIgnoreCase(state)
                                        || statusText.contains("halftime") || statusText.contains("half-time")
                                        || statusText.contains("rust") || statusText.contains("interval");
                                boolean completed = "post".equalsIgnoreCase(state) || (type != null && type.optBoolean("completed", false));
                                if (!"in".equalsIgnoreCase(state) && !completed && !halftime) { hs = "–"; as = "–"; }
                                String label;
                                String kickoff = formatKickoff(event.optString("date", ""));
                                if (halftime) {
                                    // ESPN may keep state='in' and the clock at 45+ added time while its detail says Halftime.
                                    label = "RUST · HALF-TIME";
                                } else if (completed) {
                                    label = "AFGELOPEN";
                                } else if ("in".equalsIgnoreCase(state)) {
                                    String clock = status == null ? "" : status.optString("displayClock", "");
                                    int period = status == null ? 0 : status.optInt("period", 0);
                                    if (!clock.isEmpty() && !"0:00".equals(clock)) {
                                        String minute = clock.contains(":") ? clock.substring(0, clock.indexOf(':')) : clock;
                                        label = (period >= 2 ? "2E HELFT · " : "LIVE · ") + minute + "'";
                                    } else {
                                        label = period >= 2 ? "2E HELFT" : "LIVE";
                                    }
                                } else {
                                    label = kickoff.isEmpty() ? "AFTRAPTIJD ONBEKEND" : kickoff;
                                }
                                rows.add(new String[]{home, hs, as, away, label, eventDate, homeLogo, awayLogo, event.optString("id", "")});
                            }
                        }
                    }
                    if (rows.isEmpty()) error = "Geen Eredivisie-wedstrijden gevonden. Probeer later opnieuw.";
                } catch (Exception ex) {
                    error = "Live standen tijdelijk niet beschikbaar. Controleer je internetverbinding.";
                } finally { if (c != null) c.disconnect(); }
                final String errorMessage = error;
                main.post(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    matches.removeAllViews();
                    if (errorMessage != null) {
                        hint.setText(errorMessage);
                        return;
                    }
                    boolean hasScheduledOrLive = false;
                    for (String[] r : rows) if (!"AFGELOPEN".equals(r[4])) { hasScheduledOrLive = true; break; }
                    hint.setText(hasScheduledOrLive ? "Scores en wedstrijdstatus · tik op een wedstrijd voor details bij ESPN" : "Geen komende Eredivisie-wedstrijden op deze speeldag");
                    if (!hasScheduledOrLive && !rows.isEmpty()) {
                        TextView togglePlayed = tv("▸  GESPEELDE WEDSTRIJDEN TONEN (" + rows.size() + ")", 11, C.GREEN, true);
                        togglePlayed.setGravity(Gravity.CENTER_VERTICAL); togglePlayed.setPadding(dp(8), dp(8), dp(8), dp(8));
                        matches.setVisibility(View.GONE);
                        togglePlayed.setOnClickListener(v -> { boolean open = matches.getVisibility() != View.VISIBLE; matches.setVisibility(open ? View.VISIBLE : View.GONE); togglePlayed.setText((open ? "▾" : "▸") + "  GESPEELDE WEDSTRIJDEN " + (open ? "VERBERGEN" : "TONEN") + " (" + rows.size() + ")"); });
                        block.addView(togglePlayed, block.indexOfChild(matches) + 1);
                    } else matches.setVisibility(View.VISIBLE);
                    for (String[] row : rows) {
                        boolean live = row[4].contains("LIVE") || row[4].contains("HELFT") || row[4].equals("RUST");
                        boolean finished = row[4].equals("AFGELOPEN");
                        LinearLayout match = new LinearLayout(this);
                        match.setOrientation(LinearLayout.VERTICAL);
                        match.setPadding(dp(10), dp(6), dp(10), dp(5));
                        GradientDrawable bg = new GradientDrawable();
                        bg.setColor(C.BG); bg.setCornerRadius(dp(16)); bg.setStroke(dp(1), C.BORDER);
                        match.setBackground(bg);
                        match.setClickable(true); match.setFocusable(true);
                        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(-1, -2);
                        mp.setMargins(0, dp(6), 0, dp(2));

                        LinearLayout statusRow = new LinearLayout(this);
                        statusRow.setGravity(Gravity.CENTER);
                        TextView statusText = tv(row[4], 10, live ? C.GREEN : (finished ? C.MUTED : C.TEXT), true);
                        statusText.setGravity(Gravity.CENTER);
                        if (live) {
                            statusText.setPadding(dp(8), dp(3), dp(8), dp(3));
                            GradientDrawable liveBg = new GradientDrawable();
                            liveBg.setColor(0x2225F06B); liveBg.setCornerRadius(dp(20)); liveBg.setStroke(dp(1), C.GREEN);
                            statusText.setBackground(liveBg);
                        }
                        statusRow.addView(statusText);
                        match.addView(statusRow);

                        LinearLayout teams = new LinearLayout(this);
                        teams.setGravity(Gravity.CENTER_VERTICAL);
                        teams.setPadding(0, dp(6), 0, dp(6));
                        LinearLayout homeColumn = new LinearLayout(this);
                        homeColumn.setOrientation(LinearLayout.VERTICAL); homeColumn.setGravity(Gravity.CENTER);
                        FrameLayout homeLogoFrame = new FrameLayout(this);
                        ImageView homeLogoImage = new ImageView(this);
                        homeLogoImage.setScaleType(ImageView.ScaleType.FIT_CENTER);
                        TextView homeBadge = tv(teamInitials(row[0]), 14, C.GREEN, true); homeBadge.setGravity(Gravity.CENTER);
                        GradientDrawable hb = new GradientDrawable(); hb.setColor(0xFF14251C); hb.setCornerRadius(dp(28)); hb.setStroke(dp(1), C.BORDER);
                        homeBadge.setBackground(hb); homeBadge.setPadding(dp(8), dp(8), dp(8), dp(8));
                        homeLogoFrame.addView(homeBadge, new FrameLayout.LayoutParams(dp(42), dp(42), Gravity.CENTER));
                        homeLogoFrame.addView(homeLogoImage, new FrameLayout.LayoutParams(dp(42), dp(42), Gravity.CENTER));
                        homeColumn.addView(homeLogoFrame, new LinearLayout.LayoutParams(dp(46), dp(46)));
                        loadTeamLogo(homeLogoImage, row.length > 6 ? row[6] : "", homeBadge);
                        TextView homeText = tv(row[0], 13, C.TEXT, true); homeText.setGravity(Gravity.CENTER); homeText.setMaxLines(2);
                        homeText.setPadding(0, dp(5), 0, 0); homeColumn.addView(homeText);
                        teams.addView(homeColumn, new LinearLayout.LayoutParams(0, -2, 1));

                        LinearLayout scoreColumn = new LinearLayout(this);
                        scoreColumn.setOrientation(LinearLayout.VERTICAL); scoreColumn.setGravity(Gravity.CENTER);
                        TextView scoreText = tv(row[1] + "  –  " + row[2], 21, C.TEXT, true); scoreText.setGravity(Gravity.CENTER);
                        scoreColumn.addView(scoreText);
                        TextView detailText = tv("Details ↗", 9, C.MUTED, true); detailText.setGravity(Gravity.CENTER);
                        detailText.setPadding(0, dp(5), 0, 0); scoreColumn.addView(detailText);
                        teams.addView(scoreColumn, new LinearLayout.LayoutParams(dp(112), -2));

                        LinearLayout awayColumn = new LinearLayout(this);
                        awayColumn.setOrientation(LinearLayout.VERTICAL); awayColumn.setGravity(Gravity.CENTER);
                        FrameLayout awayLogoFrame = new FrameLayout(this);
                        ImageView awayLogoImage = new ImageView(this);
                        awayLogoImage.setScaleType(ImageView.ScaleType.FIT_CENTER);
                        TextView awayBadge = tv(teamInitials(row[3]), 14, C.GREEN, true); awayBadge.setGravity(Gravity.CENTER);
                        GradientDrawable ab = new GradientDrawable(); ab.setColor(0xFF14251C); ab.setCornerRadius(dp(28)); ab.setStroke(dp(1), C.BORDER);
                        awayBadge.setBackground(ab); awayBadge.setPadding(dp(8), dp(8), dp(8), dp(8));
                        awayLogoFrame.addView(awayBadge, new FrameLayout.LayoutParams(dp(42), dp(42), Gravity.CENTER));
                        awayLogoFrame.addView(awayLogoImage, new FrameLayout.LayoutParams(dp(42), dp(42), Gravity.CENTER));
                        awayColumn.addView(awayLogoFrame, new LinearLayout.LayoutParams(dp(46), dp(46)));
                        loadTeamLogo(awayLogoImage, row.length > 7 ? row[7] : "", awayBadge);
                        TextView awayText = tv(row[3], 13, C.TEXT, true); awayText.setGravity(Gravity.CENTER); awayText.setMaxLines(2);
                        awayText.setPadding(0, dp(5), 0, 0); awayColumn.addView(awayText);
                        teams.addView(awayColumn, new LinearLayout.LayoutParams(0, -2, 1));
                        match.addView(teams);
                        match.setOnClickListener(v -> openEspnMatch(row.length > 8 ? row[8] : "", row[0], row[3]));
                        matches.addView(match, mp);
                    }
                });
            });
        };
        refresh.setOnClickListener(v -> load.run());
        load.run();
    }


    private void loadTeamLogo(ImageView target, String logoUrl, View fallback) {
        if (logoUrl == null || logoUrl.trim().isEmpty()) return;
        target.setVisibility(View.INVISIBLE);
        executor.execute(() -> {
            HttpURLConnection connection = null;
            try {
                connection = (HttpURLConnection) new URL(logoUrl).openConnection();
                connection.setConnectTimeout(5000);
                connection.setReadTimeout(5000);
                connection.setRequestProperty("User-Agent", "VoetbalHub/2.9 Android");
                try (InputStream input = connection.getInputStream()) {
                    Bitmap bitmap = BitmapFactory.decodeStream(input);
                    if (bitmap != null) main.post(() -> {
                        if (target.getContext() != null) {
                            target.setImageBitmap(bitmap);
                            target.setVisibility(View.VISIBLE);
                            fallback.setVisibility(View.GONE);
                        }
                    });
                }
            } catch (Exception ignored) {
                // Bij een ontbrekend logo blijft de nette initialenbadge zichtbaar.
            } finally { if (connection != null) connection.disconnect(); }
        });
    }

    private String teamInitials(String team) {
        if (team == null || team.trim().isEmpty()) return "FC";
        String[] parts = team.trim().split("\\s+");
        if (parts.length == 1) return parts[0].substring(0, Math.min(3, parts[0].length())).toUpperCase(java.util.Locale.ROOT);
        return (parts[0].substring(0, 1) + parts[parts.length - 1].substring(0, 1)).toUpperCase(java.util.Locale.ROOT);
    }

    private String formatKickoff(String isoDate) {
        if (isoDate == null || isoDate.trim().isEmpty()) return "";
        java.time.ZoneId zone = java.time.ZoneId.of("Europe/Amsterdam");
        java.time.format.DateTimeFormatter timeFormat = java.time.format.DateTimeFormatter.ofPattern("HH:mm");
        try {
            return timeFormat.withZone(zone).format(java.time.Instant.parse(isoDate));
        } catch (Exception ignored) { }
        try {
            return timeFormat.withZone(zone).format(java.time.OffsetDateTime.parse(isoDate).toInstant());
        } catch (Exception ignored) { }
        try {
            return java.time.LocalDateTime.parse(isoDate).atZone(zone).format(timeFormat);
        } catch (Exception ignored) { }
        return "";
    }

    private int safeInt(String value) { try { return Integer.parseInt(value); } catch (Exception e) { return 0; } }

    /** Open the exact ESPN match page using the event ID from the scoreboard feed. */
    private void openEspnMatch(String eventId, String home, String away) {
        try {
            if (eventId != null && eventId.matches("[0-9]+")) {
                Uri uri = Uri.parse("https://www.espn.com/soccer/match/_/gameId/" + eventId);
                openArticle(uri.toString(), "ESPN wedstrijd");
            } else {
                // The feed did not provide an event ID, so open ESPN soccer scores rather than a misleading Google search.
                openArticle("https://www.espn.com/soccer/scoreboard", "ESPN uitslagen");
                Toast.makeText(this, "De directe wedstrijdlink is niet beschikbaar; ESPN-scores zijn geopend.", Toast.LENGTH_LONG).show();
            }
        } catch (Exception e) {
            Toast.makeText(this, "De wedstrijd kan niet worden geopend. Probeer het later opnieuw.", Toast.LENGTH_LONG).show();
        }
    }

    private GradientDrawable cardBackground() {
        GradientDrawable g = new GradientDrawable();
        g.setColor(C.CARD);
        g.setCornerRadius(dp(18));
        g.setStroke(dp(1), C.BORDER);
        return g;
    }

    private void addArticleCard(LinearLayout list, Article a, boolean hero) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(10), dp(10), dp(10), dp(12));
        card.setClickable(true);
        card.setBackground(cardBackground());
        card.setOnClickListener(v -> openArticle(a.link, a.title));

        ImageView image = new ImageView(this);
        image.setScaleType(ImageView.ScaleType.CENTER_CROP);
        image.setBackgroundColor(C.IMAGE_PLACEHOLDER);
        image.setTag(a.imageUrl);
        int imageHeight = hero ? dp(190) : dp(125);
        card.addView(image, new LinearLayout.LayoutParams(-1, imageHeight));
        loadArticleImage(image, a.imageUrl);

        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(4), dp(9), dp(4), 0);

        LinearLayout sourceRow = new LinearLayout(this);
        sourceRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView source = tv(a.source.toUpperCase(Locale.getDefault()), 9, C.GREEN, true);
        sourceRow.addView(source, new LinearLayout.LayoutParams(0, dp(20), 1));
        TextView date = tv(formatDate(a.date), 9, C.MUTED, false);
        sourceRow.addView(date, new LinearLayout.LayoutParams(-2, dp(20)));
        TextView bookmark = tv(isArticleSaved(a.link) ? "★" : "☆", 20, isArticleSaved(a.link) ? C.GREEN : C.MUTED, true);
        bookmark.setGravity(Gravity.CENTER);
        bookmark.setContentDescription(isArticleSaved(a.link) ? "Verwijder uit bewaarde artikelen" : "Bewaar artikel");
        bookmark.setOnClickListener(v -> {
            toggleSavedArticle(a.link);
            bookmark.setText(isArticleSaved(a.link) ? "★" : "☆");
            bookmark.setTextColor(isArticleSaved(a.link) ? C.GREEN : C.MUTED);
            bookmark.setContentDescription(isArticleSaved(a.link) ? "Verwijder uit bewaarde artikelen" : "Bewaar artikel");
            Toast.makeText(this, isArticleSaved(a.link) ? "Artikel bewaard" : "Artikel verwijderd uit bewaard", Toast.LENGTH_SHORT).show();
        });
        LinearLayout.LayoutParams bookmarkLp = new LinearLayout.LayoutParams(dp(32), dp(28));
        bookmarkLp.setMargins(dp(6), 0, 0, 0);
        sourceRow.addView(bookmark, bookmarkLp);
        body.addView(sourceRow);

        TextView title = tv(a.title, hero ? 18 : 15, C.TEXT, true);
        title.setMaxLines(hero ? 4 : 3);
        title.setEllipsize(TextUtils.TruncateAt.END);
        title.setPadding(0, dp(5), 0, dp(6));
        body.addView(title);
        body.addView(tv("Lees bij de oorspronkelijke uitgever  ›", 10, C.MUTED, false));
        card.addView(body);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, dp(10));
        list.addView(card, lp);
    }

    private void loadArticleImage(ImageView target, String imageUrl) {
        if (imageUrl == null || imageUrl.trim().isEmpty()) return;
        executor.execute(() -> {
            Bitmap bitmap = null;
            try {
                URL u = new URL(imageUrl);
                HttpURLConnection c = (HttpURLConnection) u.openConnection();
                c.setConnectTimeout(7000);
                c.setReadTimeout(7000);
                c.setInstanceFollowRedirects(true);
                c.setRequestProperty("User-Agent", "VoetbalHub/2.3");
                c.connect();
                if (c.getResponseCode() >= 200 && c.getResponseCode() < 400) {
                    bitmap = BitmapFactory.decodeStream(c.getInputStream());
                }
                c.disconnect();
            } catch (Exception ignored) { }
            final Bitmap result = bitmap;
            if (result != null) {
                main.post(() -> {
                    Object tag = target.getTag();
                    if (imageUrl.equals(tag)) target.setImageBitmap(result);
                });
            }
        });
    }

    private String formatDate(String raw) {
        if (raw == null || raw.trim().isEmpty()) return "";
        String x = raw.trim();
        return x.length() > 24 ? x.substring(0, 24) : x;
    }

    private List<Article> filterArticles(String category) {
        List<Article> base = new ArrayList<>(articles);
        Collections.sort(base, (a, b) -> b.date.compareTo(a.date));
        if (category.equals("Transfers")) return filter(base, "transfer|transferv|deal|akkoord|vertrekt|tekent|contract");
        if (category.equals("Eredivisie")) return filter(base, "Ajax|PSV|Feyenoord|Groningen|AZ|Twente|Utrecht|Heerenveen|NEC|Sparta|Eredivisie|RKC|Go Ahead|Fortuna|PEC|NAC|Volendam|Heracles");
        if (category.equals("Buitenland")) return filter(base, "Premier League|La Liga|Barcelona|Real Madrid|Liverpool|Arsenal|Manchester|Bayern|Dortmund|Serie A|Milan|Inter|PSG|Champions League");
        return base;
    }

    private List<Article> filter(List<Article> base, String regex) {
        List<Article> r = new ArrayList<>();
        for (Article a : base) if (a.title.matches("(?i).*?(" + regex + ").*")) r.add(a);
        return r;
    }

    private void refreshNews() {
        if (loading) return;
        loading = true;
        showNews();
        executor.execute(() -> {
            List<Article> fresh = new ArrayList<>();
            for (int i = 0; i < feedUrls.length; i++) {
                try { fresh.addAll(parseFeed(feedNames[i], feedUrls[i])); } catch (Exception ignored) { }
            }
            LinkedHashMap<String, Article> unique = new LinkedHashMap<>();
            for (Article a : fresh) {
                String key = a.link == null || a.link.isEmpty() ? a.title.toLowerCase(Locale.ROOT) : a.link;
                if (!unique.containsKey(key)) unique.put(key, a);
            }
            fresh = new ArrayList<>(unique.values());
            Collections.sort(fresh, (a, b) -> b.date.compareTo(a.date));
            final List<Article> resultArticles = fresh;
            main.post(() -> {
                if (!resultArticles.isEmpty()) {
                    articles.clear();
                    articles.addAll(resultArticles);
                    saveCachedArticles(resultArticles);
                    lastRefresh = System.currentTimeMillis();
                    prefs.edit().putLong("lastRefresh", lastRefresh).apply();
                }
                loading = false;
                showNews();
            });
        });
    }

    private void loadCachedArticles() {
        String raw = prefs.getString("articleCache", "");
        if (raw.isEmpty()) return;
        try {
            JSONArray arr = new JSONArray(raw);
            articles.clear();
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                articles.add(new Article(o.optString("title"), o.optString("link"), o.optString("source"), o.optString("date"), o.optString("imageUrl")));
            }
        } catch (Exception ignored) { }
    }

    private void saveCachedArticles(List<Article> items) {
        try {
            JSONArray arr = new JSONArray();
            for (int i = 0; i < Math.min(items.size(), 60); i++) {
                Article a = items.get(i);
                JSONObject o = new JSONObject();
                o.put("title", a.title); o.put("link", a.link); o.put("source", a.source); o.put("date", a.date); o.put("imageUrl", a.imageUrl);
                arr.put(o);
            }
            prefs.edit().putString("articleCache", arr.toString()).apply();
        } catch (Exception ignored) { }
    }

    private String formatLastRefresh() {
        return android.text.format.DateFormat.format("HH:mm", new Date(lastRefresh)).toString();
    }

    private List<Article> parseFeed(String source, String url) throws Exception {
        List<Article> result = new ArrayList<>();
        XmlPullParser parser = Xml.newPullParser();
        URL u = new URL(url);
        java.net.URLConnection c = u.openConnection();
        c.setConnectTimeout(8000); c.setReadTimeout(8000); c.setRequestProperty("User-Agent", "VoetbalHub/2.0");
        parser.setInput(c.getInputStream(), null);
        boolean inside = false;
        String title = "", link = "", date = "", imageUrl = "";
        int event = parser.getEventType();
        while (event != XmlPullParser.END_DOCUMENT) {
            String name = parser.getName() == null ? "" : parser.getName();
            String lower = name.toLowerCase(Locale.ROOT);
            if (event == XmlPullParser.START_TAG && (lower.equals("item") || lower.equals("entry"))) inside = true;
            if (inside && event == XmlPullParser.START_TAG) {
                if (lower.equals("title")) { title = nextText(parser); }
                else if (lower.equals("link")) {
                    String href = parser.getAttributeValue(null, "href");
                    link = href != null ? href : nextText(parser);
                } else if (lower.equals("pubdate") || lower.equals("published") || lower.equals("updated") || lower.equals("dc:date")) {
                    date = nextText(parser);
                } else if (lower.equals("media:content") || lower.equals("media:thumbnail") || lower.equals("enclosure") || lower.equals("image")) {
                    String type = parser.getAttributeValue(null, "type");
                    String medium = parser.getAttributeValue(null, "medium");
                    String urlAttr = parser.getAttributeValue(null, "url");
                    if (urlAttr != null && (imageUrl.isEmpty() || "image".equalsIgnoreCase(medium) || (type != null && type.toLowerCase(Locale.ROOT).startsWith("image/")))) imageUrl = urlAttr;
                }
            }
            if (inside && event == XmlPullParser.END_TAG && (lower.equals("item") || lower.equals("entry"))) {
                if (!title.isEmpty() && link.startsWith("https://")) result.add(new Article(clean(title), link, source, date, imageUrl));
                title = ""; link = ""; date = ""; imageUrl = ""; inside = false;
            }
            event = parser.next();
        }
        return result;
    }

    private String nextText(XmlPullParser parser) throws Exception {
        String value = parser.nextText();
        return value == null ? "" : value.trim();
    }

    private String clean(String s) { return s.replaceAll("\\s+", " ").trim(); }

    private void openArticle(String url, String title) {
        if (url == null || !(url.startsWith("https://") || url.startsWith("http://"))) {
            Toast.makeText(this, "Deze link is niet geldig", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            if (articleDialog != null && articleDialog.isShowing()) articleDialog.dismiss();
            articleOpen = true;
            articleDialog = new Dialog(this);
            LinearLayout page = new LinearLayout(this);
            page.setOrientation(LinearLayout.VERTICAL);
            page.setBackgroundColor(android.graphics.Color.rgb(5, 12, 9));

            LinearLayout toolbar = new LinearLayout(this);
            toolbar.setOrientation(LinearLayout.HORIZONTAL);
            toolbar.setGravity(Gravity.CENTER_VERTICAL);
            toolbar.setPadding(dp(12), dp(6), dp(12), dp(6));
            toolbar.setBackgroundColor(android.graphics.Color.rgb(5, 12, 9));

            TextView close = tv("‹  TERUG NAAR VOETBALHUB", 14, C.TEXT, true);
            close.setGravity(Gravity.CENTER_VERTICAL);
            close.setPadding(dp(6), dp(8), dp(12), dp(8));
            close.setOnClickListener(v -> closeArticleView());
            toolbar.addView(close, new LinearLayout.LayoutParams(-2, dp(48)));

            TextView pageTitle = tv(title == null ? "Nieuwsartikel" : title, 13, C.MUTED, false);
            pageTitle.setMaxLines(1);
            pageTitle.setEllipsize(TextUtils.TruncateAt.END);
            toolbar.addView(pageTitle, new LinearLayout.LayoutParams(0, dp(48), 1));
            page.addView(toolbar, new LinearLayout.LayoutParams(-1, -2));

            activeWebView = new WebView(this);
            activeWebView.getSettings().setJavaScriptEnabled(true);
            activeWebView.getSettings().setDomStorageEnabled(true);
            activeWebView.setWebChromeClient(new WebChromeClient());
            activeWebView.setWebViewClient(new WebViewClient() {
                @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                    return false; // Keep navigation inside this viewer; app back/close returns directly to VoetbalHub.
                }
            });
            page.addView(activeWebView, new LinearLayout.LayoutParams(-1, 0, 1));
            articleDialog.setContentView(page);
            android.view.Window window = articleDialog.getWindow();
            if (window != null) {
                window.setBackgroundDrawableResource(android.R.color.transparent);
                window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
            }
            articleDialog.setOnDismissListener(d -> {
                if (activeWebView != null) {
                    activeWebView.stopLoading();
                    activeWebView.destroy();
                    activeWebView = null;
                }
                articleOpen = false;
            });
            articleDialog.show();
            if (articleDialog.getWindow() != null) articleDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
            activeWebView.loadUrl(url);
        } catch (Exception e) {
            articleOpen = false;
            activeWebView = null;
            try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
            catch (Exception ignored) { Toast.makeText(this, "Artikel openen is niet gelukt", Toast.LENGTH_LONG).show(); }
        }
    }

    private void closeArticleView() {
        if (articleDialog != null && articleDialog.isShowing()) articleDialog.dismiss();
        else {
            articleOpen = false;
            activeWebView = null;
            showNews();
        }
    }

    private void shareArticle(String url) {
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_TEXT, url);
        startActivity(Intent.createChooser(send, "Deel artikel"));
    }

    private void showIntro() {
        final FrameLayout overlay = new FrameLayout(this);
        overlay.setBackgroundColor(C.BG);
        overlay.setElevation(dp(50));

        LinearLayout center = new LinearLayout(this);
        center.setOrientation(LinearLayout.VERTICAL);
        center.setGravity(Gravity.CENTER_HORIZONTAL);
        center.setPadding(dp(24), dp(24), dp(24), dp(24));

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.ic_launcher);
        center.addView(logo, new LinearLayout.LayoutParams(dp(82), dp(82)));

        TextView title = tv("VOETBALHUB", 27, C.TEXT, true);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, dp(12), 0, dp(2));
        center.addView(title, new LinearLayout.LayoutParams(-1, dp(38)));

        TextView subtitle = tv("Onafhankelijke verzameling van nieuwslinks", 12, C.MUTED, false);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setMaxLines(2);
        center.addView(subtitle, new LinearLayout.LayoutParams(-1, dp(42)));

        LinearLayout sources = new LinearLayout(this);
        sources.setOrientation(LinearLayout.VERTICAL);
        sources.setGravity(Gravity.CENTER_HORIZONTAL);
        sources.setPadding(0, dp(22), 0, dp(14));
        String[] names = {"VI", "VoetbalPrimeur", "VoetbalNieuws"};
        for (String name : names) {
            TextView source = tv(name, 13, C.TEXT, true);
            source.setGravity(Gravity.CENTER);
            source.setBackground(cardBackground());
            source.setPadding(dp(18), 0, dp(18), 0);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(190), dp(38));
            lp.setMargins(0, 0, 0, dp(7));
            sources.addView(source, lp);
            AlphaAnimation a = new AlphaAnimation(0f, 1f);
            a.setDuration(320);
            a.setStartOffset(name.equals("VI") ? 180 : name.equals("VoetbalPrimeur") ? 430 : 680);
            source.startAnimation(a);
        }
        center.addView(sources);

        TextView arrow = tv("↓", 25, C.GREEN, true);
        arrow.setGravity(Gravity.CENTER);
        center.addView(arrow, new LinearLayout.LayoutParams(-1, dp(30)));

        TextView result = tv("VOETBALHUB  •  ONAFHANKELIJK", 15, C.GREEN, true);
        result.setGravity(Gravity.CENTER);
        GradientDrawable resultBg = new GradientDrawable();
        resultBg.setColor(C.CARD);
        resultBg.setCornerRadius(dp(20));
        resultBg.setStroke(dp(1), C.GREEN);
        result.setBackground(resultBg);
        center.addView(result, new LinearLayout.LayoutParams(dp(220), dp(48)));

        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(-1, -2, Gravity.CENTER);
        overlay.addView(center, cp);
        addContentView(overlay, new ViewGroup.LayoutParams(-1, -1));

        overlay.setAlpha(1f);
        overlay.postDelayed(() -> {
            AlphaAnimation fade = new AlphaAnimation(1f, 0f);
            fade.setDuration(360);
            fade.setInterpolator(new DecelerateInterpolator());
            fade.setAnimationListener(new Animation.AnimationListener() {
                public void onAnimationStart(Animation animation) {}
                public void onAnimationRepeat(Animation animation) {}
                public void onAnimationEnd(Animation animation) {
                    ViewGroup parent = (ViewGroup) overlay.getParent();
                    if (parent != null) parent.removeView(overlay);
                }
            });
            overlay.startAnimation(fade);
        }, 1640);
    }

    private void showVideos() {
        content.removeAllViews();
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.addView(sectionHeader("Voetbalvideo", "VERVERS", this::showVideos));
        TextView sub = tv("Video's blijven binnen VoetbalHub beschikbaar.", 12, C.MUTED, false);
        sub.setPadding(dp(16), 0, dp(16), dp(12)); root.addView(sub);
        ScrollView scroll = new ScrollView(this);
        LinearLayout list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); list.setPadding(dp(16), 0, dp(16), dp(24));
        String[][] videos = {{"VI Video", "https://www.youtube.com/results?search_query=Voetbal+International+VI+Video"}, {"VoetbalPrimeur Video", "https://www.youtube.com/results?search_query=VoetbalPrimeur"}, {"Voetbalzone Video", "https://www.youtube.com/results?search_query=Voetbalzone+voetbal"}};
        for (String[] v : videos) {
            LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setGravity(Gravity.CENTER_VERTICAL); card.setPadding(dp(18), dp(18), dp(18), dp(18)); card.setBackground(cardBackground()); card.setOnClickListener(x -> openArticle(v[1], v[0]));
            card.addView(tv("▶", 28, C.GREEN, true));
            TextView t = tv(v[0], 18, C.TEXT, true); t.setPadding(0, dp(8), 0, dp(4)); card.addView(t);
            card.addView(tv("Afspelen binnen de app  ›", 12, C.MUTED, false));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(120)); lp.setMargins(0, 0, 0, dp(12)); list.addView(card, lp);
        }
        scroll.addView(list); root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1)); content.addView(root);
    }

    private void showScores() {
        content.removeAllViews();
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.addView(sectionHeader("Uitslagen & programma", "VERVERS", this::showScores));
        ScrollView scroll = new ScrollView(this);
        LinearLayout list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); list.setPadding(dp(16), dp(8), dp(16), dp(24));
        TextView intro = tv("Kies een bron voor actuele uitslagen en het wedstrijdprogramma.", 13, C.MUTED, false);
        intro.setPadding(dp(2), 0, dp(2), dp(14)); list.addView(intro);
        addSiteCard(list, "Flashscore", "Live scores, statistieken en opstellingen", "https://www.flashscore.nl/", "https://www.google.com/s2/favicons?domain=flashscore.nl&sz=128");
        addSiteCard(list, "VI wedstrijdcentrum", "Live uitslagen en wedstrijden", "https://www.vi.nl/wedstrijden", "https://www.vi.nl/favicon.ico");
        addSiteCard(list, "Eredivisie", "Programma en uitslagen", "https://eredivisie.nl/competitie/wedstrijden/", "https://www.google.com/s2/favicons?domain=eredivisie.nl&sz=128");
        addSiteCard(list, "UEFA", "Europese wedstrijden", "https://www.uefa.com/uefachampionsleague/fixtures-results/", "https://www.google.com/s2/favicons?domain=uefa.com&sz=128");
        addSiteCard(list, "Premier League", "Wedstrijden en uitslagen", "https://www.premierleague.com/fixtures", "https://www.google.com/s2/favicons?domain=premierleague.com&sz=128");
        addSiteCard(list, "La Liga", "Wedstrijden en uitslagen", "https://www.laliga.com/en-GB/laliga-easports/results", "https://www.google.com/s2/favicons?domain=laliga.com&sz=128");
        scroll.addView(list); root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1)); content.addView(root);
    }

    private void addAction(LinearLayout list, String title, String url) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(16), dp(13), dp(14), dp(13));
        card.setBackground(cardBackground());
        TextView label = tv(title, 15, C.TEXT, false);
        label.setGravity(Gravity.CENTER_VERTICAL);
        card.addView(label, new LinearLayout.LayoutParams(0, -2, 1));
        TextView arrow = tv("↗", 20, C.GREEN, true);
        arrow.setGravity(Gravity.CENTER);
        card.addView(arrow, new LinearLayout.LayoutParams(dp(28), dp(32)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, dp(9));
        list.addView(card, lp);
        card.setOnClickListener(v -> openUrl(url));
    }

    private void showCompetitions() {
        content.removeAllViews(); LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.addView(sectionHeader("Competities"));
        LinearLayout list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); list.setPadding(dp(16), 0, dp(16), dp(24));
        String[][] c = {{"Eredivisie","https://eredivisie.nl/","eredivisie.nl"},{"Keuken Kampioen Divisie","https://keukenkampioendivisie.nl/","keukenkampioendivisie.nl"},{"Champions League","https://www.uefa.com/uefachampionsleague/","uefa.com"},{"Europa League","https://www.uefa.com/uefaeuropaleague/","uefa.com"},{"Conference League","https://www.uefa.com/uefaconferenceleague/","uefa.com"},{"Premier League","https://www.premierleague.com/","premierleague.com"},{"La Liga","https://www.laliga.com/","laliga.com"},{"Serie A","https://www.legaseriea.it/","legaseriea.it"},{"Bundesliga","https://www.bundesliga.com/","bundesliga.com"},{"Ligue 1","https://www.ligue1.com/","ligue1.com"}};
        for (String[] x : c) addSiteCard(list, x[0], "Officiële competitiepagina", x[1], "https://www.google.com/s2/favicons?domain=" + x[2] + "&sz=128");
        ScrollView scroll = new ScrollView(this); scroll.addView(list); root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1)); content.addView(root);
    }

    private Set<String> getSavedArticleLinks() {
        Set<String> stored = prefs.getStringSet("savedArticles", Collections.<String>emptySet());
        return new HashSet<>(stored);
    }

    private boolean isArticleSaved(String link) {
        return link != null && getSavedArticleLinks().contains(link);
    }

    private void toggleSavedArticle(String link) {
        Set<String> saved = getSavedArticleLinks();
        if (saved.contains(link)) saved.remove(link); else saved.add(link);
        prefs.edit().putStringSet("savedArticles", saved).apply();
    }

    private void showFavorites() {
        content.removeAllViews(); LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.addView(sectionHeader("Favorieten"));
        ScrollView scroll = new ScrollView(this); LinearLayout list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); list.setPadding(dp(16), 0, dp(16), dp(24));
        TextView clubTitle = tv("JOUW CLUBS", 12, C.GREEN, true); clubTitle.setPadding(0, dp(8), 0, dp(10)); list.addView(clubTitle);
        Set<String> favs = new HashSet<>(prefs.getStringSet("clubs", Collections.<String>emptySet()));
        TextView h = tv(favs.isEmpty() ? "Kies je clubs om je voetbalnieuws persoonlijker te maken." : "Jouw selectie  ·  " + favs.size() + " clubs", 13, C.MUTED, false); h.setPadding(0, 0, 0, dp(12)); list.addView(h);
        String[] clubs = {"FC Groningen", "Ajax", "PSV", "Feyenoord", "AZ", "FC Twente", "SC Heerenveen", "FC Utrecht", "NEC", "Sparta Rotterdam", "Heracles Almelo", "Go Ahead Eagles", "Fortuna Sittard", "PEC Zwolle", "NAC Breda", "Willem II", "Real Madrid", "FC Barcelona", "Liverpool", "Arsenal", "Manchester City", "Bayern München"};
        for (final String club : clubs) {
            boolean favorite = favs.contains(club); LinearLayout card = new LinearLayout(this); card.setGravity(Gravity.CENTER_VERTICAL); card.setPadding(dp(14), 0, dp(12), 0); card.setBackground(cardBackground());
            ImageView crest = new ImageView(this); crest.setScaleType(ImageView.ScaleType.FIT_CENTER); crest.setPadding(dp(2), dp(2), dp(2), dp(2));
            GradientDrawable badge = new GradientDrawable(); badge.setColor(0xFF14251C); badge.setCornerRadius(dp(22)); crest.setBackground(badge); card.addView(crest, new LinearLayout.LayoutParams(dp(42), dp(42)));
            String crestUrl = favoriteClubLogo(club); if (crestUrl != null) loadSiteIcon(crest, crestUrl); else { TextView fallback = tv(clubInitials(club), 11, C.GREEN, true); fallback.setGravity(Gravity.CENTER); card.addView(fallback, 0, new LinearLayout.LayoutParams(dp(42), dp(42))); }
            TextView name = tv(club, 14, favorite ? C.GREEN : C.TEXT, favorite); name.setPadding(dp(12), 0, 0, 0); card.addView(name, new LinearLayout.LayoutParams(0, -2, 1)); card.addView(tv(favorite ? "★" : "+", 22, favorite ? C.GREEN : C.MUTED, true));
            card.setOnClickListener(v -> { Set<String> current = new HashSet<>(prefs.getStringSet("clubs", Collections.<String>emptySet())); if (current.contains(club)) current.remove(club); else current.add(club); prefs.edit().putStringSet("clubs", current).apply(); showFavorites(); });
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, dp(56)); cp.setMargins(0, 0, 0, dp(7)); list.addView(card, cp);
        }
        TextView savedTitle = tv("BEWAARDE ARTIKELEN", 12, C.GREEN, true); savedTitle.setPadding(0, dp(20), 0, dp(10)); list.addView(savedTitle);
        Set<String> savedLinks = getSavedArticleLinks(); int savedCount = 0;
        for (Article a : articles) if (savedLinks.contains(a.link)) { addArticleCard(list, a, false); savedCount++; }
        if (savedCount == 0) { TextView empty = tv("Nog geen artikelen bewaard. Tik op ☆ bij een nieuwsbericht om het hier terug te vinden.", 13, C.MUTED, false); empty.setPadding(0, 0, 0, dp(12)); list.addView(empty); }
        scroll.addView(list); root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1)); content.addView(root);
    }

    private String favoriteClubLogo(String club) {
        String[][] map = {
            {"FC Groningen","fcgroningen.nl"}, {"Ajax","ajax.nl"}, {"PSV","psv.nl"},
            {"Feyenoord","feyenoord.com"}, {"AZ","az.nl"}, {"FC Twente","fctwente.nl"},
            {"SC Heerenveen","sc-heerenveen.nl"}, {"FC Utrecht","fcutrecht.nl"}, {"NEC","nec-nijmegen.nl"},
            {"Sparta Rotterdam","sparta-rotterdam.nl"}, {"Heracles Almelo","heracles.nl"},
            {"Go Ahead Eagles","ga-eagles.nl"}, {"Fortuna Sittard","fortunasittard.nl"},
            {"PEC Zwolle","peczwolle.nl"}, {"NAC Breda","nac.nl"}, {"Willem II","willem-ii.nl"},
            {"Real Madrid","realmadrid.com"}, {"FC Barcelona","fcbarcelona.com"}, {"Liverpool","liverpoolfc.com"},
            {"Arsenal","arsenal.com"}, {"Manchester City","mancity.com"}, {"Bayern München","fcbayern.com"}
        };
        for (String[] item : map) if (item[0].equals(club)) return "https://www.google.com/s2/favicons?domain=" + item[1] + "&sz=128";
        return null;
    }

    private String clubInitials(String club) { String[] parts = club.split(" "); if (parts.length == 1) return club.substring(0, Math.min(3, club.length())).toUpperCase(Locale.ROOT); return (parts[0].substring(0,1) + parts[1].substring(0,1)).toUpperCase(Locale.ROOT); }

    private String join(Set<String> s, String sep) { StringBuilder b = new StringBuilder(); for (String x : s) { if (b.length() > 0) b.append(sep); b.append(x); } return b.toString(); }

    private void showMore() {
        content.removeAllViews();
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.addView(sectionHeader("Meer"));
        ScrollView scroll = new ScrollView(this);
        LinearLayout list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); list.setPadding(dp(16), dp(4), dp(16), dp(24));
        addSiteCard(list, "Flashscore", "Live scores, statistieken & wedstrijddetails", "https://www.flashscore.nl/", "https://www.google.com/s2/favicons?domain=flashscore.nl&sz=128");
        addSiteCard(list, "VI · Voetbal International", "Nieuws en wedstrijdcentrum", "https://www.vi.nl/", "https://www.vi.nl/favicon.ico");
        addSiteCard(list, "VoetbalPrimeur", "Laatste voetbalnieuws en transfers", "https://www.voetbalprimeur.nl/", "https://www.voetbalprimeur.nl/favicon.ico");
        addSiteCard(list, "VoetbalNieuws", "Nieuws uit binnen- en buitenland", "https://www.voetbalnieuws.nl/", "https://www.voetbalnieuws.nl/favicon.ico");
        addSiteCard(list, "Auteursrecht & bronnen", "Informatie over bronnen en gebruik", null, null);
        addSiteCard(list, "Feedback sturen", "Stuur een bericht aan VoetbalHub", "mailto:voetbalhub.app@gmail.com?subject=VoetbalHub%20feedback", null);
        TextView info = tv("VOETBALHUB  ·  Onafhankelijke voetbalnieuws-hub. Artikelen openen bij de oorspronkelijke uitgever.", 12, C.MUTED, false); info.setPadding(dp(4), dp(14), dp(4), 0); list.addView(info);
        scroll.addView(list); root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1)); content.addView(root);
    }

    private void addSiteCard(LinearLayout list, String title, String subtitle, String url, String iconUrl) {
        LinearLayout card = new LinearLayout(this); card.setGravity(Gravity.CENTER_VERTICAL); card.setPadding(dp(14), dp(11), dp(14), dp(11)); card.setBackground(cardBackground());
        ImageView icon = new ImageView(this); icon.setScaleType(ImageView.ScaleType.FIT_CENTER); icon.setImageResource(R.drawable.ic_launcher);
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(dp(42), dp(42)); ip.setMargins(0, 0, dp(13), 0); card.addView(icon, ip);
        if (iconUrl != null) loadSiteIcon(icon, iconUrl);
        LinearLayout textBox = new LinearLayout(this); textBox.setOrientation(LinearLayout.VERTICAL);
        textBox.addView(tv(title, 15, C.TEXT, true)); TextView sub = tv(subtitle, 11, C.MUTED, false); sub.setPadding(0, dp(4), 0, 0); textBox.addView(sub);
        card.addView(textBox, new LinearLayout.LayoutParams(0, -2, 1)); card.addView(tv("›", 24, C.GREEN, true));
        card.setOnClickListener(v -> { if (url == null) showLegalInfo(); else if (url.startsWith("mailto:")) { try { startActivity(new Intent(Intent.ACTION_SENDTO, Uri.parse(url))); } catch (Exception ignored) {} } else openArticle(url, title); });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, 0, 0, dp(10)); list.addView(card, lp);
    }

    private void loadSiteIcon(ImageView target, String iconUrl) {
        executor.execute(() -> { HttpURLConnection c = null; try { c = (HttpURLConnection) new URL(iconUrl).openConnection(); c.setConnectTimeout(5000); c.setReadTimeout(5000); c.setRequestProperty("User-Agent", "Mozilla/5.0 VoetbalHub"); try (InputStream in = c.getInputStream()) { Bitmap bmp = BitmapFactory.decodeStream(in); if (bmp != null) main.post(() -> target.setImageBitmap(bmp)); } } catch (Exception ignored) {} finally { if (c != null) c.disconnect(); } });
    }

    private void showLegalInfo() {
        new AlertDialog.Builder(this)
                .setTitle("Auteursrecht & bronnen")
                .setMessage("VoetbalHub is een onafhankelijke nieuwsaggregator. We tonen per bericht de oorspronkelijke bron en link. Volledige artikelen, foto’s en andere beschermde content blijven op de website van de oorspronkelijke uitgever.\n\nBronnen: VI, VoetbalPrimeur en VoetbalNieuws. VoetbalHub claimt geen officiële samenwerking of vertegenwoordiging van deze partijen.\n\nVoor publicatie in Google Play moeten daarnaast de vereiste News & Magazine-verklaring, actuele contactgegevens en andere Play Console-verplichtingen worden ingevuld.")
                .setPositiveButton("OK", null)
                .show();
    }

    private void showSearch() {
        Dialog dialog = new Dialog(this);
        LinearLayout panel = new LinearLayout(this); panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(20), dp(18), dp(20), dp(16)); panel.setBackground(cardBackground());
        TextView title = tv("Zoeken", 20, C.TEXT, true); title.setPadding(0, 0, 0, dp(5)); panel.addView(title);
        TextView subtitle = tv("Vind nieuws over een club, speler of onderwerp", 12, C.MUTED, false); subtitle.setPadding(0, 0, 0, dp(14)); panel.addView(subtitle);
        EditText input = new EditText(this); input.setSingleLine(true); input.setTextColor(C.TEXT); input.setHintTextColor(C.MUTED); input.setHint("Bijv. FC Groningen"); input.setPadding(dp(14), dp(10), dp(14), dp(10));
        GradientDrawable field = new GradientDrawable(); field.setColor(0xFF080D0B); field.setCornerRadius(dp(12)); field.setStroke(dp(1), C.BORDER); input.setBackground(field); panel.addView(input, new LinearLayout.LayoutParams(-1, dp(50)));
        LinearLayout actions = new LinearLayout(this); actions.setGravity(Gravity.END|Gravity.CENTER_VERTICAL); actions.setPadding(0, dp(14), 0, 0);
        TextView cancel = tv("Annuleren", 13, C.MUTED, true); cancel.setGravity(Gravity.CENTER); cancel.setPadding(dp(12), dp(10), dp(12), dp(10)); cancel.setOnClickListener(v -> dialog.dismiss()); actions.addView(cancel);
        TextView go = tv("ZOEKEN  →", 13, C.GREEN, true); go.setGravity(Gravity.CENTER); go.setPadding(dp(14), dp(10), dp(4), dp(10)); go.setOnClickListener(v -> { String q=input.getText().toString().trim(); dialog.dismiss(); search(q); }); actions.addView(go); panel.addView(actions);
        dialog.setContentView(panel); android.view.Window w=dialog.getWindow(); if(w!=null){w.setBackgroundDrawableResource(android.R.color.transparent); w.setLayout((int)(getResources().getDisplayMetrics().widthPixels*0.90), -2);} dialog.show(); if(dialog.getWindow()!=null){dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent); dialog.getWindow().setLayout((int)(getResources().getDisplayMetrics().widthPixels*0.90), -2);} input.requestFocus();
    }

    private void search(String q) {
        if (q.isEmpty()) return;
        content.removeAllViews();
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.addView(sectionHeader("Zoekresultaten", "NIEUW ZOEKEN", this::showSearch));
        TextView query = tv("Zoekterm: " + q, 12, C.MUTED, false);
        query.setPadding(dp(16), 0, dp(16), dp(12));
        root.addView(query);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(16), 0, dp(16), dp(24));
        List<Article> matches = new ArrayList<>();
        String needle = q.toLowerCase(Locale.ROOT);
        for (Article a : articles) {
            if (a.title.toLowerCase(Locale.ROOT).contains(needle) || a.source.toLowerCase(Locale.ROOT).contains(needle)) matches.add(a);
        }
        Collections.sort(matches, (a, b) -> b.date.compareTo(a.date));
        for (int i = 0; i < Math.min(30, matches.size()); i++) addArticleCard(list, matches.get(i), false);
        if (matches.isEmpty()) list.addView(tv("Geen resultaten voor \"" + q + "\". Probeer een clubnaam of onderwerp.", 15, C.MUTED, false));
        ScrollView scroll = new ScrollView(this);
        scroll.addView(list);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        content.addView(root);
    }

    private void showSettings() {
        Dialog dialog = new Dialog(this); LinearLayout panel = new LinearLayout(this); panel.setOrientation(LinearLayout.VERTICAL); panel.setPadding(dp(18), dp(18), dp(18), dp(12)); panel.setBackground(cardBackground());
        TextView title=tv("VOETBALHUB  ·  MENU",18,C.TEXT,true); title.setPadding(dp(4),dp(2),0,dp(12)); panel.addView(title);
        String[] labels={"↻   Nieuws vernieuwen","★   Favorieten beheren","◎   Bronnen bekijken","ⓘ   Over VoetbalHub"};
        for(int i=0;i<labels.length;i++){ final int index=i; TextView item=tv(labels[i],15,C.TEXT,false); item.setGravity(Gravity.CENTER_VERTICAL); item.setPadding(dp(14),0,dp(10),0); item.setBackground(cardBackground()); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(48)); lp.setMargins(0,0,0,dp(7)); panel.addView(item,lp); item.setOnClickListener(v->{dialog.dismiss(); if(index==0)refreshNews(); else if(index==1)showFavorites(); else showMore();}); }
        TextView close=tv("SLUITEN",12,C.GREEN,true); close.setGravity(Gravity.END|Gravity.CENTER_VERTICAL); close.setPadding(0,dp(8),dp(6),dp(4)); panel.addView(close); close.setOnClickListener(v->dialog.dismiss());
        dialog.setContentView(panel); dialog.show(); if(dialog.getWindow()!=null){dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent); dialog.getWindow().setLayout((int)(getResources().getDisplayMetrics().widthPixels*0.88),-2);}
    }

    private void openUrl(String url) { if (url == null || url.isEmpty()) return; openArticle(url, "VoetbalHub"); }

    private boolean backPressedOnce = false;

    @Override
    public void onBackPressed() {
        // Vanuit een artikel sluit TERUG de ingebouwde browser en keert direct terug naar VoetbalHub.
        // Dit voorkomt dat de gebruiker eerst door eerdere VI-doorverwijzingen moet teruggaan.
        if (articleOpen) {
            closeArticleView();
            return;
        }

        // Op het hoofdscherm moet TERUG twee keer binnen 2 seconden worden ingedrukt.
        if (backPressedOnce) {
            main.removeCallbacks(resetBackPressed);
            finish();
            return;
        }

        backPressedOnce = true;
        Toast.makeText(this, "Druk nogmaals op TERUG om VoetbalHub af te sluiten", Toast.LENGTH_SHORT).show();
        main.postDelayed(resetBackPressed, 2000);
    }

    private final Runnable resetBackPressed = () -> backPressedOnce = false;

    @Override protected void onDestroy() {
        main.removeCallbacks(periodicRefresh);
        main.removeCallbacks(resetBackPressed);
        executor.shutdownNow();
        if (bannerAdView != null) {
            bannerAdView.destroy();
            bannerAdView = null;
        }
        super.onDestroy();
    }

    private static final class C {
        static final int GREEN = 0xFF25F06B;
        static final int TEXT = 0xFFF6FAF7;
        static final int MUTED = 0xFF8E9B95;
        static final int BG = 0xFF050807;
        static final int CARD = 0xFF0C1210;
        static final int BORDER = 0xFF1B2822;
        static final int IMAGE_PLACEHOLDER = 0xFF17211C;
    }

    @Override protected void onPause() {
        if (bannerAdView != null) bannerAdView.pause();
        super.onPause();
    }

    @Override protected void onResume() {
        super.onResume();
        if (bannerAdView != null) bannerAdView.resume();
    }

}
