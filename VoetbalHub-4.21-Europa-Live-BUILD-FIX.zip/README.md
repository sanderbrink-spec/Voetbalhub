# VoetbalHub 4.20

- Version code: 53
- Removed the non-working European live fixtures/standings section from the home page and the in-app scores page.
- Kept the KNVB Cup fixture section and external score-source links.
- Added immersive full-screen display; system bars can be temporarily revealed by swiping from the screen edge.
- Existing news sources and app features retained.

## Build

Push this project to your GitHub repository and run the existing GitHub Actions workflow to build the APK.

**Note:** Android compilation and on-device testing have not been run in this environment.
