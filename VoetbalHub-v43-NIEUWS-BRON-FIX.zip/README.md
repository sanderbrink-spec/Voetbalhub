VoetbalHub versie 4.10 (versionCode 43)

Deze versie voegt Google Nieuws RSS toe als aanvullende bron voor nieuws van VI, VoetbalPrimeur en VoetbalNieuws. De statusregel toont nu de publicatietijd van het nieuwste artikel in plaats van alleen de tijd waarop de app feeds ophaalde.

Build via GitHub Actions met de workflow in .github/workflows/build.yml. De ZIP is gecontroleerd op integriteit, maar in deze omgeving is geen Android-build uitgevoerd.
