VoetbalHub Android project
Version: 4.11 (versionCode 44)

Fixes in this version:
- Google News fallback query is restricted to the last day and requests date sorting.
- News cards hide the image area unless a valid image successfully loads, preventing large blank blocks.
- Article sorting and the newest-article status use parsed publication timestamps rather than string sorting.

Build using the repository's GitHub Actions workflow. The Android build has not been run locally in this environment.
