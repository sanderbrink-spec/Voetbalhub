# VoetbalHub 4.13

- Version code: 46
- Intro uses the bundled VoetbalHub stadium artwork locally, including Flashscore in place of Google News and no “Europa” heading.
- Source tiles have the neon glow shown in the artwork.
- Intro stays fully visible for 3 seconds, then fades out.
- The splash image is bundled in `app/src/main/res/drawable-nodpi/intro_splash.png`; it does not depend on internet access.

Build using the repository GitHub Actions workflow. The Android build has not been run locally.
