# VoetbalHub v37 - UI verbeteringen

Compactere wedstrijdkaarten, eigen donker menu, aangepaste zoekdialoog en vernieuwde bronlijst. VersionName 4.4.
