# VoetbalHub

VoetbalHub is an Android voetbalnieuws-app met een donkere, professionele interface.

## Build

GitHub Actions bouwt de debug-APK met Java 17 en Gradle 8.9.

## Belangrijk

- Nieuws wordt via RSS geladen.
- Artikelen openen in een ingebouwde WebView binnen VoetbalHub.
- Nieuwskaarten tonen afbeeldingen wanneer de feed een afbeeldings-URL levert.
- Favoriete clubs worden lokaal opgeslagen.
- De APK wordt als GitHub Actions artifact gepubliceerd.
