plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "nl.voetbalhub.app"
    compileSdk = 35
    compileOptions {\n        sourceCompatibility = JavaVersion.VERSION_17\n        targetCompatibility = JavaVersion.VERSION_17\n    }\n    kotlinOptions {\n        jvmTarget = "17"\n    }\n    defaultConfig {
        applicationId = "nl.voetbalhub.app"
        minSdk = 24
        targetSdk = 35
        versionCode = 50
        versionName = "5.0"
    }
}
