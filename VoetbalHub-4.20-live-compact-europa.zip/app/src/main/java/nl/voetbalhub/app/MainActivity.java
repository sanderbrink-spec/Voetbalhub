package nl.voetbalhub.app;

import android.annotation.SuppressLint;
import android.animation.ValueAnimator;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Html;
import android.text.TextUtils;
import android.util.Xml;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import android.widget.FrameLayout;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.*;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.LoadAdError;
import android.util.Log;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;

import androidx.appcompat.app.AlertDialog;
import androidx.browser.customtabs.CustomTabsIntent;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import org.xmlpull.v1.XmlPullParser;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {
    private static class Article {
        final String title, link, source, date, imageUrl;

        Article(String title, String link, String source, String date, String imageUrl) {
            this.title = title;
            this.link = link;
            this.source = source;
            this.date = date;
            this.imageUrl = imageUrl == null ? "" : imageUrl;
        }
    }

    private final ExecutorService executor = Executors.newFixedThreadPool(4);
    private final Handler main = new Handler(Looper.getMainLooper());
    private final List<Article> articles = new ArrayList<>();
    private final List<Article> shown = new ArrayList<>();
    private final String[] feedNames = {"VI", "VoetbalPrimeur", "VoetbalNieuws"};
    // Alleen rechtstreekse feeds van de drie voetbaluitgevers; geen Google Nieuws.
    private final String[] feedUrls = {
            "https://www.vi.nl/feed/news.xml",
            "https://www.voetbalprimeur.nl/feed/news.xml",
            "https://www.voetbalnieuws.nl/feed/news.xml"
    };
    private String active = "Voor jou";
    private boolean loading = false;
    private int articleDisplayLimit = 20;
    private boolean articleOpen = false;
    private WebView activeWebView;
    private Dialog articleDialog;
    private FrameLayout content;
    private LinearLayout chips, nav;
    private SharedPreferences prefs;
    private AdView bannerAdView;
    private final Runnable periodicRefresh = new Runnable() {
        @Override public void run() {
            refreshNews();
            main.postDelayed(this, 10 * 60 * 1000L);
        }
    };
    private long lastRefresh = 0L;
    private String newsStatusMessage = "";
    private boolean scoresPageVisible = false;
    private Runnable dailyScoresReset;

    private void initializeAds() {
        // Mobile Ads SDK initialization is asynchronous. The banner is kept separate
        // from the bottom navigation so it cannot cover app controls.
        MobileAds.initialize(this, initializationStatus -> {
            FrameLayout adContainer = findViewById(R.id.adContainer);
            if (adContainer == null || isFinishing()) return;
            bannerAdView = new AdView(this);
            // Google's official test banner ID: guarantees a visible test ad while debugging.
            // Replace with the production ad-unit ID only after the test banner is confirmed.
            bannerAdView.setAdUnitId("ca-app-pub-3940256099942544/6300978111");
            bannerAdView.setAdSize(AdSize.BANNER);
            bannerAdView.setAdListener(new AdListener() {
                @Override public void onAdLoaded() {
                    Log.d("VoetbalHubAds", "Test banner loaded successfully");
                    adContainer.setVisibility(View.VISIBLE);
                }
                @Override public void onAdFailedToLoad(LoadAdError error) {
                    Log.e("VoetbalHubAds", "Banner failed: " + error.getCode() + " / " + error.getMessage());
                    Toast.makeText(MainActivity.this, "Testadvertentie laden mislukt (" + error.getCode() + ")", Toast.LENGTH_LONG).show();
                }
            });
            adContainer.removeAllViews();
            adContainer.addView(bannerAdView, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.CENTER));
            bannerAdView.loadAd(new AdRequest.Builder().build());
        });
    }

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // Google-banner tijdelijk verborgen op verzoek; advertentiecode blijft beschikbaar.
        View adContainer = findViewById(R.id.adContainer);
        if (adContainer != null) adContainer.setVisibility(View.GONE);
        content = findViewById(R.id.content);
        chips = findViewById(R.id.chips);
        nav = findViewById(R.id.nav);
        View header = findViewById(R.id.header);
        ViewCompat.setOnApplyWindowInsetsListener(header, (v, insets) -> {
            int top = insets.getInsets(WindowInsetsCompat.Type.statusBars()).top;
            v.setPadding(v.getPaddingLeft(), top, v.getPaddingRight(), v.getPaddingBottom());
            ViewGroup.LayoutParams lp = v.getLayoutParams();
            lp.height = dp(64) + top;
            v.setLayoutParams(lp);
            return insets;
        });
        ViewCompat.setOnApplyWindowInsetsListener(nav, (v, insets) -> {
            int bottom = insets.getInsets(WindowInsetsCompat.Type.navigationBars()).bottom;
            int extra = dp(10);
            v.setPadding(v.getPaddingLeft(), dp(4), v.getPaddingRight(), bottom + extra);
            ViewGroup.LayoutParams lp = v.getLayoutParams();
            lp.height = dp(76) + bottom;
            v.setLayoutParams(lp);
            return insets;
        });
        ViewCompat.requestApplyInsets(header);
        ViewCompat.requestApplyInsets(nav);
        prefs = getSharedPreferences("voethub", MODE_PRIVATE);
        lastRefresh = prefs.getLong("lastRefresh", 0L);
        loadCachedArticles();
        buildChips();
        buildNav();
        findViewById(R.id.logo).setOnClickListener(v -> { active = "Voor jou"; articleDisplayLimit = 20; buildChips(); showNews(); });
        findViewById(R.id.title).setOnClickListener(v -> { active = "Voor jou"; articleDisplayLimit = 20; buildChips(); showNews(); });
        findViewById(R.id.search).setOnClickListener(v -> showSearch());
        findViewById(R.id.settings).setOnClickListener(v -> showSettings());
        showNews();
        refreshNews();
        main.postDelayed(periodicRefresh, 10 * 60 * 1000L);
        showIntro();
    }

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    private TextView tv(String text, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setIncludeFontPadding(false);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private void buildChips() {
        chips.removeAllViews();
        String[] labels = {"Voor jou", "Laatste nieuws", "Transfers", "Eredivisie", "Buitenland", "Video"};
        for (String label : labels) {
            TextView b = tv(label, 13, label.equals(active) ? C.BG : C.TEXT, false);
            b.setGravity(Gravity.CENTER);
            b.setPadding(dp(13), 0, dp(13), 0);
            b.setBackground(ContextCompat.getDrawable(this, label.equals(active) ? R.drawable.rounded_active : R.drawable.rounded_chip));
            b.setOnClickListener(v -> {
                active = label;
                articleDisplayLimit = 20;
                buildChips();
                if (label.equals("Video")) showVideos(); else showNews();
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, dp(34));
            lp.setMargins(0, 0, dp(8), 0);
            chips.addView(b, lp);
        }
    }

    private void buildNav() {
        nav.removeAllViews();
        String[][] items = {{"⌂", "Nieuws"}, {"▣", "Uitslagen"}, {"◉", "Competities"}, {"★", "Favorieten"}, {"☰", "Meer"}};
        for (int i = 0; i < items.length; i++) {
            final String page = items[i][1];
            final int index = i;
            LinearLayout box = new LinearLayout(this);
            box.setOrientation(LinearLayout.VERTICAL);
            box.setGravity(Gravity.CENTER);
            box.setClickable(true);
            box.addView(tv(items[i][0], 21, index == 0 ? C.GREEN : C.MUTED, true), new LinearLayout.LayoutParams(-1, dp(28)));
            box.addView(tv(page, 10, index == 0 ? C.GREEN : C.MUTED, index == 0), new LinearLayout.LayoutParams(-1, dp(18)));
            box.setOnClickListener(v -> {
                switch (page) {
                    case "Nieuws": active = "Voor jou"; articleDisplayLimit = 20; buildChips(); showNews(); break;
                    case "Uitslagen": showScores(); break;
                    case "Competities": showCompetitions(); break;
                    case "Favorieten": showFavorites(); break;
                    default: showMore();
                }
            });
            nav.addView(box, new LinearLayout.LayoutParams(0, -1, 1));
        }
    }

    private LinearLayout sectionHeader(String title, String action, final Runnable click) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(16), dp(10), dp(16), dp(10));
        row.addView(tv(title, 22, C.TEXT, true), new LinearLayout.LayoutParams(0, dp(40), 1));
        if (action != null) {
            TextView a = tv(action, 12, C.GREEN, true);
            a.setGravity(Gravity.CENTER);
            a.setOnClickListener(v -> { if (click != null) click.run(); });
            row.addView(a, new LinearLayout.LayoutParams(dp(90), dp(36)));
        }
        return row;
    }

    private LinearLayout sectionHeader(String title) { return sectionHeader(title, null, null); }

    private void showNews() {
        articleOpen = false;
        activeWebView = null;
        content.removeAllViews();
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.addView(sectionHeader("Laatste voetbalnieuws", "VERVERS", this::refreshNews));
        TextView status = tv(loading ? "Nieuws wordt bijgewerkt…" : (!newsStatusMessage.isEmpty() ? newsStatusMessage : "Live RSS  •  VI  •  VoetbalPrimeur  •  VoetbalNieuws" + (lastRefresh > 0 ? "  •  " + formatLastRefresh() : "")), 11, C.MUTED, false);
        status.setPadding(dp(16), 0, dp(16), dp(10));
        root.addView(status);
        ScrollView scroll = new ScrollView(this);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(16), 0, dp(16), dp(24));
        if (active.equals("Voor jou") || active.equals("Eredivisie")) {
            addEredivisieLiveBlock(list);
            if (active.equals("Voor jou")) {
                addDailyFixtureSection(list, "EUROPA · LIVE WEDSTRIJDEN EN NEDERLANDSE CLUBS", new String[]{
                        "https://site.api.espn.com/apis/site/v2/sports/soccer/uefa.champions/scoreboard",
                        "https://site.api.espn.com/apis/site/v2/sports/soccer/uefa.europa/scoreboard",
                        "https://site.api.espn.com/apis/site/v2/sports/soccer/uefa.europa.conf/scoreboard"
                }, false);
            }
        }
        List<Article> filtered = filterArticles(active);
        shown.clear(); shown.addAll(filtered);
        if (filtered.isEmpty()) {
            list.addView(tv("Nog geen nieuws geladen. Tik op VERVERS.", 15, C.MUTED, false), new LinearLayout.LayoutParams(-1, dp(60)));
        } else {
            int visibleCount = Math.min(articleDisplayLimit, filtered.size());
            for (int i = 0; i < visibleCount; i++) addArticleCard(list, filtered.get(i), i == 0 && active.equals("Voor jou"));
            if (visibleCount < filtered.size()) {
                TextView more = tv("MEER LADEN  ·  " + Math.min(20, filtered.size() - visibleCount) + " BERICHTEN", 13, C.GREEN, true);
                more.setGravity(Gravity.CENTER);
                more.setPadding(dp(12), dp(16), dp(12), dp(16));
                more.setBackground(cardBackground());
                LinearLayout.LayoutParams moreLp = new LinearLayout.LayoutParams(-1, -2);
                moreLp.setMargins(0, dp(8), 0, dp(12));
                list.addView(more, moreLp);
                more.setOnClickListener(v -> {
                    int previousScrollY = scroll.getScrollY();
                    articleDisplayLimit += 20;
                    showNews();
                    main.post(() -> {
                        if (content != null && content.getChildCount() > 0 && content.getChildAt(0) instanceof LinearLayout) {
                            LinearLayout page = (LinearLayout) content.getChildAt(0);
                            for (int child = 0; child < page.getChildCount(); child++) {
                                if (page.getChildAt(child) instanceof ScrollView) {
                                    ((ScrollView) page.getChildAt(child)).scrollTo(0, previousScrollY);
                                    break;
                                }
                            }
                        }
                    });
                });
            } else if (filtered.size() > 20) {
                list.addView(tv("Alle beschikbare berichten geladen", 11, C.MUTED, false));
            }
        }
        scroll.addView(list);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        content.addView(root);
    }


    /** Live Eredivisieblok met aftraptijd, status en wedstrijdminuut uit de scoreboardfeed. */
    private void addEredivisieLiveBlock(LinearLayout parent) {
        LinearLayout block = new LinearLayout(this);
        block.setOrientation(LinearLayout.VERTICAL);
        block.setPadding(dp(10), dp(7), dp(10), dp(7));
        block.setBackground(cardBackground());

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = tv("LIVE EREDIVISIE", 16, C.TEXT, true);
        header.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        TextView refresh = tv("↻  VERVERS", 12, C.GREEN, true);
        header.addView(refresh);
        block.addView(header);

        TextView hint = tv("LIVE SCORES VAN VANDAAG", 10, C.MUTED, true);
        hint.setPadding(0, dp(4), 0, dp(2));
        block.addView(hint);
        LinearLayout matches = new LinearLayout(this);
        matches.setOrientation(LinearLayout.VERTICAL);
        block.addView(matches);
        TextView nextDayToggle = tv("", 12, C.GREEN, true);
        nextDayToggle.setPadding(0, dp(8), 0, 0);
        nextDayToggle.setVisibility(View.GONE);
        block.addView(nextDayToggle);
        TextView more = tv("ALLE UITSLAGEN  ›", 12, C.GREEN, true);
        more.setPadding(0, dp(10), 0, 0);
        more.setOnClickListener(v -> showScores());
        block.addView(more);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(2), 0, dp(7));
        parent.addView(block, 0, lp);

        Runnable load = () -> {
            hint.setVisibility(View.VISIBLE);
            hint.setText("Wedstrijden en tijden bijwerken…");
            matches.removeAllViews();
            executor.execute(() -> {
                final List<String[]> rows = new ArrayList<>();
                String error = null;
                HttpURLConnection c = null;
                try {
                    URL url = new URL("https://site.api.espn.com/apis/site/v2/sports/soccer/ned.1/scoreboard");
                    c = (HttpURLConnection) url.openConnection();
                    c.setRequestMethod("GET");
                    c.setRequestProperty("Cache-Control", "no-cache");
                    c.setConnectTimeout(8000);
                    c.setReadTimeout(8000);
                    c.setRequestProperty("User-Agent", "VoetbalHub/2.8 Android");
                    try (InputStream in = c.getInputStream(); java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream()) {
                        byte[] buffer = new byte[4096]; int n;
                        while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
                        JSONObject json = new JSONObject(out.toString("UTF-8"));
                        JSONArray events = json.optJSONArray("events");
                        if (events != null) {
                            // Toon op het beginscherm alleen vandaag. Als er vandaag geen wedstrijd is,
                            // selecteer de eerstvolgende speeldag maar houd die standaard ingeklapt.
                            String todayKey = todayKey();
                            String selectedMatchDay = "";
                            String firstFutureDay = "";
                            boolean hasToday = false;
                            for (int i = 0; i < events.length(); i++) {
                                JSONObject candidate = events.optJSONObject(i);
                                if (candidate == null) continue;
                                String candidateDay = localDayKey(candidate.optString("date", ""));
                                if (candidateDay.isEmpty()) continue;
                                if (candidateDay.equals(todayKey)) { hasToday = true; selectedMatchDay = todayKey; break; }
                                if (candidateDay.compareTo(todayKey) > 0 && (firstFutureDay.isEmpty() || candidateDay.compareTo(firstFutureDay) < 0)) firstFutureDay = candidateDay;
                            }
                            if (!hasToday) selectedMatchDay = firstFutureDay;
                            for (int i = 0; i < events.length() && rows.size() < 12; i++) {
                                JSONObject event = events.optJSONObject(i);
                                if (event == null) continue;
                                String eventDate = event.optString("date", "");
                                String eventDay = localDayKey(eventDate);
                                if (!selectedMatchDay.isEmpty() && !selectedMatchDay.equals(eventDay)) continue;
                                JSONArray comps = event.optJSONArray("competitions");
                                if (comps == null || comps.length() == 0) continue;
                                JSONObject comp = comps.optJSONObject(0);
                                JSONArray competitors = comp == null ? null : comp.optJSONArray("competitors");
                                if (competitors == null || competitors.length() < 2) continue;
                                JSONObject a = competitors.optJSONObject(0), b = competitors.optJSONObject(1);
                                JSONObject at = a == null ? null : a.optJSONObject("team");
                                JSONObject bt = b == null ? null : b.optJSONObject("team");
                                String home = at == null ? "Thuis" : at.optString("displayName", at.optString("shortDisplayName", "Thuis"));
                                String away = bt == null ? "Uit" : bt.optString("displayName", bt.optString("shortDisplayName", "Uit"));
                                String homeLogo = at == null ? "" : at.optString("logo", "");
                                String awayLogo = bt == null ? "" : bt.optString("logo", "");
                                String hs = a == null ? "–" : a.optString("score", "–");
                                String as = b == null ? "–" : b.optString("score", "–");
                                JSONObject status = event.optJSONObject("status");
                                JSONObject type = status == null ? null : status.optJSONObject("type");
                                String state = type == null ? "" : type.optString("state", "");
                                String statusName = type == null ? "" : type.optString("name", "");
                                String statusDetail = type == null ? "" : type.optString("detail", "");
                                String statusShortDetail = type == null ? "" : type.optString("shortDetail", "");
                                String statusText = (statusName + " " + statusDetail + " " + statusShortDetail).toLowerCase(java.util.Locale.ROOT);
                                boolean halftime = "halftime".equalsIgnoreCase(state)
                                        || statusText.contains("halftime") || statusText.contains("half-time")
                                        || statusText.contains("rust") || statusText.contains("interval");
                                boolean completed = "post".equalsIgnoreCase(state) || (type != null && type.optBoolean("completed", false));
                                if (!"in".equalsIgnoreCase(state) && !completed && !halftime) { hs = "–"; as = "–"; }
                                String label;
                                String kickoff = formatKickoff(event.optString("date", ""));
                                if (halftime) {
                                    // ESPN may keep state='in' and the clock at 45+ added time while its detail says Halftime.
                                    label = "RUST · HALF-TIME";
                                } else if (completed) {
                                    label = "AFGELOPEN";
                                } else if ("in".equalsIgnoreCase(state)) {
                                    String clock = status == null ? "" : status.optString("displayClock", "");
                                    int period = status == null ? 0 : status.optInt("period", 0);
                                    if (!clock.isEmpty() && !"0:00".equals(clock)) {
                                        String minute = clock.contains(":") ? clock.substring(0, clock.indexOf(':')) : clock;
                                        label = (period >= 2 ? "2E HELFT · " : "LIVE · ") + minute + "'";
                                    } else {
                                        label = period >= 2 ? "2E HELFT" : "LIVE";
                                    }
                                } else {
                                    label = kickoff.isEmpty() ? "AFTRAPTIJD ONBEKEND" : kickoff;
                                }
                                rows.add(new String[]{home, hs, as, away, label, eventDate, homeLogo, awayLogo, event.optString("id", "")});
                            }
                        }
                    }
                    if (rows.isEmpty()) error = "Geen Eredivisie-wedstrijden gevonden. Probeer later opnieuw.";
                } catch (Exception ex) {
                    error = "Live standen tijdelijk niet beschikbaar. Controleer je internetverbinding.";
                } finally { if (c != null) c.disconnect(); }
                final String errorMessage = error;
                main.post(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    matches.removeAllViews();
                    if (errorMessage != null) {
                        hint.setText(errorMessage);
                        return;
                    }
                    boolean hasScheduledOrLive = false;
                    boolean selectedDayIsToday = !rows.isEmpty() && todayKey().equals(localDayKey(rows.get(0)[5]));
                    for (String[] r : rows) if (!"AFGELOPEN".equals(r[4])) { hasScheduledOrLive = true; break; }
                    if (!rows.isEmpty() && !selectedDayIsToday) {
                        hint.setText("Vandaag geen wedstrijden · volgende speeldag ingeklapt");
                        matches.setVisibility(View.GONE);
                        nextDayToggle.setVisibility(View.VISIBLE);
                        nextDayToggle.setText("▸  VOLGENDE SPEELDAG TONEN · " + formatDayLabel(localDayKey(rows.get(0)[5])));
                        nextDayToggle.setOnClickListener(v -> {
                            boolean open = matches.getVisibility() != View.VISIBLE;
                            matches.setVisibility(open ? View.VISIBLE : View.GONE);
                            nextDayToggle.setText((open ? "▾  VOLGENDE SPEELDAG VERBERGEN · " : "▸  VOLGENDE SPEELDAG TONEN · ") + formatDayLabel(localDayKey(rows.get(0)[5])));
                        });
                    } else {
                        nextDayToggle.setVisibility(View.GONE);
                        matches.setVisibility(View.VISIBLE);
                        hint.setText(hasScheduledOrLive ? "Scores en wedstrijdstatus · tik op een wedstrijd voor details bij ESPN" : "Vandaag geen komende Eredivisie-wedstrijden");
                    }
                    if (!hasScheduledOrLive && !rows.isEmpty() && selectedDayIsToday) {
                        TextView togglePlayed = tv("▸  GESPEELDE WEDSTRIJDEN TONEN (" + rows.size() + ")", 11, C.GREEN, true);
                        togglePlayed.setGravity(Gravity.CENTER_VERTICAL); togglePlayed.setPadding(dp(8), dp(8), dp(8), dp(8));
                        matches.setVisibility(View.GONE);
                        togglePlayed.setOnClickListener(v -> { boolean open = matches.getVisibility() != View.VISIBLE; matches.setVisibility(open ? View.VISIBLE : View.GONE); togglePlayed.setText((open ? "▾" : "▸") + "  GESPEELDE WEDSTRIJDEN " + (open ? "VERBERGEN" : "TONEN") + " (" + rows.size() + ")"); });
                        block.addView(togglePlayed, block.indexOfChild(matches) + 1);
                    } else if (selectedDayIsToday) {
                        matches.setVisibility(View.VISIBLE);
                    }
                    for (String[] row : rows) {
                        boolean live = row[4].contains("LIVE") || row[4].contains("HELFT") || row[4].equals("RUST");
                        boolean finished = row[4].equals("AFGELOPEN");
                        LinearLayout match = new LinearLayout(this);
                        match.setOrientation(LinearLayout.VERTICAL);
                        match.setPadding(dp(10), dp(6), dp(10), dp(5));
                        GradientDrawable bg = new GradientDrawable();
                        bg.setColor(C.BG); bg.setCornerRadius(dp(16)); bg.setStroke(dp(1), C.BORDER);
                        match.setBackground(bg);
                        match.setClickable(true); match.setFocusable(true);
                        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(-1, -2);
                        mp.setMargins(0, dp(6), 0, dp(2));

                        LinearLayout statusRow = new LinearLayout(this);
                        statusRow.setGravity(Gravity.CENTER);
                        TextView statusText = tv(row[4], 10, live ? C.GREEN : (finished ? C.MUTED : C.TEXT), true);
                        statusText.setGravity(Gravity.CENTER);
                        if (live) {
                            statusText.setPadding(dp(8), dp(3), dp(8), dp(3));
                            GradientDrawable liveBg = new GradientDrawable();
                            liveBg.setColor(0x2225F06B); liveBg.setCornerRadius(dp(20)); liveBg.setStroke(dp(1), C.GREEN);
                            statusText.setBackground(liveBg);
                        }
                        statusRow.addView(statusText);
                        match.addView(statusRow);

                        LinearLayout teams = new LinearLayout(this);
                        teams.setGravity(Gravity.CENTER_VERTICAL);
                        teams.setPadding(0, dp(6), 0, dp(6));
                        LinearLayout homeColumn = new LinearLayout(this);
                        homeColumn.setOrientation(LinearLayout.VERTICAL); homeColumn.setGravity(Gravity.CENTER);
                        FrameLayout homeLogoFrame = new FrameLayout(this);
                        ImageView homeLogoImage = new ImageView(this);
                        homeLogoImage.setScaleType(ImageView.ScaleType.FIT_CENTER);
                        TextView homeBadge = tv(teamInitials(row[0]), 14, C.GREEN, true); homeBadge.setGravity(Gravity.CENTER);
                        GradientDrawable hb = new GradientDrawable(); hb.setColor(0xFF14251C); hb.setCornerRadius(dp(28)); hb.setStroke(dp(1), C.BORDER);
                        homeBadge.setBackground(hb); homeBadge.setPadding(dp(8), dp(8), dp(8), dp(8));
                        homeLogoFrame.addView(homeBadge, new FrameLayout.LayoutParams(dp(42), dp(42), Gravity.CENTER));
                        homeLogoFrame.addView(homeLogoImage, new FrameLayout.LayoutParams(dp(42), dp(42), Gravity.CENTER));
                        homeColumn.addView(homeLogoFrame, new LinearLayout.LayoutParams(dp(46), dp(46)));
                        loadTeamLogo(homeLogoImage, row.length > 6 ? row[6] : "", homeBadge);
                        TextView homeText = tv(row[0], 13, C.TEXT, true); homeText.setGravity(Gravity.CENTER); homeText.setMaxLines(2);
                        homeText.setPadding(0, dp(5), 0, 0); homeColumn.addView(homeText);
                        teams.addView(homeColumn, new LinearLayout.LayoutParams(0, -2, 1));

                        LinearLayout scoreColumn = new LinearLayout(this);
                        scoreColumn.setOrientation(LinearLayout.VERTICAL); scoreColumn.setGravity(Gravity.CENTER);
                        TextView scoreText = tv(row[1] + "  –  " + row[2], 21, C.TEXT, true); scoreText.setGravity(Gravity.CENTER);
                        scoreColumn.addView(scoreText);
                        TextView detailText = tv("Details ↗", 9, C.MUTED, true); detailText.setGravity(Gravity.CENTER);
                        detailText.setPadding(0, dp(5), 0, 0); scoreColumn.addView(detailText);
                        teams.addView(scoreColumn, new LinearLayout.LayoutParams(dp(112), -2));

                        LinearLayout awayColumn = new LinearLayout(this);
                        awayColumn.setOrientation(LinearLayout.VERTICAL); awayColumn.setGravity(Gravity.CENTER);
                        FrameLayout awayLogoFrame = new FrameLayout(this);
                        ImageView awayLogoImage = new ImageView(this);
                        awayLogoImage.setScaleType(ImageView.ScaleType.FIT_CENTER);
                        TextView awayBadge = tv(teamInitials(row[3]), 14, C.GREEN, true); awayBadge.setGravity(Gravity.CENTER);
                        GradientDrawable ab = new GradientDrawable(); ab.setColor(0xFF14251C); ab.setCornerRadius(dp(28)); ab.setStroke(dp(1), C.BORDER);
                        awayBadge.setBackground(ab); awayBadge.setPadding(dp(8), dp(8), dp(8), dp(8));
                        awayLogoFrame.addView(awayBadge, new FrameLayout.LayoutParams(dp(42), dp(42), Gravity.CENTER));
                        awayLogoFrame.addView(awayLogoImage, new FrameLayout.LayoutParams(dp(42), dp(42), Gravity.CENTER));
                        awayColumn.addView(awayLogoFrame, new LinearLayout.LayoutParams(dp(46), dp(46)));
                        loadTeamLogo(awayLogoImage, row.length > 7 ? row[7] : "", awayBadge);
                        TextView awayText = tv(row[3], 13, C.TEXT, true); awayText.setGravity(Gravity.CENTER); awayText.setMaxLines(2);
                        awayText.setPadding(0, dp(5), 0, 0); awayColumn.addView(awayText);
                        teams.addView(awayColumn, new LinearLayout.LayoutParams(0, -2, 1));
                        match.addView(teams);
                        match.setOnClickListener(v -> openEspnMatch(row.length > 8 ? row[8] : "", row[0], row[3]));
                        matches.addView(match, mp);
                    }
                });
            });
        };
        refresh.setOnClickListener(v -> load.run());
        load.run();
    }


    private void loadTeamLogo(ImageView target, String logoUrl, View fallback) {
        if (logoUrl == null || logoUrl.trim().isEmpty()) return;
        target.setVisibility(View.INVISIBLE);
        executor.execute(() -> {
            HttpURLConnection connection = null;
            try {
                connection = (HttpURLConnection) new URL(logoUrl).openConnection();
                connection.setConnectTimeout(5000);
                connection.setReadTimeout(5000);
                connection.setRequestProperty("User-Agent", "VoetbalHub/2.9 Android");
                try (InputStream input = connection.getInputStream()) {
                    Bitmap bitmap = BitmapFactory.decodeStream(input);
                    if (bitmap != null) main.post(() -> {
                        if (target.getContext() != null) {
                            target.setImageBitmap(bitmap);
                            target.setVisibility(View.VISIBLE);
                            fallback.setVisibility(View.GONE);
                        }
                    });
                }
            } catch (Exception ignored) {
                // Bij een ontbrekend logo blijft de nette initialenbadge zichtbaar.
            } finally { if (connection != null) connection.disconnect(); }
        });
    }

    private String teamInitials(String team) {
        if (team == null || team.trim().isEmpty()) return "FC";
        String[] parts = team.trim().split("\\s+");
        if (parts.length == 1) return parts[0].substring(0, Math.min(3, parts[0].length())).toUpperCase(java.util.Locale.ROOT);
        return (parts[0].substring(0, 1) + parts[parts.length - 1].substring(0, 1)).toUpperCase(java.util.Locale.ROOT);
    }

    private String formatKickoff(String isoDate) {
        if (isoDate == null || isoDate.trim().isEmpty()) return "";
        java.time.ZoneId zone = java.time.ZoneId.of("Europe/Amsterdam");
        java.time.format.DateTimeFormatter timeFormat = java.time.format.DateTimeFormatter.ofPattern("HH:mm");
        try {
            return timeFormat.withZone(zone).format(java.time.Instant.parse(isoDate));
        } catch (Exception ignored) { }
        try {
            return timeFormat.withZone(zone).format(java.time.OffsetDateTime.parse(isoDate).toInstant());
        } catch (Exception ignored) { }
        try {
            return java.time.LocalDateTime.parse(isoDate).atZone(zone).format(timeFormat);
        } catch (Exception ignored) { }
        return "";
    }

    private int safeInt(String value) { try { return Integer.parseInt(value); } catch (Exception e) { return 0; } }

    /** Open the exact ESPN match page using the event ID from the scoreboard feed. */
    private void openEspnMatch(String eventId, String home, String away) {
        try {
            if (eventId != null && eventId.matches("[0-9]+")) {
                Uri uri = Uri.parse("https://www.espn.com/soccer/match/_/gameId/" + eventId);
                openArticle(uri.toString(), "ESPN wedstrijd");
            } else {
                // The feed did not provide an event ID, so open ESPN soccer scores rather than a misleading Google search.
                openArticle("https://www.espn.com/soccer/scoreboard", "ESPN uitslagen");
                Toast.makeText(this, "De directe wedstrijdlink is niet beschikbaar; ESPN-scores zijn geopend.", Toast.LENGTH_LONG).show();
            }
        } catch (Exception e) {
            Toast.makeText(this, "De wedstrijd kan niet worden geopend. Probeer het later opnieuw.", Toast.LENGTH_LONG).show();
        }
    }

    private GradientDrawable cardBackground() {
        GradientDrawable g = new GradientDrawable();
        g.setColor(C.CARD);
        g.setCornerRadius(dp(18));
        g.setStroke(dp(1), C.BORDER);
        return g;
    }

    private void addArticleCard(LinearLayout list, Article a, boolean hero) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(10), dp(10), dp(10), dp(12));
        card.setClickable(true);
        card.setBackground(cardBackground());
        card.setOnClickListener(v -> openArticle(a.link, a.title));

        ImageView image = new ImageView(this);
        image.setScaleType(ImageView.ScaleType.CENTER_CROP);
        image.setBackgroundColor(C.IMAGE_PLACEHOLDER);
        image.setTag(a.imageUrl);
        int imageHeight = hero ? dp(190) : dp(125);
        // Never reserve a large blank image block when the feed has no usable image.
        image.setVisibility(View.GONE);
        card.addView(image, new LinearLayout.LayoutParams(-1, imageHeight));
        loadArticleImage(image, a.imageUrl);

        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(4), dp(9), dp(4), 0);

        LinearLayout sourceRow = new LinearLayout(this);
        sourceRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView source = tv(a.source.toUpperCase(Locale.getDefault()), 9, C.GREEN, true);
        sourceRow.addView(source, new LinearLayout.LayoutParams(0, dp(20), 1));
        TextView date = tv(formatDate(a.date), 9, C.MUTED, false);
        sourceRow.addView(date, new LinearLayout.LayoutParams(-2, dp(20)));
        TextView bookmark = tv(isArticleSaved(a.link) ? "★" : "☆", 20, isArticleSaved(a.link) ? C.GREEN : C.MUTED, true);
        bookmark.setGravity(Gravity.CENTER);
        bookmark.setContentDescription(isArticleSaved(a.link) ? "Verwijder uit bewaarde artikelen" : "Bewaar artikel");
        bookmark.setOnClickListener(v -> {
            toggleSavedArticle(a.link);
            bookmark.setText(isArticleSaved(a.link) ? "★" : "☆");
            bookmark.setTextColor(isArticleSaved(a.link) ? C.GREEN : C.MUTED);
            bookmark.setContentDescription(isArticleSaved(a.link) ? "Verwijder uit bewaarde artikelen" : "Bewaar artikel");
            Toast.makeText(this, isArticleSaved(a.link) ? "Artikel bewaard" : "Artikel verwijderd uit bewaard", Toast.LENGTH_SHORT).show();
        });
        LinearLayout.LayoutParams bookmarkLp = new LinearLayout.LayoutParams(dp(32), dp(28));
        bookmarkLp.setMargins(dp(6), 0, 0, 0);
        sourceRow.addView(bookmark, bookmarkLp);
        body.addView(sourceRow);

        TextView title = tv(a.title, hero ? 18 : 15, C.TEXT, true);
        title.setMaxLines(hero ? 4 : 3);
        title.setEllipsize(TextUtils.TruncateAt.END);
        title.setPadding(0, dp(5), 0, dp(6));
        body.addView(title);
        body.addView(tv("Lees bij de oorspronkelijke uitgever  ›", 10, C.MUTED, false));
        card.addView(body);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, dp(10));
        list.addView(card, lp);
    }

    private void loadArticleImage(ImageView target, String imageUrl) {
        if (imageUrl == null || imageUrl.trim().isEmpty()) return;
        executor.execute(() -> {
            Bitmap bitmap = null;
            try {
                URL u = new URL(imageUrl);
                HttpURLConnection c = (HttpURLConnection) u.openConnection();
                c.setConnectTimeout(7000);
                c.setReadTimeout(7000);
                c.setInstanceFollowRedirects(true);
                c.setRequestProperty("User-Agent", "VoetbalHub/2.3");
                c.connect();
                if (c.getResponseCode() >= 200 && c.getResponseCode() < 400) {
                    bitmap = BitmapFactory.decodeStream(c.getInputStream());
                }
                c.disconnect();
            } catch (Exception ignored) { }
            final Bitmap result = bitmap;
            if (result != null) {
                main.post(() -> {
                    Object tag = target.getTag();
                    if (imageUrl.equals(tag)) {
                        target.setImageBitmap(result);
                        target.setVisibility(View.VISIBLE);
                    }
                });
            }
        });
    }

    private String formatDate(String raw) {
        if (raw == null || raw.trim().isEmpty()) return "";
        long timestamp = articleTimestamp(raw);
        if (timestamp > 0L) return android.text.format.DateFormat.format("EEE, dd MMM HH:mm", new Date(timestamp)).toString();
        String x = raw.trim();
        return x.length() > 24 ? x.substring(0, 24) : x;
    }

    private List<Article> filterArticles(String category) {
        List<Article> base = new ArrayList<>(articles);
        Collections.sort(base, (a, b) -> Long.compare(articleTimestamp(b.date), articleTimestamp(a.date)));
        if (category.equals("Transfers")) return filter(base, "transfer|transferv|deal|akkoord|vertrekt|tekent|contract");
        if (category.equals("Eredivisie")) return filter(base, "Ajax|PSV|Feyenoord|Groningen|AZ|Twente|Utrecht|Heerenveen|NEC|Sparta|Eredivisie|RKC|Go Ahead|Fortuna|PEC|NAC|Volendam|Heracles");
        if (category.equals("Buitenland")) return filter(base, "Premier League|La Liga|Barcelona|Real Madrid|Liverpool|Arsenal|Manchester|Bayern|Dortmund|Serie A|Milan|Inter|PSG|Champions League");
        return base;
    }

    private List<Article> filter(List<Article> base, String regex) {
        List<Article> r = new ArrayList<>();
        for (Article a : base) if (a.title.matches("(?i).*?(" + regex + ").*")) r.add(a);
        return r;
    }

    private void refreshNews() {
        if (loading) return;
        loading = true;
        showNews();
        executor.execute(() -> {
            List<Article> fresh = new ArrayList<>();
            List<String> failedFeeds = new ArrayList<>();
            for (int i = 0; i < feedUrls.length; i++) {
                try {
                    List<Article> parsed = parseFeed(feedNames[i], feedUrls[i]);
                    if (parsed.isEmpty()) failedFeeds.add(feedNames[i]);
                    fresh.addAll(parsed);
                } catch (Exception ex) { failedFeeds.add(feedNames[i]); }
            }
            LinkedHashMap<String, Article> unique = new LinkedHashMap<>();
            for (Article a : fresh) {
                String key = a.link == null || a.link.isEmpty() ? a.title.toLowerCase(Locale.ROOT) : a.link;
                if (!unique.containsKey(key)) unique.put(key, a);
            }
            // Merge new feed items with previously cached items so older articles remain available.
            for (Article oldArticle : articles) {
                String key = oldArticle.link == null || oldArticle.link.isEmpty() ? oldArticle.title.toLowerCase(Locale.ROOT) : oldArticle.link;
                if (!unique.containsKey(key)) unique.put(key, oldArticle);
            }
            fresh = new ArrayList<>(unique.values());
            Collections.sort(fresh, (a, b) -> Long.compare(articleTimestamp(b.date), articleTimestamp(a.date)));
            if (fresh.size() > 300) fresh = new ArrayList<>(fresh.subList(0, 300));
            final List<Article> resultArticles = fresh;
            final List<String> failed = failedFeeds;
            main.post(() -> {
                if (!resultArticles.isEmpty()) {
                    articles.clear();
                    articles.addAll(resultArticles);
                    saveCachedArticles(resultArticles);
                    lastRefresh = System.currentTimeMillis();
                    prefs.edit().putLong("lastRefresh", lastRefresh).apply();
                    String newest = newestArticleDate(resultArticles);
                    newsStatusMessage = failed.isEmpty()
                            ? "Feeds opgehaald · nieuwste artikel: " + newest
                            : "Nieuws deels opgehaald · nieuwste artikel: " + newest;
                } else {
                    newsStatusMessage = articles.isEmpty() ? "Geen nieuws ontvangen. Controleer internet en tik op VERVERS." : "Vernieuwen mislukt · opgeslagen nieuws wordt getoond. Tik opnieuw op VERVERS.";
                }
                loading = false;
                showNews();
            });
        });
    }

    private String newestArticleDate(List<Article> items) {
        if (items == null || items.isEmpty()) return "onbekend";
        long timestamp = articleTimestamp(items.get(0).date);
        if (timestamp > 0L) return android.text.format.DateFormat.format("dd-MM HH:mm", new Date(timestamp)).toString();
        String date = items.get(0).date == null ? "" : items.get(0).date.trim();
        return date.isEmpty() ? "datum onbekend" : (date.length() > 22 ? date.substring(0, 22) : date);
    }

    private long articleTimestamp(String raw) {
        if (raw == null || raw.trim().isEmpty()) return 0L;
        String value = raw.trim();
        String[] patterns = {
                "EEE, dd MMM yyyy HH:mm:ss Z", "EEE, dd MMM yyyy HH:mm:ss zzz",
                "EEE, dd MMM yyyy HH:mm Z", "yyyy-MM-dd'T'HH:mm:ssXXX",
                "yyyy-MM-dd'T'HH:mm:ss'Z'", "yyyy-MM-dd'T'HH:mm:ss.SSSXXX",
                "yyyy-MM-dd'T'HH:mm:ssZ", "yyyy-MM-dd HH:mm:ss"
        };
        for (String pattern : patterns) {
            try {
                java.text.SimpleDateFormat format = new java.text.SimpleDateFormat(pattern, Locale.ENGLISH);
                format.setLenient(true);
                format.setTimeZone(TimeZone.getDefault());
                Date parsed = format.parse(value);
                if (parsed != null) return parsed.getTime();
            } catch (Exception ignored) { }
        }
        return 0L;
    }

    private String joinNames(List<String> names) {
        StringBuilder out = new StringBuilder();
        for (String name : names) { if (out.length() > 0) out.append(", "); out.append(name); }
        return out.toString();
    }

    private void loadCachedArticles() {
        String raw = prefs.getString("articleCache", "");
        if (raw.isEmpty()) return;
        try {
            JSONArray arr = new JSONArray(raw);
            articles.clear();
            boolean removedOldGoogleItems = false;
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                String source = o.optString("source", "");
                String link = o.optString("link", "");
                if (source.toLowerCase(Locale.ROOT).contains("google") || link.toLowerCase(Locale.ROOT).contains("news.google.com")) {
                    removedOldGoogleItems = true;
                    continue;
                }
                articles.add(new Article(o.optString("title"), link, source, o.optString("date"), o.optString("imageUrl")));
            }
            if (removedOldGoogleItems) saveCachedArticles(articles);
        } catch (Exception ignored) { }
    }

    private void saveCachedArticles(List<Article> items) {
        try {
            JSONArray arr = new JSONArray();
            for (int i = 0; i < Math.min(items.size(), 300); i++) {
                Article a = items.get(i);
                JSONObject o = new JSONObject();
                o.put("title", a.title); o.put("link", a.link); o.put("source", a.source); o.put("date", a.date); o.put("imageUrl", a.imageUrl);
                arr.put(o);
            }
            prefs.edit().putString("articleCache", arr.toString()).apply();
        } catch (Exception ignored) { }
    }

    private String formatLastRefresh() {
        return android.text.format.DateFormat.format("HH:mm", new Date(lastRefresh)).toString();
    }

    private List<Article> parseFeed(String source, String url) throws Exception {
        List<Article> result = new ArrayList<>();
        XmlPullParser parser = Xml.newPullParser();
        // Force a fresh HTTP request. Some feed/CDN responses otherwise remain cached
        // and the app silently keeps the previous midnight snapshot.
        String freshUrl = url + (url.contains("?") ? "&" : "?") + "_vh=" + System.currentTimeMillis();
        URL u = new URL(freshUrl);
        java.net.URLConnection c = u.openConnection();
        c.setUseCaches(false);
        c.setConnectTimeout(15000); c.setReadTimeout(15000);
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 16) AppleWebKit/537.36 Chrome/130 Mobile Safari/537.36 VoetbalHub/4.9");
        c.setRequestProperty("Cache-Control", "no-cache, no-store, max-age=0");
        c.setRequestProperty("Pragma", "no-cache");
        c.setRequestProperty("Accept", "application/rss+xml, application/atom+xml, application/xml, text/xml, */*");
        try (InputStream feedStream = c.getInputStream()) { parser.setInput(feedStream, null);
        boolean inside = false;
        String title = "", link = "", date = "", imageUrl = "";
        int event = parser.getEventType();
        while (event != XmlPullParser.END_DOCUMENT) {
            String name = parser.getName() == null ? "" : parser.getName();
            String lower = name.toLowerCase(Locale.ROOT);
            if (event == XmlPullParser.START_TAG && (lower.equals("item") || lower.equals("entry"))) inside = true;
            if (inside && event == XmlPullParser.START_TAG) {
                if (lower.equals("title")) { title = nextText(parser); }
                else if (lower.equals("link")) {
                    String href = parser.getAttributeValue(null, "href");
                    link = href != null ? href : nextText(parser);
                } else if (lower.equals("pubdate") || lower.equals("published") || lower.equals("updated") || lower.equals("dc:date")) {
                    date = nextText(parser);
                } else if (lower.equals("media:content") || lower.equals("media:thumbnail") || lower.equals("enclosure") || lower.equals("image")) {
                    String type = parser.getAttributeValue(null, "type");
                    String medium = parser.getAttributeValue(null, "medium");
                    String urlAttr = parser.getAttributeValue(null, "url");
                    if (urlAttr != null && (imageUrl.isEmpty() || "image".equalsIgnoreCase(medium) || (type != null && type.toLowerCase(Locale.ROOT).startsWith("image/")))) imageUrl = urlAttr;
                }
            }
            if (inside && event == XmlPullParser.END_TAG && (lower.equals("item") || lower.equals("entry"))) {
                if (!title.isEmpty() && link.startsWith("https://")) result.add(new Article(clean(title), link, source, date, imageUrl));
                title = ""; link = ""; date = ""; imageUrl = ""; inside = false;
            }
            event = parser.next();
        }
        }
        return result;
    }

    private String nextText(XmlPullParser parser) throws Exception {
        String value = parser.nextText();
        return value == null ? "" : value.trim();
    }

    private String clean(String s) { return s.replaceAll("\\s+", " ").trim(); }

    private void openArticle(String url, String title) {
        if (url == null || !(url.startsWith("https://") || url.startsWith("http://"))) {
            Toast.makeText(this, "Deze link is niet geldig", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            if (articleDialog != null && articleDialog.isShowing()) articleDialog.dismiss();
            articleOpen = true;
            articleDialog = new Dialog(this);
            LinearLayout page = new LinearLayout(this);
            page.setOrientation(LinearLayout.VERTICAL);
            page.setBackgroundColor(android.graphics.Color.rgb(5, 12, 9));

            LinearLayout toolbar = new LinearLayout(this);
            toolbar.setOrientation(LinearLayout.HORIZONTAL);
            toolbar.setGravity(Gravity.CENTER_VERTICAL);
            toolbar.setPadding(dp(12), dp(6), dp(12), dp(6));
            toolbar.setBackgroundColor(android.graphics.Color.rgb(5, 12, 9));

            TextView close = tv("‹  TERUG NAAR VOETBALHUB", 14, C.TEXT, true);
            close.setGravity(Gravity.CENTER_VERTICAL);
            close.setPadding(dp(6), dp(8), dp(12), dp(8));
            close.setOnClickListener(v -> closeArticleView());
            toolbar.addView(close, new LinearLayout.LayoutParams(-2, dp(48)));

            TextView pageTitle = tv(title == null ? "Nieuwsartikel" : title, 13, C.MUTED, false);
            pageTitle.setMaxLines(1);
            pageTitle.setEllipsize(TextUtils.TruncateAt.END);
            toolbar.addView(pageTitle, new LinearLayout.LayoutParams(0, dp(48), 1));
            page.addView(toolbar, new LinearLayout.LayoutParams(-1, -2));

            activeWebView = new WebView(this);
            activeWebView.getSettings().setJavaScriptEnabled(true);
            activeWebView.getSettings().setDomStorageEnabled(true);
            activeWebView.setWebChromeClient(new WebChromeClient());
            activeWebView.setWebViewClient(new WebViewClient() {
                @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                    return false; // Keep navigation inside this viewer; app back/close returns directly to VoetbalHub.
                }
            });
            page.addView(activeWebView, new LinearLayout.LayoutParams(-1, 0, 1));
            articleDialog.setContentView(page);
            android.view.Window window = articleDialog.getWindow();
            if (window != null) {
                window.setBackgroundDrawableResource(android.R.color.transparent);
                window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
            }
            articleDialog.setOnDismissListener(d -> {
                if (activeWebView != null) {
                    activeWebView.stopLoading();
                    activeWebView.destroy();
                    activeWebView = null;
                }
                articleOpen = false;
            });
            articleDialog.show();
            if (articleDialog.getWindow() != null) articleDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
            activeWebView.loadUrl(url);
        } catch (Exception e) {
            articleOpen = false;
            activeWebView = null;
            try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
            catch (Exception ignored) { Toast.makeText(this, "Artikel openen is niet gelukt", Toast.LENGTH_LONG).show(); }
        }
    }

    private void closeArticleView() {
        if (articleDialog != null && articleDialog.isShowing()) articleDialog.dismiss();
        else {
            articleOpen = false;
            activeWebView = null;
            showNews();
        }
    }

    private void shareArticle(String url) {
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_TEXT, url);
        startActivity(Intent.createChooser(send, "Deel artikel"));
    }

    private void showIntro() {
        // Premium VoetbalHub splash with a real, animated 3-second loading bar.
        final FrameLayout overlay = new FrameLayout(this);
        overlay.setBackgroundColor(C.BG);
        overlay.setElevation(dp(50));
        overlay.setClickable(true);
        overlay.setFocusable(true);

        ImageView splash = new ImageView(this);
        splash.setImageResource(R.drawable.intro_splash);
        splash.setScaleType(ImageView.ScaleType.FIT_XY);
        splash.setContentDescription("VoetbalHub: alle voetbalbronnen op één plek");
        overlay.addView(splash, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        LinearLayout loader = new LinearLayout(this);
        loader.setOrientation(LinearLayout.VERTICAL);
        loader.setGravity(Gravity.CENTER_HORIZONTAL);
        loader.setPadding(dp(28), dp(12), dp(28), dp(8));
        loader.setBackgroundColor(0x12020805);

        TextView status = tv("VOETBALHUB WORDT GESTART", 11, 0xFFE1F5E8, true);
        status.setLetterSpacing(0.12f);
        status.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams statusLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(22));
        statusLp.bottomMargin = dp(10);
        loader.addView(status, statusLp);

        LinearLayout progressRow = new LinearLayout(this);
        progressRow.setOrientation(LinearLayout.HORIZONTAL);
        progressRow.setGravity(Gravity.CENTER_VERTICAL);
        IntroProgressView progressBar = new IntroProgressView(this);
        LinearLayout.LayoutParams barLp = new LinearLayout.LayoutParams(0, dp(12), 1f);
        barLp.rightMargin = dp(12);
        progressRow.addView(progressBar, barLp);

        TextView percent = tv("0%", 16, C.TEXT, true);
        percent.setGravity(Gravity.CENTER_VERTICAL | Gravity.RIGHT);
        percent.setMinWidth(dp(42));
        progressRow.addView(percent, new LinearLayout.LayoutParams(dp(48), dp(28)));
        loader.addView(progressRow, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(30)));

        FrameLayout.LayoutParams loaderLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        loaderLp.leftMargin = dp(8);
        loaderLp.rightMargin = dp(8);
        loaderLp.bottomMargin = dp(76);
        overlay.addView(loader, loaderLp);

        addContentView(overlay, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        ValueAnimator loadingAnimator = ValueAnimator.ofInt(0, 100);
        loadingAnimator.setDuration(3000L);
        loadingAnimator.setInterpolator(new LinearInterpolator());
        loadingAnimator.addUpdateListener(animation -> {
            int value = (Integer) animation.getAnimatedValue();
            progressBar.setProgress(value / 100f);
            percent.setText(value + "%");
        });
        loadingAnimator.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override public void onAnimationEnd(android.animation.Animator animation) {
                if (isFinishing() || isDestroyed()) {
                    ViewParentHelper.remove(overlay);
                    return;
                }
                status.setText("KLAAR OM AF TE TRAPPEN");
                overlay.animate()
                        .alpha(0f)
                        .setDuration(250L)
                        .setInterpolator(new DecelerateInterpolator())
                        .withEndAction(() -> ViewParentHelper.remove(overlay))
                        .start();
            }
        });
        overlay.setAlpha(1f);
        overlay.post(loadingAnimator::start);
    }

    /** Rounded neon progress track with a soft green glow. */
    private final class IntroProgressView extends View {
        private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private float progress = 0f;

        IntroProgressView(android.content.Context context) {
            super(context);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            track.setColor(0xCC17271E);
            track.setStyle(Paint.Style.FILL);
            glow.setColor(C.GREEN);
            glow.setStyle(Paint.Style.FILL);
            glow.setShadowLayer(dp(7), 0, 0, 0xCC25F06B);
            fill.setColor(0xFF25F06B);
            fill.setStyle(Paint.Style.FILL);
        }

        void setProgress(float value) {
            progress = Math.max(0f, Math.min(1f, value));
            invalidate();
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float h = getHeight();
            float radius = h / 2f;
            float right = getWidth();
            RectF full = new RectF(0, 1, right, h - 1);
            canvas.drawRoundRect(full, radius, radius, track);
            Paint border = new Paint(Paint.ANTI_ALIAS_FLAG);
            border.setStyle(Paint.Style.STROKE);
            border.setStrokeWidth(dp(1));
            border.setColor(0xFF78F6A2);
            canvas.drawRoundRect(full, radius, radius, border);
            if (progress > 0f) {
                float end = Math.max(h, right * progress);
                RectF glowRect = new RectF(1, 2, Math.min(right - 1, end), h - 2);
                canvas.drawRoundRect(glowRect, radius, radius, glow);
                canvas.drawRoundRect(glowRect, radius, radius, fill);
            }
        }
    }

    private static final class ViewParentHelper {
        static void remove(View view) {
            if (view.getParent() instanceof ViewGroup) {
                ((ViewGroup) view.getParent()).removeView(view);
            }
        }
    }

    /** Draws a moving neon highlight over the source cards in the splash artwork. */
    private static class IntroGlowView extends View {
        private final Paint glowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint corePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private ValueAnimator animator;
        private float progress;

        IntroGlowView(android.content.Context context) {
            super(context);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            setClickable(false);
            setFocusable(false);
            glowPaint.setStyle(Paint.Style.STROKE);
            corePaint.setStyle(Paint.Style.STROKE);
        }

        private float px(float value) { return value * getResources().getDisplayMetrics().density; }

        void startGlow() {
            if (animator != null) animator.cancel();
            animator = ValueAnimator.ofFloat(0f, 1f);
            animator.setDuration(3000L);
            animator.setRepeatCount(ValueAnimator.INFINITE);
            animator.addUpdateListener(a -> {
                progress = (Float) a.getAnimatedValue();
                invalidate();
            });
            animator.start();
        }

        void stopGlow() {
            if (animator != null) {
                animator.cancel();
                animator = null;
            }
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth(), h = getHeight();
            if (w <= 0 || h <= 0) return;

            // All source tiles pulse together. The six animated energy streams run
            // from the source tiles towards the central VoetbalHub emblem.
            float[][] cards = {
                    {0.38f, 0.315f, 0.62f, 0.415f}, // VI
                    {0.095f, 0.405f, 0.335f, 0.515f}, // ESPN
                    {0.665f, 0.405f, 0.905f, 0.515f}, // VoetbalPrimeur
                    {0.095f, 0.585f, 0.335f, 0.695f}, // UEFA
                    {0.665f, 0.585f, 0.905f, 0.695f}, // VoetbalNieuws
                    {0.38f, 0.665f, 0.62f, 0.775f}  // Flashscore
            };
            float hubX = w * 0.5f, hubY = h * 0.545f;
            float pulse = (float)(0.5 + 0.5 * Math.sin(progress * Math.PI * 2.0));

            // Persistent, subtle connection rails.
            Paint rail = new Paint(Paint.ANTI_ALIAS_FLAG);
            rail.setStyle(Paint.Style.STROKE);
            rail.setStrokeCap(Paint.Cap.ROUND);
            rail.setStrokeWidth(px(2.0f));
            rail.setColor(android.graphics.Color.argb(85, 0, 255, 112));
            rail.setShadowLayer(px(8), 0, 0, android.graphics.Color.argb(70, 0, 255, 100));
            for (float[] b : cards) {
                float sx = (b[0] + b[2]) * 0.5f * w;
                float sy = (b[1] + b[3]) * 0.5f * h;
                canvas.drawLine(sx, sy, hubX, hubY, rail);
            }

            // Each card gets the same breathing neon outline, like a charging dashboard.
            for (float[] b : cards) {
                RectF r = new RectF(b[0] * w, b[1] * h, b[2] * w, b[3] * h);
                int alpha = (int)(115 + 105 * pulse);
                glowPaint.setColor(android.graphics.Color.argb(alpha, 0, 255, 112));
                glowPaint.setStrokeWidth(px(2.5f + 1.1f * pulse));
                glowPaint.setShadowLayer(px(12 + 13 * pulse), 0, 0,
                        android.graphics.Color.argb((int)(130 + 100 * pulse), 0, 255, 95));
                canvas.drawRoundRect(r, px(22), px(22), glowPaint);
                corePaint.setColor(android.graphics.Color.argb((int)(70 + 90 * pulse), 110, 255, 165));
                corePaint.setStrokeWidth(px(1.2f));
                corePaint.clearShadowLayer();
                canvas.drawRoundRect(r, px(22), px(22), corePaint);
            }

            // Bright energy pulses travel from every source into the central hub at once.
            Paint stream = new Paint(Paint.ANTI_ALIAS_FLAG);
            stream.setStyle(Paint.Style.STROKE);
            stream.setStrokeCap(Paint.Cap.ROUND);
            stream.setStrokeWidth(px(3.0f));
            stream.setColor(android.graphics.Color.argb((int)(150 + 100 * pulse), 45, 255, 130));
            stream.setShadowLayer(px(15), 0, 0, android.graphics.Color.argb(230, 0, 255, 110));
            Paint charge = new Paint(Paint.ANTI_ALIAS_FLAG);
            charge.setStyle(Paint.Style.FILL);
            charge.setColor(android.graphics.Color.WHITE);
            charge.setShadowLayer(px(15), 0, 0, android.graphics.Color.rgb(0, 255, 110));
            for (float[] b : cards) {
                float sx = (b[0] + b[2]) * 0.5f * w;
                float sy = (b[1] + b[3]) * 0.5f * h;
                // The illuminated segment length grows and contracts as energy is transferred.
                float t = 0.28f + 0.62f * progress;
                canvas.drawLine(sx, sy, sx + (hubX - sx) * t, sy + (hubY - sy) * t, stream);
                float dotT = progress;
                float dx = sx + (hubX - sx) * dotT;
                float dy = sy + (hubY - sy) * dotT;
                canvas.drawCircle(dx, dy, px(4.0f + 2.2f * pulse), charge);
            }

            // Central emblem receives the charge and gently brightens.
            Paint hub = new Paint(Paint.ANTI_ALIAS_FLAG);
            hub.setStyle(Paint.Style.STROKE);
            hub.setColor(android.graphics.Color.argb((int)(125 + 115 * pulse), 0, 255, 110));
            hub.setStrokeWidth(px(2.5f + 1.3f * pulse));
            hub.setShadowLayer(px(22), 0, 0, android.graphics.Color.argb((int)(150 + 100 * pulse), 0, 255, 100));
            float radius = Math.min(w, h) * (0.115f + 0.006f * pulse);
            canvas.drawCircle(hubX, hubY, radius, hub);
        }
    }

    private void showVideos() {
        scoresPageVisible = false;
        content.removeAllViews();
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.addView(sectionHeader("Voetbalvideo", "VERVERS", this::showVideos));
        TextView sub = tv("Video's blijven binnen VoetbalHub beschikbaar.", 12, C.MUTED, false);
        sub.setPadding(dp(16), 0, dp(16), dp(12)); root.addView(sub);
        ScrollView scroll = new ScrollView(this);
        LinearLayout list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); list.setPadding(dp(16), 0, dp(16), dp(24));
        String[][] videos = {{"VI Video", "https://www.youtube.com/results?search_query=Voetbal+International+VI+Video"}, {"VoetbalPrimeur Video", "https://www.youtube.com/results?search_query=VoetbalPrimeur"}, {"Voetbalzone Video", "https://www.youtube.com/results?search_query=Voetbalzone+voetbal"}};
        for (String[] v : videos) {
            LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setGravity(Gravity.CENTER_VERTICAL); card.setPadding(dp(18), dp(18), dp(18), dp(18)); card.setBackground(cardBackground()); card.setOnClickListener(x -> openArticle(v[1], v[0]));
            card.addView(tv("▶", 28, C.GREEN, true));
            TextView t = tv(v[0], 18, C.TEXT, true); t.setPadding(0, dp(8), 0, dp(4)); card.addView(t);
            card.addView(tv("Afspelen binnen de app  ›", 12, C.MUTED, false));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(120)); lp.setMargins(0, 0, 0, dp(12)); list.addView(card, lp);
        }
        scroll.addView(list); root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1)); content.addView(root);
    }

    private void showScores() {
        scoresPageVisible = true;
        scheduleScoresMidnightReset();
        content.removeAllViews();
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.addView(sectionHeader("Uitslagen & programma", "VERVERS", this::showScores));
        ScrollView scroll = new ScrollView(this);
        LinearLayout list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); list.setPadding(dp(16), dp(8), dp(16), dp(24));
        TextView intro = tv("Wedstrijden per dag. Nederlandse clubs in Europa en de KNVB Beker vanaf de kwartfinale.", 13, C.MUTED, false);
        intro.setPadding(dp(2), 0, dp(2), dp(12)); list.addView(intro);
        addDailyFixtureSection(list, "NEDERLANDSE CLUBS IN EUROPA", new String[]{
                "https://site.api.espn.com/apis/site/v2/sports/soccer/uefa.champions/scoreboard",
                "https://site.api.espn.com/apis/site/v2/sports/soccer/uefa.europa/scoreboard",
                "https://site.api.espn.com/apis/site/v2/sports/soccer/uefa.europa.conf/scoreboard"
        }, false);
        addDailyFixtureSection(list, "KNVB BEKER · VANAF KWARTFINALE", new String[]{
                "https://site.api.espn.com/apis/site/v2/sports/soccer/ned.cup/scoreboard"
        }, true);
        TextView sourcesTitle = tv("MEER UITSLAGENBRONNEN", 12, C.GREEN, true);
        sourcesTitle.setPadding(0, dp(18), 0, dp(8)); list.addView(sourcesTitle);
        addSiteCard(list, "Flashscore", "Live scores, statistieken en opstellingen", "https://www.flashscore.nl/", "https://www.google.com/s2/favicons?domain=flashscore.nl&sz=128");
        addSiteCard(list, "VI wedstrijdcentrum", "Live uitslagen en wedstrijden", "https://www.vi.nl/wedstrijden", "https://www.vi.nl/favicon.ico");
        addSiteCard(list, "Eredivisie", "Programma en uitslagen", "https://eredivisie.nl/competitie/wedstrijden/", "https://www.google.com/s2/favicons?domain=eredivisie.nl&sz=128");
        addSiteCard(list, "UEFA", "Europese wedstrijden", "https://www.uefa.com/uefachampionsleague/fixtures-results/", "https://www.google.com/s2/favicons?domain=uefa.com&sz=128");
        addSiteCard(list, "Premier League", "Wedstrijden en uitslagen", "https://www.premierleague.com/fixtures", "https://www.google.com/s2/favicons?domain=premierleague.com&sz=128");
        addSiteCard(list, "La Liga", "Wedstrijden en uitslagen", "https://www.laliga.com/en-GB/laliga-easports/results", "https://www.google.com/s2/favicons?domain=laliga.com&sz=128");
        scroll.addView(list); root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1)); content.addView(root);
    }

    private void scheduleScoresMidnightReset() {
        if (dailyScoresReset != null) main.removeCallbacks(dailyScoresReset);
        java.util.Calendar now = java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("Europe/Amsterdam"));
        java.util.Calendar next = (java.util.Calendar) now.clone();
        next.add(java.util.Calendar.DAY_OF_YEAR, 1);
        next.set(java.util.Calendar.HOUR_OF_DAY, 0);
        next.set(java.util.Calendar.MINUTE, 0);
        next.set(java.util.Calendar.SECOND, 1);
        next.set(java.util.Calendar.MILLISECOND, 0);
        long delay = Math.max(1000L, next.getTimeInMillis() - now.getTimeInMillis());
        dailyScoresReset = () -> {
            if (scoresPageVisible && !isFinishing() && !isDestroyed()) showScores();
        };
        main.postDelayed(dailyScoresReset, delay);
    }

    private void addDailyFixtureSection(LinearLayout parent, String title, String[] endpoints, boolean cupOnlyQuarterFinal) {
        LinearLayout section = new LinearLayout(this);
        section.setOrientation(LinearLayout.VERTICAL);
        section.setPadding(dp(10), dp(8), dp(10), dp(7));
        section.setBackground(cardBackground());
        LinearLayout.LayoutParams sectionLp = new LinearLayout.LayoutParams(-1, -2);
        sectionLp.setMargins(0, 0, 0, dp(7));
        parent.addView(section, sectionLp);
        TextView heading = tv(title, 13, C.GREEN, true);
        heading.setPadding(0, 0, 0, dp(4));
        section.addView(heading);
        TextView status = tv("Wedstrijden laden…", 13, C.MUTED, false);
        section.addView(status);
        executor.execute(() -> {
            final Map<String, List<String[]>> byDay = new TreeMap<>();
            boolean anyEndpointSucceeded = false;
            for (String endpoint : endpoints) {
                HttpURLConnection conn = null;
                try {
                    // ESPN's default scoreboard window can omit future fixtures. Request a rolling
                    // 30-day window so Dutch clubs' European fixtures are available and can be grouped by local day.
                    java.time.LocalDate rangeStart = java.time.LocalDate.now(java.time.ZoneId.of("Europe/Amsterdam"));
                    java.time.LocalDate rangeEnd = rangeStart.plusDays(30);
                    java.time.format.DateTimeFormatter espnDate = java.time.format.DateTimeFormatter.BASIC_ISO_DATE;
                    String dateRange = rangeStart.format(espnDate) + "-" + rangeEnd.format(espnDate);
                    String separator = endpoint.contains("?") ? "&" : "?";
                    URL url = new URL(endpoint + separator + "dates=" + dateRange + "&_vh=" + System.currentTimeMillis());
                    conn = (HttpURLConnection) url.openConnection();
                    conn.setConnectTimeout(9000); conn.setReadTimeout(9000);
                    conn.setUseCaches(false);
                    conn.setRequestProperty("Cache-Control", "no-cache");
                    conn.setRequestProperty("User-Agent", "VoetbalHub/4.15 Android");
                    try (InputStream in = conn.getInputStream(); java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream()) {
                        byte[] buffer = new byte[4096]; int n;
                        while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
                        JSONObject json = new JSONObject(out.toString("UTF-8"));
                        anyEndpointSucceeded = true;
                        JSONArray events = json.optJSONArray("events");
                        if (events == null) continue;
                        for (int i = 0; i < events.length(); i++) {
                            JSONObject event = events.optJSONObject(i); if (event == null) continue;
                            JSONArray comps = event.optJSONArray("competitions");
                            JSONObject comp = comps == null || comps.length() == 0 ? null : comps.optJSONObject(0);
                            JSONArray teams = comp == null ? null : comp.optJSONArray("competitors");
                            if (teams == null || teams.length() < 2) continue;
                            JSONObject a = teams.optJSONObject(0), b = teams.optJSONObject(1);
                            JSONObject ta = a == null ? null : a.optJSONObject("team");
                            JSONObject tb = b == null ? null : b.optJSONObject("team");
                            String home = ta == null ? "" : ta.optString("displayName", "");
                            String away = tb == null ? "" : tb.optString("displayName", "");
                            if (cupOnlyQuarterFinal) {
                                String stage = getCupStageText(event, comp, json);
                                if (!(stage.contains("quarterfinal") || stage.contains("quarter-final") || stage.contains("quarter final") || stage.contains("kwartfinale") || stage.contains("semi-final") || stage.contains("semifinal") || stage.contains("final"))) continue;
                            } else if (title.toLowerCase(java.util.Locale.ROOT).contains("knvb")) {
                                // The European section keeps all matches from its European endpoints.
                                // This avoids missing Dutch clubs when ESPN returns a different team alias.
                            }
                            String date = event.optString("date", "");
                            if (date.length() < 10) continue;
                            String day = localDayKey(date);
                            if (day.isEmpty()) continue;
                            // On the news home screen the live Europe panel is for today's matches only.
                            if (title.toUpperCase(java.util.Locale.ROOT).contains("LIVE WEDSTRIJDEN") && !day.equals(todayKey())) continue;
                            String kickoff = formatKickoff(date);
                            JSONObject eventStatus = event.optJSONObject("status");
                            JSONObject type = eventStatus == null ? null : eventStatus.optJSONObject("type");
                            String state = type == null ? "" : type.optString("state", "");
                            String statusName = type == null ? "" : type.optString("name", "");
                            String statusDetail = type == null ? "" : type.optString("detail", "");
                            String statusText = (statusName + " " + statusDetail).toLowerCase(java.util.Locale.ROOT);
                            boolean halftime = "halftime".equalsIgnoreCase(state) || statusText.contains("half-time") || statusText.contains("halftime") || statusText.contains("rust") || statusText.contains("interval");
                            boolean completed = "post".equalsIgnoreCase(state) || (type != null && type.optBoolean("completed", false));
                            String scoreA = a == null ? "–" : a.optString("score", "–");
                            String scoreB = b == null ? "–" : b.optString("score", "–");
                            String liveLabel = "";
                            if (halftime) liveLabel = "RUST · HALF-TIME";
                            else if (completed) liveLabel = "AFGELOPEN";
                            else if ("in".equalsIgnoreCase(state)) {
                                String clock = eventStatus == null ? "" : eventStatus.optString("displayClock", "");
                                int period = eventStatus == null ? 0 : eventStatus.optInt("period", 0);
                                String minute = clock.contains(":") ? clock.substring(0, clock.indexOf(':')) : clock;
                                liveLabel = (period >= 2 ? "2E HELFT · " : "LIVE · ") + (minute.isEmpty() || "0".equals(minute) ? "" : minute + "'");
                            } else { scoreA = "–"; scoreB = "–"; }
                            String competitionName = comp == null ? "" : comp.optString("name", "");
                            final String fKickoff = kickoff, fHome = home, fAway = away, fScoreA = scoreA, fScoreB = scoreB, fCompetitionName = competitionName, fLiveLabel = liveLabel;
                            byDay.computeIfAbsent(day, k -> new ArrayList<>()).add(new String[]{fKickoff, fHome, fScoreA, fScoreB, fAway, fCompetitionName, fLiveLabel});
                        }
                    }
                } catch (Exception ignored) {
                    // One competition feed may be temporarily unavailable; other feeds still render.
                } finally { if (conn != null) conn.disconnect(); }
            }
            final boolean succeeded = anyEndpointSucceeded;
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) return;
                section.removeAllViews();
                TextView newHeading = tv(title, 13, C.GREEN, true); newHeading.setPadding(0, 0, 0, dp(8)); section.addView(newHeading);
                if (byDay.isEmpty()) {
                    // Keep empty sections compact so days without fixtures do not dominate the page.
                    section.setPadding(dp(12), dp(8), dp(12), dp(8));
                    TextView empty = tv(succeeded ? "Geen wedstrijden gevonden." : "Wedstrijdgegevens tijdelijk niet beschikbaar.", 12, C.MUTED, false);
                    empty.setPadding(0, 0, 0, 0);
                    section.addView(empty);
                    return;
                }
                String today = todayKey();
                for (Map.Entry<String, List<String[]>> entry : byDay.entrySet()) {
                    final String dayKey = entry.getKey();
                    final List<String[]> games = entry.getValue();
                    String dateLabel = formatDayLabel(dayKey);
                    LinearLayout dayHeader = new LinearLayout(MainActivity.this);
                    dayHeader.setGravity(Gravity.CENTER_VERTICAL);
                    dayHeader.setPadding(dp(8), dp(9), dp(8), dp(9));
                    dayHeader.setBackgroundColor(0xFF14221B);
                    TextView dayTitle = tv(dateLabel + "  ·  " + games.size() + " wedstrijden", 13, C.TEXT, true);
                    dayHeader.addView(dayTitle, new LinearLayout.LayoutParams(0, -2, 1));
                    TextView arrow = tv(dayKey.equals(today) ? "⌄" : "›", 19, C.GREEN, true); dayHeader.addView(arrow);
                    LinearLayout gameList = new LinearLayout(MainActivity.this); gameList.setOrientation(LinearLayout.VERTICAL);
                    boolean expanded = dayKey.equals(today);
                    gameList.setVisibility(expanded ? View.VISIBLE : View.GONE);
                    for (String[] game : games) {
                        LinearLayout row = new LinearLayout(MainActivity.this); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(dp(4), dp(8), dp(4), dp(8));
                        row.setOrientation(LinearLayout.VERTICAL);
                        boolean dutchClubMatch = isDutchClub(game[1]) || isDutchClub(game[4]);
                        TextView scoreline = tv(game[0] + "   " + game[1] + "   " + game[2] + " - " + game[3] + "   " + game[4], 13, dutchClubMatch ? C.GREEN : C.TEXT, true);
                        row.addView(scoreline);
                        if (game.length > 6 && !game[6].isEmpty()) row.addView(tv(game[6], 11, game[6].contains("LIVE") || game[6].contains("HELFT") || game[6].contains("RUST") ? C.GREEN : C.MUTED, true));
                        if (!game[5].isEmpty()) row.addView(tv(game[5], 10, C.MUTED, false));
                        View line = new View(MainActivity.this); line.setBackgroundColor(0xFF1D2B24);
                        row.addView(line, new LinearLayout.LayoutParams(-1, dp(1)));
                        gameList.addView(row);
                    }
                    dayHeader.setOnClickListener(v -> {
                        boolean show = gameList.getVisibility() != View.VISIBLE;
                        gameList.setVisibility(show ? View.VISIBLE : View.GONE);
                        arrow.setText(show ? "⌄" : "›");
                    });
                    LinearLayout.LayoutParams dayLp = new LinearLayout.LayoutParams(-1, -2); dayLp.setMargins(0, dp(3), 0, 0);
                    section.addView(dayHeader, dayLp); section.addView(gameList);
                }
            });
        });
    }

    private String getCupStageText(JSONObject event, JSONObject competition, JSONObject scoreboard) {
        StringBuilder text = new StringBuilder();
        text.append(event.optString("name", " ")).append(' ')
            .append(event.optString("shortName", " ")).append(' ')
            .append(event.optString("seasonType", " ")).append(' ')
            .append(event.optString("week", " ")).append(' ');
        if (competition != null) {
            text.append(competition.optString("name", " ")).append(' ')
                .append(competition.optString("notes", " ")).append(' ');
            JSONArray notes = competition.optJSONArray("notes");
            if (notes != null) for (int i = 0; i < notes.length(); i++) {
                JSONObject note = notes.optJSONObject(i);
                if (note != null) text.append(note.optString("headline", " ")).append(' ');
            }
        }
        JSONObject season = scoreboard.optJSONObject("season");
        if (season != null) text.append(season.optString("name", " ")).append(' ');
        return text.toString().toLowerCase(java.util.Locale.ROOT);
    }

    private boolean isDutchClub(String team) {
        String t = team == null ? "" : team.toLowerCase(java.util.Locale.ROOT);
        String[] clubs = {"ajax", "psv", "feyenoord", "az alkmaar", "fc twente", "go ahead eagles", "fc utrecht", "fc groningen", "sc groningen", "sc heerenveen", "nec nijmegen", "sparta rotterdam", "heracles", "fortuna sittard", "pec zwolle", "nac breda", "willem ii", "rkc waalwijk", "fc volendam", "de graafschap", "cambuur", "ado den haag", "telstar", "excelsior", "almere city", "vitesse", "roda jc", "fc emmen", "helmond sport", "fc dordrecht", "top oss", "jong ajax", "jong psv", "jong az", "psv eindhoven", "feyenoord rotterdam", "ajax amsterdam", "fc twente enschede"};
        for (String club : clubs) if (t.contains(club)) return true;
        // ESPN sometimes names AZ simply "AZ" instead of "AZ Alkmaar".
        return t.matches(".*(^|[^a-z])az([^a-z]|$).*");
    }

    private String todayKey() {
        return java.time.LocalDate.now(java.time.ZoneId.of("Europe/Amsterdam")).toString();
    }

    /** Convert ESPN's UTC/offset timestamp to the Dutch local calendar day. */
    private String localDayKey(String isoDate) {
        if (isoDate == null || isoDate.trim().isEmpty()) return "";
        java.time.ZoneId zone = java.time.ZoneId.of("Europe/Amsterdam");
        try { return java.time.Instant.parse(isoDate).atZone(zone).toLocalDate().toString(); } catch (Exception ignored) { }
        try { return java.time.OffsetDateTime.parse(isoDate).atZoneSameInstant(zone).toLocalDate().toString(); } catch (Exception ignored) { }
        try { return java.time.LocalDateTime.parse(isoDate).atZone(zone).toLocalDate().toString(); } catch (Exception ignored) { }
        return isoDate.length() >= 10 ? isoDate.substring(0, 10) : "";
    }

    private String formatDayLabel(String day) {
        try {
            java.text.SimpleDateFormat input = new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.ROOT);
            input.setTimeZone(java.util.TimeZone.getTimeZone("Europe/Amsterdam"));
            java.util.Date d = input.parse(day);
            java.text.SimpleDateFormat output = new java.text.SimpleDateFormat("EEEE d MMMM", new java.util.Locale("nl", "NL"));
            output.setTimeZone(java.util.TimeZone.getTimeZone("Europe/Amsterdam"));
            String value = output.format(d);
            return value.substring(0, 1).toUpperCase(new java.util.Locale("nl", "NL")) + value.substring(1);
        } catch (Exception e) { return day; }
    }

    private void addAction(LinearLayout list, String title, String url) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(16), dp(13), dp(14), dp(13));
        card.setBackground(cardBackground());
        TextView label = tv(title, 15, C.TEXT, false);
        label.setGravity(Gravity.CENTER_VERTICAL);
        card.addView(label, new LinearLayout.LayoutParams(0, -2, 1));
        TextView arrow = tv("↗", 20, C.GREEN, true);
        arrow.setGravity(Gravity.CENTER);
        card.addView(arrow, new LinearLayout.LayoutParams(dp(28), dp(32)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, dp(9));
        list.addView(card, lp);
        card.setOnClickListener(v -> openUrl(url));
    }

    private void showCompetitions() {
        scoresPageVisible = false;
        content.removeAllViews(); LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.addView(sectionHeader("Competities"));
        LinearLayout list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); list.setPadding(dp(16), 0, dp(16), dp(24));
        String[][] c = {{"Eredivisie","https://eredivisie.nl/","eredivisie.nl"},{"Keuken Kampioen Divisie","https://keukenkampioendivisie.nl/","keukenkampioendivisie.nl"},{"Champions League","https://www.uefa.com/uefachampionsleague/","uefa.com"},{"Europa League","https://www.uefa.com/uefaeuropaleague/","uefa.com"},{"Conference League","https://www.uefa.com/uefaconferenceleague/","uefa.com"},{"Premier League","https://www.premierleague.com/","premierleague.com"},{"La Liga","https://www.laliga.com/","laliga.com"},{"Serie A","https://www.legaseriea.it/","legaseriea.it"},{"Bundesliga","https://www.bundesliga.com/","bundesliga.com"},{"Ligue 1","https://www.ligue1.com/","ligue1.com"}};
        for (String[] x : c) addSiteCard(list, x[0], "Officiële competitiepagina", x[1], "https://www.google.com/s2/favicons?domain=" + x[2] + "&sz=128");
        ScrollView scroll = new ScrollView(this); scroll.addView(list); root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1)); content.addView(root);
    }

    private Set<String> getSavedArticleLinks() {
        Set<String> stored = prefs.getStringSet("savedArticles", Collections.<String>emptySet());
        return new HashSet<>(stored);
    }

    private boolean isArticleSaved(String link) {
        return link != null && getSavedArticleLinks().contains(link);
    }

    private void toggleSavedArticle(String link) {
        Set<String> saved = getSavedArticleLinks();
        if (saved.contains(link)) saved.remove(link); else saved.add(link);
        prefs.edit().putStringSet("savedArticles", saved).apply();
    }

    private void showFavorites() {
        scoresPageVisible = false;
        content.removeAllViews(); LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.addView(sectionHeader("Favorieten"));
        ScrollView scroll = new ScrollView(this); LinearLayout list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); list.setPadding(dp(16), 0, dp(16), dp(24));
        TextView clubTitle = tv("JOUW CLUBS", 12, C.GREEN, true); clubTitle.setPadding(0, dp(8), 0, dp(10)); list.addView(clubTitle);
        Set<String> favs = new HashSet<>(prefs.getStringSet("clubs", Collections.<String>emptySet()));
        TextView h = tv(favs.isEmpty() ? "Kies je clubs om je voetbalnieuws persoonlijker te maken." : "Jouw selectie  ·  " + favs.size() + " clubs", 13, C.MUTED, false); h.setPadding(0, 0, 0, dp(12)); list.addView(h);
        String[] clubs = {"FC Groningen", "Ajax", "PSV", "Feyenoord", "AZ", "FC Twente", "SC Heerenveen", "FC Utrecht", "NEC", "Sparta Rotterdam", "Heracles Almelo", "Go Ahead Eagles", "Fortuna Sittard", "PEC Zwolle", "NAC Breda", "Willem II", "Real Madrid", "FC Barcelona", "Liverpool", "Arsenal", "Manchester City", "Bayern München"};
        for (final String club : clubs) {
            boolean favorite = favs.contains(club); LinearLayout card = new LinearLayout(this); card.setGravity(Gravity.CENTER_VERTICAL); card.setPadding(dp(14), 0, dp(12), 0); card.setBackground(cardBackground());
            ImageView crest = new ImageView(this); crest.setScaleType(ImageView.ScaleType.FIT_CENTER); crest.setPadding(dp(2), dp(2), dp(2), dp(2));
            GradientDrawable badge = new GradientDrawable(); badge.setColor(0xFF14251C); badge.setCornerRadius(dp(22)); crest.setBackground(badge); card.addView(crest, new LinearLayout.LayoutParams(dp(42), dp(42)));
            String crestUrl = favoriteClubLogo(club); if (crestUrl != null) loadSiteIcon(crest, crestUrl); else { TextView fallback = tv(clubInitials(club), 11, C.GREEN, true); fallback.setGravity(Gravity.CENTER); card.addView(fallback, 0, new LinearLayout.LayoutParams(dp(42), dp(42))); }
            TextView name = tv(club, 14, favorite ? C.GREEN : C.TEXT, favorite); name.setPadding(dp(12), 0, 0, 0); card.addView(name, new LinearLayout.LayoutParams(0, -2, 1)); card.addView(tv(favorite ? "★" : "+", 22, favorite ? C.GREEN : C.MUTED, true));
            card.setOnClickListener(v -> { Set<String> current = new HashSet<>(prefs.getStringSet("clubs", Collections.<String>emptySet())); if (current.contains(club)) current.remove(club); else current.add(club); prefs.edit().putStringSet("clubs", current).apply(); showFavorites(); });
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, dp(56)); cp.setMargins(0, 0, 0, dp(7)); list.addView(card, cp);
        }
        TextView savedTitle = tv("BEWAARDE ARTIKELEN", 12, C.GREEN, true); savedTitle.setPadding(0, dp(20), 0, dp(10)); list.addView(savedTitle);
        Set<String> savedLinks = getSavedArticleLinks(); int savedCount = 0;
        for (Article a : articles) if (savedLinks.contains(a.link)) { addArticleCard(list, a, false); savedCount++; }
        if (savedCount == 0) { TextView empty = tv("Nog geen artikelen bewaard. Tik op ☆ bij een nieuwsbericht om het hier terug te vinden.", 13, C.MUTED, false); empty.setPadding(0, 0, 0, dp(12)); list.addView(empty); }
        scroll.addView(list); root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1)); content.addView(root);
    }

    private String favoriteClubLogo(String club) {
        String[][] map = {
            {"FC Groningen","fcgroningen.nl"}, {"Ajax","ajax.nl"}, {"PSV","psv.nl"},
            {"Feyenoord","feyenoord.com"}, {"AZ","az.nl"}, {"FC Twente","fctwente.nl"},
            {"SC Heerenveen","sc-heerenveen.nl"}, {"FC Utrecht","fcutrecht.nl"}, {"NEC","nec-nijmegen.nl"},
            {"Sparta Rotterdam","sparta-rotterdam.nl"}, {"Heracles Almelo","heracles.nl"},
            {"Go Ahead Eagles","ga-eagles.nl"}, {"Fortuna Sittard","fortunasittard.nl"},
            {"PEC Zwolle","peczwolle.nl"}, {"NAC Breda","nac.nl"}, {"Willem II","willem-ii.nl"},
            {"Real Madrid","realmadrid.com"}, {"FC Barcelona","fcbarcelona.com"}, {"Liverpool","liverpoolfc.com"},
            {"Arsenal","arsenal.com"}, {"Manchester City","mancity.com"}, {"Bayern München","fcbayern.com"}
        };
        for (String[] item : map) if (item[0].equals(club)) return "https://www.google.com/s2/favicons?domain=" + item[1] + "&sz=128";
        return null;
    }

    private String clubInitials(String club) { String[] parts = club.split(" "); if (parts.length == 1) return club.substring(0, Math.min(3, club.length())).toUpperCase(Locale.ROOT); return (parts[0].substring(0,1) + parts[1].substring(0,1)).toUpperCase(Locale.ROOT); }

    private String join(Set<String> s, String sep) { StringBuilder b = new StringBuilder(); for (String x : s) { if (b.length() > 0) b.append(sep); b.append(x); } return b.toString(); }

    private void showMore() {
        content.removeAllViews();
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.addView(sectionHeader("Meer"));
        ScrollView scroll = new ScrollView(this);
        LinearLayout list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); list.setPadding(dp(16), dp(4), dp(16), dp(24));
        addSiteCard(list, "Flashscore", "Live scores, statistieken & wedstrijddetails", "https://www.flashscore.nl/", "https://www.google.com/s2/favicons?domain=flashscore.nl&sz=128");
        addSiteCard(list, "VI · Voetbal International", "Nieuws en wedstrijdcentrum", "https://www.vi.nl/", "https://www.vi.nl/favicon.ico");
        addSiteCard(list, "VoetbalPrimeur", "Laatste voetbalnieuws en transfers", "https://www.voetbalprimeur.nl/", "https://www.voetbalprimeur.nl/favicon.ico");
        addSiteCard(list, "VoetbalNieuws", "Nieuws uit binnen- en buitenland", "https://www.voetbalnieuws.nl/", "https://www.voetbalnieuws.nl/favicon.ico");
        addSiteCard(list, "Auteursrecht & bronnen", "Informatie over bronnen en gebruik", null, null);
        addSiteCard(list, "Feedback sturen", "Stuur een bericht aan VoetbalHub", "mailto:voetbalhub.app@gmail.com?subject=VoetbalHub%20feedback", null);
        TextView info = tv("VOETBALHUB  ·  Onafhankelijke voetbalnieuws-hub. Artikelen openen bij de oorspronkelijke uitgever.", 12, C.MUTED, false); info.setPadding(dp(4), dp(14), dp(4), 0); list.addView(info);
        scroll.addView(list); root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1)); content.addView(root);
    }

    private void addSiteCard(LinearLayout list, String title, String subtitle, String url, String iconUrl) {
        LinearLayout card = new LinearLayout(this); card.setGravity(Gravity.CENTER_VERTICAL); card.setPadding(dp(14), dp(11), dp(14), dp(11)); card.setBackground(cardBackground());
        ImageView icon = new ImageView(this); icon.setScaleType(ImageView.ScaleType.FIT_CENTER); icon.setImageResource(R.drawable.ic_launcher);
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(dp(42), dp(42)); ip.setMargins(0, 0, dp(13), 0); card.addView(icon, ip);
        if (iconUrl != null) loadSiteIcon(icon, iconUrl);
        LinearLayout textBox = new LinearLayout(this); textBox.setOrientation(LinearLayout.VERTICAL);
        textBox.addView(tv(title, 15, C.TEXT, true)); TextView sub = tv(subtitle, 11, C.MUTED, false); sub.setPadding(0, dp(4), 0, 0); textBox.addView(sub);
        card.addView(textBox, new LinearLayout.LayoutParams(0, -2, 1)); card.addView(tv("›", 24, C.GREEN, true));
        card.setOnClickListener(v -> { if (url == null) showLegalInfo(); else if (url.startsWith("mailto:")) { try { startActivity(new Intent(Intent.ACTION_SENDTO, Uri.parse(url))); } catch (Exception ignored) {} } else openArticle(url, title); });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, 0, 0, dp(10)); list.addView(card, lp);
    }

    private void loadSiteIcon(ImageView target, String iconUrl) {
        executor.execute(() -> { HttpURLConnection c = null; try { c = (HttpURLConnection) new URL(iconUrl).openConnection(); c.setConnectTimeout(5000); c.setReadTimeout(5000); c.setRequestProperty("User-Agent", "Mozilla/5.0 VoetbalHub"); try (InputStream in = c.getInputStream()) { Bitmap bmp = BitmapFactory.decodeStream(in); if (bmp != null) main.post(() -> target.setImageBitmap(bmp)); } } catch (Exception ignored) {} finally { if (c != null) c.disconnect(); } });
    }

    private void showLegalInfo() {
        new AlertDialog.Builder(this)
                .setTitle("Auteursrecht & bronnen")
                .setMessage("VoetbalHub is een onafhankelijke nieuwsaggregator. We tonen per bericht de oorspronkelijke bron en link. Volledige artikelen, foto’s en andere beschermde content blijven op de website van de oorspronkelijke uitgever.\n\nBronnen: VI, VoetbalPrimeur en VoetbalNieuws. VoetbalHub claimt geen officiële samenwerking of vertegenwoordiging van deze partijen.\n\nVoor publicatie in Google Play moeten daarnaast de vereiste News & Magazine-verklaring, actuele contactgegevens en andere Play Console-verplichtingen worden ingevuld.")
                .setPositiveButton("OK", null)
                .show();
    }

    private void showSearch() {
        Dialog dialog = new Dialog(this);
        LinearLayout panel = new LinearLayout(this); panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(20), dp(18), dp(20), dp(16)); panel.setBackground(cardBackground());
        TextView title = tv("Zoeken", 20, C.TEXT, true); title.setPadding(0, 0, 0, dp(5)); panel.addView(title);
        TextView subtitle = tv("Vind nieuws over een club, speler of onderwerp", 12, C.MUTED, false); subtitle.setPadding(0, 0, 0, dp(14)); panel.addView(subtitle);
        EditText input = new EditText(this); input.setSingleLine(true); input.setTextColor(C.TEXT); input.setHintTextColor(C.MUTED); input.setHint("Bijv. FC Groningen"); input.setPadding(dp(14), dp(10), dp(14), dp(10));
        GradientDrawable field = new GradientDrawable(); field.setColor(0xFF080D0B); field.setCornerRadius(dp(12)); field.setStroke(dp(1), C.BORDER); input.setBackground(field); panel.addView(input, new LinearLayout.LayoutParams(-1, dp(50)));
        LinearLayout actions = new LinearLayout(this); actions.setGravity(Gravity.END|Gravity.CENTER_VERTICAL); actions.setPadding(0, dp(14), 0, 0);
        TextView cancel = tv("Annuleren", 13, C.MUTED, true); cancel.setGravity(Gravity.CENTER); cancel.setPadding(dp(12), dp(10), dp(12), dp(10)); cancel.setOnClickListener(v -> dialog.dismiss()); actions.addView(cancel);
        TextView go = tv("ZOEKEN  →", 13, C.GREEN, true); go.setGravity(Gravity.CENTER); go.setPadding(dp(14), dp(10), dp(4), dp(10)); go.setOnClickListener(v -> { String q=input.getText().toString().trim(); dialog.dismiss(); search(q); }); actions.addView(go); panel.addView(actions);
        dialog.setContentView(panel); android.view.Window w=dialog.getWindow(); if(w!=null){w.setBackgroundDrawableResource(android.R.color.transparent); w.setLayout((int)(getResources().getDisplayMetrics().widthPixels*0.90), -2);} dialog.show(); if(dialog.getWindow()!=null){dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent); dialog.getWindow().setLayout((int)(getResources().getDisplayMetrics().widthPixels*0.90), -2);} input.requestFocus();
    }

    private void search(String q) {
        if (q.isEmpty()) return;
        content.removeAllViews();
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.addView(sectionHeader("Zoekresultaten", "NIEUW ZOEKEN", this::showSearch));
        TextView query = tv("Zoekterm: " + q, 12, C.MUTED, false);
        query.setPadding(dp(16), 0, dp(16), dp(12));
        root.addView(query);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(16), 0, dp(16), dp(24));
        List<Article> matches = new ArrayList<>();
        String needle = q.toLowerCase(Locale.ROOT);
        for (Article a : articles) {
            if (a.title.toLowerCase(Locale.ROOT).contains(needle) || a.source.toLowerCase(Locale.ROOT).contains(needle)) matches.add(a);
        }
        Collections.sort(matches, (a, b) -> b.date.compareTo(a.date));
        for (int i = 0; i < Math.min(30, matches.size()); i++) addArticleCard(list, matches.get(i), false);
        if (matches.isEmpty()) list.addView(tv("Geen resultaten voor \"" + q + "\". Probeer een clubnaam of onderwerp.", 15, C.MUTED, false));
        ScrollView scroll = new ScrollView(this);
        scroll.addView(list);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        content.addView(root);
    }

    private void showSettings() {
        Dialog dialog = new Dialog(this); LinearLayout panel = new LinearLayout(this); panel.setOrientation(LinearLayout.VERTICAL); panel.setPadding(dp(18), dp(18), dp(18), dp(12)); panel.setBackground(cardBackground());
        TextView title=tv("VOETBALHUB  ·  MENU",18,C.TEXT,true); title.setPadding(dp(4),dp(2),0,dp(12)); panel.addView(title);
        String[] labels={"↻   Nieuws vernieuwen","★   Favorieten beheren","◎   Bronnen bekijken","ⓘ   Over VoetbalHub"};
        for(int i=0;i<labels.length;i++){ final int index=i; TextView item=tv(labels[i],15,C.TEXT,false); item.setGravity(Gravity.CENTER_VERTICAL); item.setPadding(dp(14),0,dp(10),0); item.setBackground(cardBackground()); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(48)); lp.setMargins(0,0,0,dp(7)); panel.addView(item,lp); item.setOnClickListener(v->{dialog.dismiss(); if(index==0)refreshNews(); else if(index==1)showFavorites(); else showMore();}); }
        TextView close=tv("SLUITEN",12,C.GREEN,true); close.setGravity(Gravity.END|Gravity.CENTER_VERTICAL); close.setPadding(0,dp(8),dp(6),dp(4)); panel.addView(close); close.setOnClickListener(v->dialog.dismiss());
        dialog.setContentView(panel); dialog.show(); if(dialog.getWindow()!=null){dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent); dialog.getWindow().setLayout((int)(getResources().getDisplayMetrics().widthPixels*0.88),-2);}
    }

    private void openUrl(String url) { if (url == null || url.isEmpty()) return; openArticle(url, "VoetbalHub"); }

    private boolean backPressedOnce = false;

    @Override
    public void onBackPressed() {
        // Vanuit een artikel sluit TERUG de ingebouwde browser en keert direct terug naar VoetbalHub.
        // Dit voorkomt dat de gebruiker eerst door eerdere VI-doorverwijzingen moet teruggaan.
        if (articleOpen) {
            closeArticleView();
            return;
        }

        // Op het hoofdscherm moet TERUG twee keer binnen 2 seconden worden ingedrukt.
        if (backPressedOnce) {
            main.removeCallbacks(resetBackPressed);
            finish();
            return;
        }

        backPressedOnce = true;
        Toast.makeText(this, "Druk nogmaals op TERUG om VoetbalHub af te sluiten", Toast.LENGTH_SHORT).show();
        main.postDelayed(resetBackPressed, 2000);
    }

    private final Runnable resetBackPressed = () -> backPressedOnce = false;

    @Override protected void onDestroy() {
        main.removeCallbacks(periodicRefresh);
        main.removeCallbacks(resetBackPressed);
        executor.shutdownNow();
        if (bannerAdView != null) {
            bannerAdView.destroy();
            bannerAdView = null;
        }
        super.onDestroy();
    }

    private static final class C {
        static final int GREEN = 0xFF25F06B;
        static final int TEXT = 0xFFF6FAF7;
        static final int MUTED = 0xFF8E9B95;
        static final int BG = 0xFF050807;
        static final int CARD = 0xFF0C1210;
        static final int BORDER = 0xFF1B2822;
        static final int IMAGE_PLACEHOLDER = 0xFF17211C;
    }

    @Override protected void onPause() {
        if (bannerAdView != null) bannerAdView.pause();
        super.onPause();
    }

    @Override protected void onResume() {
        super.onResume();
        if (bannerAdView != null) bannerAdView.resume();
    }

}
