# VoetbalHub

Professionele Nederlandse voetbalnieuws-app.

## GitHub APK build

De repository gebruikt GitHub Actions. De workflow bouwt direct vanuit de projectroot met Gradle 8.9 en Java 17.

APK-artifact: `VoetbalHub-APK`

## Functies
- Nieuws van VI, VoetbalPrimeur en Voetbalzone via feeds
- Categorieën en zoeken
- Video-links
- Uitslagen en competities
- Favoriete clubs
- Instellingen
- Donkere professionele voetbalinterface
