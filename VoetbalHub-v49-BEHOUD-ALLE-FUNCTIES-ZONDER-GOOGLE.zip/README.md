# VoetbalHub 4.16

- Version code: 49
- Built on top of VoetbalHub 4.15 / version code 48, preserving the existing app functionality and navigation.
- Removed Google News as a news source; only the direct VI, VoetbalPrimeur and VoetbalNieuws RSS feeds are used.
- Old cached Google News articles are filtered out of the saved news cache.
- Replaced the intro artwork with a cleaner, aligned dark/neon-green splash; removed the extra animated overlay that caused logos and lines to overlap.
- Includes the version 48 European fixtures and KNVB Cup sections.

Build using the repository GitHub Actions workflow. Android compilation has not been run locally.
