package nl.voetbalhub.app;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Html;
import android.text.TextUtils;
import android.util.Xml;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.*;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import org.xmlpull.v1.XmlPullParser;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {
    private static class Article {
        final String title, link, source, date;
        Article(String title, String link, String source, String date) {
            this.title = title;
            this.link = link;
            this.source = source;
            this.date = date;
        }
    }

    private final ExecutorService executor = Executors.newFixedThreadPool(4);
    private final Handler main = new Handler(Looper.getMainLooper());
    private final List<Article> articles = new ArrayList<>();
    private final List<Article> shown = new ArrayList<>();
    private final String[] feedNames = {"VI", "VoetbalPrimeur", "Voetbalzone"};
    private final String[] feedUrls = {
            "https://www.vi.nl/feed/news.xml",
            "https://www.voetbalprimeur.nl/feed/news.xml",
            "https://news.google.com/rss/search?q=site%3Avoetbalzone.nl&hl=nl&gl=NL&ceid=NL:nl"
    };
    private String active = "Voor jou";
    private boolean loading = false;
    private boolean articleOpen = false;
    private WebView activeWebView;
    private FrameLayout content;
    private LinearLayout chips, nav;
    private SharedPreferences prefs;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        content = findViewById(R.id.content);
        chips = findViewById(R.id.chips);
        nav = findViewById(R.id.nav);
        View header = findViewById(R.id.header);
        ViewCompat.setOnApplyWindowInsetsListener(header, (v, insets) -> {
            int top = insets.getInsets(WindowInsetsCompat.Type.statusBars()).top;
            v.setPadding(v.getPaddingLeft(), top, v.getPaddingRight(), v.getPaddingBottom());
            ViewGroup.LayoutParams lp = v.getLayoutParams();
            lp.height = dp(64) + top;
            v.setLayoutParams(lp);
            return insets;
        });
        ViewCompat.setOnApplyWindowInsetsListener(nav, (v, insets) -> {
            int bottom = insets.getInsets(WindowInsetsCompat.Type.navigationBars()).bottom;
            int extra = dp(10);
            v.setPadding(v.getPaddingLeft(), dp(4), v.getPaddingRight(), bottom + extra);
            ViewGroup.LayoutParams lp = v.getLayoutParams();
            lp.height = dp(76) + bottom;
            v.setLayoutParams(lp);
            return insets;
        });
        ViewCompat.requestApplyInsets(header);
        ViewCompat.requestApplyInsets(nav);
        prefs = getSharedPreferences("voethub", MODE_PRIVATE);
        buildChips();
        buildNav();
        findViewById(R.id.search).setOnClickListener(v -> showSearch());
        findViewById(R.id.settings).setOnClickListener(v -> showSettings());
        showNews();
        refreshNews();
        showIntro();
    }

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    private TextView tv(String text, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setIncludeFontPadding(false);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private void buildChips() {
        chips.removeAllViews();
        String[] labels = {"Voor jou", "Laatste nieuws", "Transfers", "Eredivisie", "Buitenland", "Video"};
        for (String label : labels) {
            TextView b = tv(label, 13, label.equals(active) ? C.BG : C.TEXT, false);
            b.setGravity(Gravity.CENTER);
            b.setPadding(dp(13), 0, dp(13), 0);
            b.setBackground(ContextCompat.getDrawable(this, label.equals(active) ? R.drawable.rounded_active : R.drawable.rounded_chip));
            b.setOnClickListener(v -> {
                active = label;
                buildChips();
                if (label.equals("Video")) showVideos(); else showNews();
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, dp(34));
            lp.setMargins(0, 0, dp(8), 0);
            chips.addView(b, lp);
        }
    }

    private void buildNav() {
        nav.removeAllViews();
        String[][] items = {{"⌂", "Nieuws"}, {"▣", "Uitslagen"}, {"◉", "Competities"}, {"★", "Favorieten"}, {"☰", "Meer"}};
        for (int i = 0; i < items.length; i++) {
            final String page = items[i][1];
            final int index = i;
            LinearLayout box = new LinearLayout(this);
            box.setOrientation(LinearLayout.VERTICAL);
            box.setGravity(Gravity.CENTER);
            box.setClickable(true);
            box.addView(tv(items[i][0], 21, index == 0 ? C.GREEN : C.MUTED, true), new LinearLayout.LayoutParams(-1, dp(28)));
            box.addView(tv(page, 10, index == 0 ? C.GREEN : C.MUTED, index == 0), new LinearLayout.LayoutParams(-1, dp(18)));
            box.setOnClickListener(v -> {
                switch (page) {
                    case "Nieuws": active = "Voor jou"; buildChips(); showNews(); break;
                    case "Uitslagen": showScores(); break;
                    case "Competities": showCompetitions(); break;
                    case "Favorieten": showFavorites(); break;
                    default: showMore();
                }
            });
            nav.addView(box, new LinearLayout.LayoutParams(0, -1, 1));
        }
    }

    private LinearLayout sectionHeader(String title, String action, final Runnable click) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(16), dp(10), dp(16), dp(10));
        row.addView(tv(title, 22, C.TEXT, true), new LinearLayout.LayoutParams(0, dp(40), 1));
        if (action != null) {
            TextView a = tv(action, 12, C.GREEN, true);
            a.setGravity(Gravity.CENTER);
            a.setOnClickListener(v -> { if (click != null) click.run(); });
            row.addView(a, new LinearLayout.LayoutParams(dp(90), dp(36)));
        }
        return row;
    }

    private LinearLayout sectionHeader(String title) { return sectionHeader(title, null, null); }

    private void showNews() {
        articleOpen = false;
        activeWebView = null;
        content.removeAllViews();
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.addView(sectionHeader("Laatste voetbalnieuws", "VERVERS", this::refreshNews));
        TextView status = tv(loading ? "Nieuws wordt bijgewerkt…" : "VI  •  VoetbalPrimeur  •  Voetbalzone", 11, C.MUTED, false);
        status.setPadding(dp(16), 0, dp(16), dp(10));
        root.addView(status);
        ScrollView scroll = new ScrollView(this);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(16), 0, dp(16), dp(24));
        List<Article> filtered = filterArticles(active);
        shown.clear(); shown.addAll(filtered);
        if (filtered.isEmpty()) {
            list.addView(tv("Nog geen nieuws geladen. Tik op VERVERS.", 15, C.MUTED, false), new LinearLayout.LayoutParams(-1, dp(60)));
        } else {
            for (int i = 0; i < Math.min(30, filtered.size()); i++) addArticleCard(list, filtered.get(i), i == 0 && active.equals("Voor jou"));
        }
        scroll.addView(list);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        content.addView(root);
    }

    private GradientDrawable cardBackground() {
        GradientDrawable g = new GradientDrawable();
        g.setColor(C.CARD);
        g.setCornerRadius(dp(18));
        g.setStroke(dp(1), C.BORDER);
        return g;
    }

    private void addArticleCard(LinearLayout list, Article a, boolean hero) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(13), dp(14), dp(13));
        card.setClickable(true);
        card.setBackground(cardBackground());
        card.setOnClickListener(v -> openArticle(a.link, a.title));

        LinearLayout sourceRow = new LinearLayout(this);
        sourceRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView source = tv(a.source.toUpperCase(Locale.getDefault()), 9, C.GREEN, true);
        sourceRow.addView(source, new LinearLayout.LayoutParams(0, dp(20), 1));
        TextView date = tv(formatDate(a.date), 9, C.MUTED, false);
        sourceRow.addView(date, new LinearLayout.LayoutParams(-2, dp(20)));
        card.addView(sourceRow);

        TextView title = tv(a.title, hero ? 18 : 15, C.TEXT, true);
        title.setMaxLines(hero ? 4 : 3);
        title.setEllipsize(TextUtils.TruncateAt.END);
        title.setPadding(0, dp(7), 0, dp(7));
        card.addView(title);
        card.addView(tv("Lees bij de oorspronkelijke uitgever  ›", 10, C.MUTED, false));

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, dp(10));
        list.addView(card, lp);
    }

    private String formatDate(String raw) {
        if (raw == null || raw.trim().isEmpty()) return "";
        String x = raw.trim();
        return x.length() > 24 ? x.substring(0, 24) : x;
    }

    private List<Article> filterArticles(String category) {
        List<Article> base = new ArrayList<>(articles);
        Collections.sort(base, (a, b) -> b.date.compareTo(a.date));
        if (category.equals("Transfers")) return filter(base, "transfer|transferv|deal|akkoord|vertrekt|tekent|contract");
        if (category.equals("Eredivisie")) return filter(base, "Ajax|PSV|Feyenoord|Groningen|AZ|Twente|Utrecht|Heerenveen|NEC|Sparta|Eredivisie|RKC|Go Ahead|Fortuna|PEC|NAC|Volendam|Heracles");
        if (category.equals("Buitenland")) return filter(base, "Premier League|La Liga|Barcelona|Real Madrid|Liverpool|Arsenal|Manchester|Bayern|Dortmund|Serie A|Milan|Inter|PSG|Champions League");
        return base;
    }

    private List<Article> filter(List<Article> base, String regex) {
        List<Article> r = new ArrayList<>();
        for (Article a : base) if (a.title.matches("(?i).*?(" + regex + ").*")) r.add(a);
        return r;
    }

    private void refreshNews() {
        if (loading) return;
        loading = true;
        showNews();
        executor.execute(() -> {
            List<Article> fresh = new ArrayList<>();
            for (int i = 0; i < feedUrls.length; i++) {
                try { fresh.addAll(parseFeed(feedNames[i], feedUrls[i])); } catch (Exception ignored) { }
            }
            Collections.sort(fresh, (a, b) -> b.date.compareTo(a.date));
            main.post(() -> { articles.clear(); articles.addAll(fresh); loading = false; showNews(); });
        });
    }

    private List<Article> parseFeed(String source, String url) throws Exception {
        List<Article> result = new ArrayList<>();
        XmlPullParser parser = Xml.newPullParser();
        URL u = new URL(url);
        java.net.URLConnection c = u.openConnection();
        c.setConnectTimeout(8000); c.setReadTimeout(8000); c.setRequestProperty("User-Agent", "VoetbalHub/2.0");
        parser.setInput(c.getInputStream(), null);
        boolean inside = false;
        String title = "", link = "", date = "";
        int event = parser.getEventType();
        while (event != XmlPullParser.END_DOCUMENT) {
            String name = parser.getName() == null ? "" : parser.getName();
            String lower = name.toLowerCase(Locale.ROOT);
            if (event == XmlPullParser.START_TAG && (lower.equals("item") || lower.equals("entry"))) inside = true;
            if (inside && event == XmlPullParser.START_TAG) {
                if (lower.equals("title")) { title = nextText(parser); }
                else if (lower.equals("link")) {
                    String href = parser.getAttributeValue(null, "href");
                    link = href != null ? href : nextText(parser);
                } else if (lower.equals("pubdate") || lower.equals("published") || lower.equals("updated") || lower.equals("dc:date")) {
                    date = nextText(parser);
                }
            }
            if (inside && event == XmlPullParser.END_TAG && (lower.equals("item") || lower.equals("entry"))) {
                if (!title.isEmpty() && link.startsWith("https://")) result.add(new Article(clean(title), link, source, date));
                title = ""; link = ""; date = ""; inside = false;
            }
            event = parser.next();
        }
        return result;
    }

    private String nextText(XmlPullParser parser) throws Exception {
        String value = parser.nextText();
        return value == null ? "" : value.trim();
    }

    private String clean(String s) { return s.replaceAll("\\s+", " ").trim(); }

    @SuppressLint("SetJavaScriptEnabled")
    private void openArticle(String url, String title) {
        articleOpen = true;
        content.removeAllViews();
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        LinearLayout toolbar = new LinearLayout(this);
        toolbar.setGravity(Gravity.CENTER_VERTICAL);
        toolbar.setPadding(dp(8), dp(4), dp(8), dp(4));
        TextView back = tv("‹", 34, C.TEXT, false);
        back.setGravity(Gravity.CENTER);
        back.setOnClickListener(v -> showNews());
        toolbar.addView(back, new LinearLayout.LayoutParams(dp(48), dp(48)));
        TextView heading = tv(title, 15, C.TEXT, true);
        heading.setMaxLines(2);
        heading.setEllipsize(TextUtils.TruncateAt.END);
        toolbar.addView(heading, new LinearLayout.LayoutParams(0, dp(52), 1));
        TextView share = tv("↗", 22, C.GREEN, true);
        share.setGravity(Gravity.CENTER);
        share.setOnClickListener(v -> shareArticle(url));
        toolbar.addView(share, new LinearLayout.LayoutParams(dp(48), dp(48)));
        root.addView(toolbar);

        WebView web = new WebView(this);
        activeWebView = web;
        web.setBackgroundColor(C.BG);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setLoadsImagesAutomatically(true);
        web.getSettings().setMediaPlaybackRequiresUserGesture(true);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) { return false; }
        });
        web.loadUrl(url);
        root.addView(web, new LinearLayout.LayoutParams(-1, 0, 1));
        content.addView(root);
    }

    private void shareArticle(String url) {
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_TEXT, url);
        startActivity(Intent.createChooser(send, "Deel artikel"));
    }

    private void showIntro() {
        final FrameLayout overlay = new FrameLayout(this);
        overlay.setBackgroundColor(C.BG);
        overlay.setElevation(dp(50));

        LinearLayout center = new LinearLayout(this);
        center.setOrientation(LinearLayout.VERTICAL);
        center.setGravity(Gravity.CENTER_HORIZONTAL);
        center.setPadding(dp(24), dp(24), dp(24), dp(24));

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.ic_launcher);
        center.addView(logo, new LinearLayout.LayoutParams(dp(82), dp(82)));

        TextView title = tv("VOETBALHUB", 27, C.TEXT, true);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, dp(12), 0, dp(2));
        center.addView(title, new LinearLayout.LayoutParams(-1, dp(38)));

        TextView subtitle = tv("Onafhankelijke verzameling van nieuwslinks", 12, C.MUTED, false);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setMaxLines(2);
        center.addView(subtitle, new LinearLayout.LayoutParams(-1, dp(42)));

        LinearLayout sources = new LinearLayout(this);
        sources.setOrientation(LinearLayout.VERTICAL);
        sources.setGravity(Gravity.CENTER_HORIZONTAL);
        sources.setPadding(0, dp(22), 0, dp(14));
        String[] names = {"VI", "VoetbalPrimeur", "Voetbalzone"};
        for (String name : names) {
            TextView source = tv(name, 13, C.TEXT, true);
            source.setGravity(Gravity.CENTER);
            source.setBackground(cardBackground());
            source.setPadding(dp(18), 0, dp(18), 0);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(190), dp(38));
            lp.setMargins(0, 0, 0, dp(7));
            sources.addView(source, lp);
            AlphaAnimation a = new AlphaAnimation(0f, 1f);
            a.setDuration(320);
            a.setStartOffset(name.equals("VI") ? 180 : name.equals("VoetbalPrimeur") ? 430 : 680);
            source.startAnimation(a);
        }
        center.addView(sources);

        TextView arrow = tv("↓", 25, C.GREEN, true);
        arrow.setGravity(Gravity.CENTER);
        center.addView(arrow, new LinearLayout.LayoutParams(-1, dp(30)));

        TextView result = tv("VOETBALHUB  •  ONAFHANKELIJK", 15, C.GREEN, true);
        result.setGravity(Gravity.CENTER);
        GradientDrawable resultBg = new GradientDrawable();
        resultBg.setColor(C.CARD);
        resultBg.setCornerRadius(dp(20));
        resultBg.setStroke(dp(1), C.GREEN);
        result.setBackground(resultBg);
        center.addView(result, new LinearLayout.LayoutParams(dp(220), dp(48)));

        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(-1, -2, Gravity.CENTER);
        overlay.addView(center, cp);
        addContentView(overlay, new ViewGroup.LayoutParams(-1, -1));

        overlay.setAlpha(1f);
        overlay.postDelayed(() -> {
            AlphaAnimation fade = new AlphaAnimation(1f, 0f);
            fade.setDuration(360);
            fade.setInterpolator(new DecelerateInterpolator());
            fade.setAnimationListener(new Animation.AnimationListener() {
                public void onAnimationStart(Animation animation) {}
                public void onAnimationRepeat(Animation animation) {}
                public void onAnimationEnd(Animation animation) {
                    ViewGroup parent = (ViewGroup) overlay.getParent();
                    if (parent != null) parent.removeView(overlay);
                }
            });
            overlay.startAnimation(fade);
        }, 1640);
    }

    private void showVideos() {
        content.removeAllViews();
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.addView(sectionHeader("Voetbalvideo", "VERVERS", this::showVideos));
        TextView sub = tv("Video's blijven binnen VoetbalHub beschikbaar.", 12, C.MUTED, false);
        sub.setPadding(dp(16), 0, dp(16), dp(12)); root.addView(sub);
        ScrollView scroll = new ScrollView(this);
        LinearLayout list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); list.setPadding(dp(16), 0, dp(16), dp(24));
        String[][] videos = {{"VI Video", "https://www.youtube.com/results?search_query=Voetbal+International+VI+Video"}, {"VoetbalPrimeur Video", "https://www.youtube.com/results?search_query=VoetbalPrimeur"}, {"Voetbalzone Video", "https://www.youtube.com/results?search_query=Voetbalzone+voetbal"}};
        for (String[] v : videos) {
            LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setGravity(Gravity.CENTER_VERTICAL); card.setPadding(dp(18), dp(18), dp(18), dp(18)); card.setBackground(cardBackground()); card.setOnClickListener(x -> openArticle(v[1], v[0]));
            card.addView(tv("▶", 28, C.GREEN, true));
            TextView t = tv(v[0], 18, C.TEXT, true); t.setPadding(0, dp(8), 0, dp(4)); card.addView(t);
            card.addView(tv("Afspelen binnen de app  ›", 12, C.MUTED, false));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(120)); lp.setMargins(0, 0, 0, dp(12)); list.addView(card, lp);
        }
        scroll.addView(list); root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1)); content.addView(root);
    }

    private void showScores() { content.removeAllViews(); LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.addView(sectionHeader("Uitslagen & programma", "OPEN", () -> openArticle("https://www.vi.nl/wedstrijden", "Wedstrijdcentrum"))); LinearLayout list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); list.setPadding(dp(16), 0, dp(16), dp(24)); list.addView(tv("Wedstrijdcentrum", 20, C.TEXT, true)); list.addView(tv("Actuele standen, programma's en live uitslagen.", 14, C.MUTED, false)); addAction(list, "OPEN WEDSTRIJDCENTRUM", "https://www.vi.nl/wedstrijden"); addAction(list, "Eredivisie programma", "https://eredivisie.nl/competitie/wedstrijden/"); ScrollView s = new ScrollView(this); s.addView(list); root.addView(s, new LinearLayout.LayoutParams(-1, 0, 1)); content.addView(root); }

    private void showCompetitions() { content.removeAllViews(); LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.addView(sectionHeader("Competities")); LinearLayout list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); list.setPadding(dp(16), 0, dp(16), dp(24)); String[][] c = {{"🇳🇱 Eredivisie", "https://eredivisie.nl/"}, {"🏆 Champions League", "https://www.uefa.com/uefachampionsleague/"}, {"🏴 Premier League", "https://www.premierleague.com/"}, {"🇪🇸 La Liga", "https://www.laliga.com/"}, {"🇮🇹 Serie A", "https://www.legaseriea.it/"}}; for (String[] x : c) addAction(list, x[0], x[1]); ScrollView s = new ScrollView(this); s.addView(list); root.addView(s, new LinearLayout.LayoutParams(-1, 0, 1)); content.addView(root); }

    private void showFavorites() {
        content.removeAllViews();
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.addView(sectionHeader("Favorieten"));
        LinearLayout list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); list.setPadding(dp(16), 0, dp(16), dp(24));
        Set<String> stored = prefs.getStringSet("clubs", Collections.<String>emptySet()); Set<String> favs = new HashSet<>(stored);
        String heading = favs.isEmpty() ? "Nog geen favoriete clubs." : "Jouw clubs: " + join(favs, "  •  "); TextView h = tv(heading, 16, C.TEXT, true); h.setPadding(0, dp(16), 0, dp(18)); list.addView(h);
        String[] clubs = {"FC Groningen", "Ajax", "PSV", "Feyenoord", "AZ"};
        for (final String club : clubs) {
            Button button = new Button(this); boolean favorite = favs.contains(club); button.setText((favorite ? "★ " : "☆ ") + club); button.setTextColor(favorite ? C.GREEN : C.TEXT); button.setOnClickListener(v -> { Set<String> current = new HashSet<>(prefs.getStringSet("clubs", Collections.<String>emptySet())); if (current.contains(club)) current.remove(club); else current.add(club); prefs.edit().putStringSet("clubs", current).apply(); showFavorites(); }); list.addView(button, new LinearLayout.LayoutParams(-1, dp(52)));
        }
        ScrollView scroll = new ScrollView(this); scroll.addView(list); root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1)); content.addView(root);
    }

    private String join(Set<String> s, String sep) { StringBuilder b = new StringBuilder(); for (String x : s) { if (b.length() > 0) b.append(sep); b.append(x); } return b.toString(); }

    private void showMore() {
        content.removeAllViews();
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.addView(sectionHeader("Meer"));
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(16), 0, dp(16), dp(24));
        addAction(list, "VI.nl openen", "https://www.vi.nl/");
        addAction(list, "VoetbalPrimeur openen", "https://www.voetbalprimeur.nl/");
        addAction(list, "Voetbalzone openen", "https://www.voetbalzone.nl/");
        addAction(list, "Auteursrecht & bronnen", null);
        addAction(list, "Feedback sturen", "mailto:voetbalhub.app@gmail.com?subject=VoetbalHub%20feedback");
        TextView info = tv("VoetbalHub 2.2\nOnafhankelijke nieuwsaggregator. VoetbalHub kopieert geen volledige artikelen of afbeeldingen. Per bericht tonen we de bron en openen we het originele artikel bij de oorspronkelijke uitgever.\n\nVoetbalHub is niet officieel verbonden aan VI, VoetbalPrimeur of Voetbalzone.", 12, C.MUTED, false);
        info.setPadding(0, dp(24), 0, 0);
        list.addView(info);
        ScrollView scroll = new ScrollView(this);
        scroll.addView(list);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        content.addView(root);
    }

    private void addAction(LinearLayout list, String label, String url) { TextView b = tv(label + "  ›", 15, C.TEXT, false); b.setGravity(Gravity.CENTER_VERTICAL); b.setPadding(dp(18), 0, dp(18), 0); b.setBackground(cardBackground()); b.setOnClickListener(v -> { if (url != null && url.startsWith("mailto:")) { try { Intent i = new Intent(Intent.ACTION_SENDTO, Uri.parse(url)); startActivity(i); } catch (Exception ignored) {} } else if (url != null) { openArticle(url, label); } else { showLegalInfo(); } }); LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(58)); lp.setMargins(0, 0, 0, dp(10)); list.addView(b, lp); }

    private void showLegalInfo() {
        new AlertDialog.Builder(this)
                .setTitle("Auteursrecht & bronnen")
                .setMessage("VoetbalHub is een onafhankelijke nieuwsaggregator. We tonen per bericht de oorspronkelijke bron en link. Volledige artikelen, foto’s en andere beschermde content blijven op de website van de oorspronkelijke uitgever.\n\nBronnen: VI, VoetbalPrimeur en Voetbalzone. VoetbalHub claimt geen officiële samenwerking of vertegenwoordiging van deze partijen.\n\nVoor publicatie in Google Play moeten daarnaast de vereiste News & Magazine-verklaring, actuele contactgegevens en andere Play Console-verplichtingen worden ingevuld.")
                .setPositiveButton("OK", null)
                .show();
    }

    private void showSearch() { EditText input = new EditText(this); input.setHint("Zoek speler, club of onderwerp"); input.setSingleLine(true); input.setPadding(dp(16), 0, dp(16), 0); new AlertDialog.Builder(this).setTitle("Zoeken in VoetbalHub").setView(input).setNegativeButton("Annuleren", null).setPositiveButton("Zoeken", (d, w) -> search(input.getText().toString().trim())).show(); }

    private void search(String q) { if (q.isEmpty()) return; active = "Voor jou"; buildChips(); content.removeAllViews(); LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.addView(sectionHeader("Zoekresultaten")); LinearLayout list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); list.setPadding(dp(16), 0, dp(16), dp(24)); int count = 0; for (Article a : articles) { if (a.title.toLowerCase(Locale.ROOT).contains(q.toLowerCase(Locale.ROOT))) { addArticleCard(list, a, false); if (++count >= 30) break; } } if (count == 0) list.addView(tv("Geen resultaten voor \"" + q + "\".", 15, C.MUTED, false)); ScrollView s = new ScrollView(this); s.addView(list); root.addView(s, new LinearLayout.LayoutParams(-1, 0, 1)); content.addView(root); }

    private void showSettings() { new AlertDialog.Builder(this).setTitle("VoetbalHub instellingen").setItems(new String[]{"Nieuws vernieuwen", "Favorieten beheren", "Bronnen bekijken", "Over VoetbalHub"}, (d, which) -> { if (which == 0) refreshNews(); else if (which == 1) showFavorites(); else showMore(); }).show(); }

    private void openUrl(String url) { if (url == null || url.isEmpty()) return; openArticle(url, "VoetbalHub"); }

    @Override
    public void onBackPressed() {
        if (activeWebView != null && activeWebView.canGoBack()) {
            activeWebView.goBack();
            return;
        }
        if (articleOpen) {
            showNews();
            return;
        }
        showNews();
    }

    @Override protected void onDestroy() { executor.shutdownNow(); super.onDestroy(); }

    private static final class C {
        static final int GREEN = 0xFF25F06B;
        static final int TEXT = 0xFFF6FAF7;
        static final int MUTED = 0xFF8E9B95;
        static final int BG = 0xFF050807;
        static final int CARD = 0xFF0C1210;
        static final int BORDER = 0xFF1B2822;
        static final int IMAGE_PLACEHOLDER = 0xFF17211C;
    }
}
