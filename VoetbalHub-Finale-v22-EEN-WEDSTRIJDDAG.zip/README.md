# VoetbalHub v22 — één wedstrijddag

- Live Eredivisieblok toont wedstrijden van één wedstrijddag tegelijk (de eerste datum uit de beschikbare scoreboardfeed).
- Aftrap bij geplande wedstrijden staat prominent als VANDAAG · HH:mm.
- Live wedstrijdstatus/minuut, rust en eindstand worden weergegeven wanneer de feed deze informatie levert.
- Teamlogo's worden geladen uit de beschikbare teamgegevens; als een logo ontbreekt blijft de initialenbadge zichtbaar.
- Tik op een wedstrijdkaart om de Flashscore-ingang te openen.
- Versie 3.0 (versionCode 21).

De gebruikte ESPN-scoreboardfeed is een beschikbare feed zonder SLA; controleer build en wedstrijdgegevens op het apparaat.
