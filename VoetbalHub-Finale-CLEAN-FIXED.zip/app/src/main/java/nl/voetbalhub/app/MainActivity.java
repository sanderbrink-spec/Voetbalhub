package nl.voetbalhub.app;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Xml;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import org.xmlpull.v1.XmlPullParser;

import java.net.URL;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {
    private static class Article {
        final String title, link, source, date;
        Article(String title, String link, String source, String date) {
            this.title = title; this.link = link; this.source = source; this.date = date;
        }
    }

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private final List<Article> articles = new ArrayList<>();
    private final List<Article> shown = new ArrayList<>();
    private final String[] feedNames = {"VI", "VoetbalPrimeur", "Voetbalzone"};
    private final String[] feedUrls = {
            "https://www.vi.nl/feed/news.xml",
            "https://www.voetbalprimeur.nl/feed/news.xml",
            "https://news.google.com/rss/search?q=site%3Avoetbalzone.nl&hl=nl&gl=NL&ceid=NL:nl"
    };
    private String active = "Voor jou";
    private boolean loading = false;
    private FrameLayout content;
    private LinearLayout chips, nav;
    private SharedPreferences prefs;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        content = findViewById(R.id.content);
        chips = findViewById(R.id.chips);
        nav = findViewById(R.id.nav);
        prefs = getSharedPreferences("voethub", MODE_PRIVATE);
        buildChips();
        buildNav();
        findViewById(R.id.search).setOnClickListener(v -> showSearch());
        findViewById(R.id.settings).setOnClickListener(v -> showSettings());
        showNews();
        refreshNews();
    }

    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    private TextView tv(String text, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(text); t.setTextSize(size); t.setTextColor(color); t.setIncludeFontPadding(false);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private void buildChips() {
        chips.removeAllViews();
        String[] labels = {"Voor jou", "Laatste nieuws", "Transfers", "Eredivisie", "Buitenland", "Video"};
        for (String label : labels) {
            TextView b = tv(label, 13, label.equals(active) ? C.BG : C.TEXT, false);
            b.setGravity(Gravity.CENTER); b.setPadding(dp(16), 0, dp(16), 0);
            b.setBackground(ContextCompat.getDrawable(this, label.equals(active) ? R.drawable.rounded_active : R.drawable.rounded_chip));
            b.setOnClickListener(v -> { active = label; buildChips(); if (label.equals("Video")) showVideos(); else showNews(); });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, dp(38));
            lp.setMargins(0,0,dp(8),0); chips.addView(b, lp);
        }
    }

    private void buildNav() {
        nav.removeAllViews();
        String[][] items = {{"⌂","Nieuws"},{"▣","Uitslagen"},{"◉","Competities"},{"★","Favorieten"},{"☰","Meer"}};
        for (int i=0;i<items.length;i++) {
            final String page = items[i][1]; final int index=i;
            LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setGravity(Gravity.CENTER); box.setClickable(true);
            box.addView(tv(items[i][0],21,index==0?C.GREEN:C.MUTED,true), new LinearLayout.LayoutParams(-1,dp(28)));
            box.addView(tv(page,10,index==0?C.GREEN:C.MUTED,index==0), new LinearLayout.LayoutParams(-1,dp(18)));
            box.setOnClickListener(v -> { switch(page) { case "Nieuws": active="Voor jou"; buildChips(); showNews(); break; case "Uitslagen": showScores(); break; case "Competities": showCompetitions(); break; case "Favorieten": showFavorites(); break; default: showMore(); }});
            nav.addView(box, new LinearLayout.LayoutParams(0,-1,1));
        }
    }

    private LinearLayout sectionHeader(String title, String action, final Runnable click) {
        LinearLayout row = new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(dp(16),dp(10),dp(16),dp(10));
        row.addView(tv(title,22,C.TEXT,true), new LinearLayout.LayoutParams(0,dp(40),1));
        if (action != null) {
            TextView a=tv(action,12,C.GREEN,true); a.setGravity(Gravity.CENTER); a.setOnClickListener(v->{if(click!=null)click.run();});
            row.addView(a,new LinearLayout.LayoutParams(dp(90),dp(36)));
        }
        return row;
    }
    private LinearLayout sectionHeader(String title) { return sectionHeader(title,null,null); }

    private void showNews() {
        content.removeAllViews();
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.addView(sectionHeader("Laatste voetbalnieuws","VERVERS",this::refreshNews));
        TextView status=tv(loading?"Nieuws wordt bijgewerkt…":"VI  •  VoetbalPrimeur  •  Voetbalzone",11,C.MUTED,false); status.setPadding(dp(16),0,dp(16),dp(10)); root.addView(status);
        ScrollView scroll=new ScrollView(this); LinearLayout list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); list.setPadding(dp(16),0,dp(16),dp(24));
        List<Article> filtered=filterArticles(active); shown.clear(); shown.addAll(filtered);
        if(filtered.isEmpty()) list.addView(tv("Nog geen nieuws geladen. Tik op VERVERS.",15,C.MUTED,false), new LinearLayout.LayoutParams(-1,dp(60)));
        else for(int i=0;i<Math.min(30,filtered.size());i++) addArticleCard(list,filtered.get(i),i==0&&active.equals("Voor jou"));
        scroll.addView(list); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1)); content.addView(root);
    }

    private void addArticleCard(LinearLayout list, Article a, boolean hero) {
        LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(dp(16),dp(15),dp(16),dp(15)); card.setClickable(true);
        card.setBackground(ContextCompat.getDrawable(this,R.drawable.rounded_card)); card.setOnClickListener(v->openUrl(a.link));
        String meta=a.source.toUpperCase(Locale.getDefault())+(a.date.isEmpty()?"":"  •  "+a.date);
        card.addView(tv(meta,10,C.GREEN,true));
        TextView title=tv(a.title,hero?20:16,C.TEXT,true); title.setPadding(0,dp(8),0,dp(5)); card.addView(title);
        card.addView(tv("Lees het volledige artikel bij "+a.source+"  ›",11,C.MUTED,false));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,0,0,dp(10)); list.addView(card,lp);
    }

    private List<Article> filterArticles(String category) {
        List<Article> base=new ArrayList<>(articles); Collections.sort(base,(a,b)->b.date.compareTo(a.date));
        if(category.equals("Transfers")) return filter(base,"transfer|transferv|deal|akkoord|vertrekt|tekent|contract");
        if(category.equals("Eredivisie")) return filter(base,"Ajax|PSV|Feyenoord|Groningen|AZ|Twente|Utrecht|Heerenveen|NEC|Sparta|Eredivisie|RKC|Go Ahead|Fortuna|PEC|NAC|Volendam|Heracles");
        if(category.equals("Buitenland")) return filter(base,"Premier League|La Liga|Barcelona|Real Madrid|Liverpool|Arsenal|Manchester|Bayern|Dortmund|Serie A|Milan|Inter|PSG|Champions League");
        return base;
    }
    private List<Article> filter(List<Article> base,String regex){List<Article> r=new ArrayList<>(); for(Article a:base) if(a.title.matches("(?i).*?("+regex+").*")) r.add(a); return r;}

    private void refreshNews() {
        if(loading)return; loading=true; showNews();
        executor.execute(()->{
            List<Article> fresh=new ArrayList<>();
            for(int i=0;i<feedUrls.length;i++) try{fresh.addAll(parseFeed(feedNames[i],feedUrls[i]));}catch(Exception ignored){}
            Collections.sort(fresh,(a,b)->b.date.compareTo(a.date));
            main.post(()->{articles.clear(); articles.addAll(fresh); loading=false; showNews();});
        });
    }

    private List<Article> parseFeed(String source,String url) throws Exception {
        List<Article> result=new ArrayList<>(); XmlPullParser parser=Xml.newPullParser();
        URL u=new URL(url); java.net.URLConnection c=u.openConnection(); c.setConnectTimeout(8000); c.setReadTimeout(8000); c.setRequestProperty("User-Agent","VoetbalHub/1.0");
        parser.setInput(c.getInputStream(),null); boolean inside=false; String title="",link="",date=""; int event=parser.getEventType();
        while(event!=XmlPullParser.END_DOCUMENT){
            if(event==XmlPullParser.START_TAG&&(parser.getName().equalsIgnoreCase("item")||parser.getName().equalsIgnoreCase("entry"))) inside=true;
            if(inside&&event==XmlPullParser.START_TAG){String n=parser.getName().toLowerCase(Locale.ROOT);
                if(n.equals("title")){parser.next();if(parser.getEventType()==XmlPullParser.TEXT)title=parser.getText().trim();}
                else if(n.equals("link")){String href=parser.getAttributeValue(null,"href"); if(href!=null&&!href.isEmpty())link=href; else {parser.next();if(parser.getEventType()==XmlPullParser.TEXT)link=parser.getText().trim();}}
                else if(n.equals("pubdate")||n.equals("published")||n.equals("updated")||n.equals("dc:date")){parser.next();if(parser.getEventType()==XmlPullParser.TEXT)date=parser.getText().trim();}
            }
            if(inside&&event==XmlPullParser.END_TAG&&(parser.getName().equalsIgnoreCase("item")||parser.getName().equalsIgnoreCase("entry"))){if(!title.isEmpty()&&link.startsWith("http"))result.add(new Article(clean(title),link,source,date));title="";link="";date="";inside=false;}
            event=parser.next();
        }
        return result;
    }
    private String clean(String s){return s.replaceAll("\\s+"," ").trim();}

    private void showVideos(){
        content.removeAllViews(); LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.addView(sectionHeader("Voetbalvideo","VERVERS",this::showVideos));
        TextView sub=tv("Officiële voetbalvideo's en shows",12,C.MUTED,false);sub.setPadding(dp(16),0,dp(16),dp(12));root.addView(sub);
        ScrollView scroll=new ScrollView(this);LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);list.setPadding(dp(16),0,dp(16),dp(24));
        String[][] videos={{"VI Video","https://www.youtube.com/results?search_query=Voetbal+International+VI+Video"},{"VoetbalPrimeur Video","https://www.youtube.com/results?search_query=VoetbalPrimeur"},{"Voetbalzone Video","https://www.youtube.com/results?search_query=Voetbalzone+voetbal"}};
        for(String[] v:videos){LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setGravity(Gravity.CENTER_VERTICAL);card.setPadding(dp(18),dp(18),dp(18),dp(18));card.setBackground(ContextCompat.getDrawable(this,R.drawable.rounded_card));card.setOnClickListener(x->openUrl(v[1]));card.addView(tv("▶",28,C.GREEN,true));TextView t=tv(v[0],18,C.TEXT,true);t.setPadding(0,dp(8),0,dp(4));card.addView(t);card.addView(tv("Open officiële videopagina  ›",12,C.MUTED,false));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(120));lp.setMargins(0,0,0,dp(12));list.addView(card,lp);}
        scroll.addView(list);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));content.addView(root);
    }

    private void showScores(){content.removeAllViews();LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.addView(sectionHeader("Uitslagen & programma","LIVE",()->openUrl("https://www.vi.nl/wedstrijden")));LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);list.setPadding(dp(16),0,dp(16),dp(24));list.addView(tv("Wedstrijdcentrum",20,C.TEXT,true));list.addView(tv("Bekijk actuele standen, programma's en live uitslagen via het wedstrijdcentrum.",14,C.MUTED,false));addAction(list,"OPEN WEDSTRIJDCENTRUM","https://www.vi.nl/wedstrijden");addAction(list,"Eredivisie programma","https://eredivisie.nl/competitie/wedstrijden/");ScrollView s=new ScrollView(this);s.addView(list);root.addView(s,new LinearLayout.LayoutParams(-1,0,1));content.addView(root);}
    private void showCompetitions(){content.removeAllViews();LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.addView(sectionHeader("Competities"));LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);list.setPadding(dp(16),0,dp(16),dp(24));String[][] c={{"🇳🇱 Eredivisie","https://eredivisie.nl/"},{"🏆 Champions League","https://www.uefa.com/uefachampionsleague/"},{"🏴 Premier League","https://www.premierleague.com/"},{"🇪🇸 La Liga","https://www.laliga.com/"},{"🇮🇹 Serie A","https://www.legaseriea.it/"}};for(String[] x:c)addAction(list,x[0],x[1]);ScrollView s=new ScrollView(this);s.addView(list);root.addView(s,new LinearLayout.LayoutParams(-1,0,1));content.addView(root);}
    private void showFavorites() {
        content.removeAllViews();
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.addView(sectionHeader("Favorieten"));

        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(16), 0, dp(16), dp(24));

        Set<String> stored = prefs.getStringSet("clubs", Collections.<String>emptySet());
        Set<String> favs = new HashSet<>(stored);
        String heading = favs.isEmpty() ? "Nog geen favoriete clubs." : "Jouw clubs: " + join(favs, "  •  ");
        TextView h = tv(heading, 16, C.TEXT, true);
        h.setPadding(0, dp(16), 0, dp(18));
        list.addView(h);

        String[] clubs = {"FC Groningen", "Ajax", "PSV", "Feyenoord", "AZ"};
        for (final String club : clubs) {
            Button button = new Button(this);
            boolean favorite = favs.contains(club);
            button.setText((favorite ? "★ " : "☆ ") + club);
            button.setTextColor(favorite ? C.GREEN : C.TEXT);
            button.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    Set<String> current = new HashSet<>(prefs.getStringSet("clubs", Collections.<String>emptySet()));
                    if (current.contains(club)) {
                        current.remove(club);
                    } else {
                        current.add(club);
                    }
                    prefs.edit().putStringSet("clubs", current).apply();
                    showFavorites();
                }
            });
            list.addView(button, new LinearLayout.LayoutParams(-1, dp(52)));
        }

        ScrollView scroll = new ScrollView(this);
        scroll.addView(list);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        content.addView(root);
    }
    private String join(Set<String> s,String sep){StringBuilder b=new StringBuilder();for(String x:s){if(b.length()>0)b.append(sep);b.append(x);}return b.toString();}
    private void showMore(){content.removeAllViews();LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.addView(sectionHeader("Meer"));LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);list.setPadding(dp(16),0,dp(16),dp(24));addAction(list,"VI.nl openen","https://www.vi.nl/");addAction(list,"VoetbalPrimeur openen","https://www.voetbalprimeur.nl/");addAction(list,"Voetbalzone openen","https://www.voetbalzone.nl/");addAction(list,"Feedback sturen","mailto:voetbalhub.app@gmail.com?subject=VoetbalHub%20feedback");TextView info=tv("VoetbalHub 1.0\nEen onafhankelijke nieuwsverzamelaar. Artikelen blijven bij de oorspronkelijke uitgever.",12,C.MUTED,false);info.setPadding(0,dp(24),0,0);list.addView(info);ScrollView s=new ScrollView(this);s.addView(list);root.addView(s,new LinearLayout.LayoutParams(-1,0,1));content.addView(root);}
    private void addAction(LinearLayout list,String label,String url){TextView b=tv(label+"  ›",15,C.TEXT,false);b.setGravity(Gravity.CENTER_VERTICAL);b.setPadding(dp(18),0,dp(18),0);b.setBackground(ContextCompat.getDrawable(this,R.drawable.rounded_card));b.setOnClickListener(v->openUrl(url));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(58));lp.setMargins(0,0,0,dp(10));list.addView(b,lp);}
    private void showSearch(){EditText input=new EditText(this);input.setHint("Zoek speler, club of onderwerp");input.setSingleLine(true);input.setPadding(dp(16),0,dp(16),0);new AlertDialog.Builder(this).setTitle("Zoeken in VoetbalHub").setView(input).setNegativeButton("Annuleren",null).setPositiveButton("Zoeken",(d,w)->search(input.getText().toString().trim())).show();}
    private void search(String q){if(q.isEmpty())return;active="Voor jou";buildChips();content.removeAllViews();LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.addView(sectionHeader("Zoekresultaten"));LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);list.setPadding(dp(16),0,dp(16),dp(24));int count=0;for(Article a:articles){if(a.title.toLowerCase(Locale.ROOT).contains(q.toLowerCase(Locale.ROOT))){addArticleCard(list,a,false);if(++count>=30)break;}}if(count==0)list.addView(tv("Geen resultaten voor \""+q+"\".",15,C.MUTED,false));ScrollView s=new ScrollView(this);s.addView(list);root.addView(s,new LinearLayout.LayoutParams(-1,0,1));content.addView(root);}
    private void showSettings(){new AlertDialog.Builder(this).setTitle("VoetbalHub instellingen").setItems(new String[]{"Nieuws vernieuwen","Favorieten beheren","Bronnen bekijken","Over VoetbalHub"},(d,which)->{if(which==0)refreshNews();else if(which==1)showFavorites();else showMore();}).show();}
    private void openUrl(String url){try{startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));}catch(Exception ignored){}}
    @Override protected void onDestroy(){executor.shutdownNow();super.onDestroy();}
    private static final class C {static final int GREEN=0xFF25F06B;static final int TEXT=0xFFF6FAF7;static final int MUTED=0xFF8E9B95;static final int BG=0xFF050807;}
}
