plugins {
    id("com.android.application")
}

android {
    namespace = "nl.voetbalhub.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "nl.voetbalhub.app"
        minSdk = 24
        targetSdk = 35
        versionCode = 11
        versionName = "1.1"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
}
