# VoetbalHub v24 – compactere aftraptijden

Gebaseerd op v23. De aftraptijd/wedstrijdstatus boven de wedstrijdkaart is iets kleiner gemaakt met compactere padding, zodat de kaart rustiger oogt. De overige lay-out, scorefeed, clublogo's en Flashscore-link zijn behouden.

Build: GitHub Actions → Build VoetbalHub APK.
