# VoetbalHub 2.0

Professionele voetbalnieuws-app voor Android.

## Nieuw in 2.0
- Artikelen openen binnen de app via een ingebouwde WebView.
- RSS-artikelen tonen automatisch afbeeldingen wanneer de feed een afbeelding meegeeft.
- Grote hero-kaart voor het eerste nieuwsbericht.
- Compacte nieuwskaarten met afbeelding voor de overige berichten.
- In-app video- en wedstrijdpagina's.
- Delen van artikelen vanuit de ingebouwde leesomgeving.
- Donkere stadionstijl met groene accenten.

## Bronnen
VI, VoetbalPrimeur en Voetbalzone/Google News RSS-zoekfeed. Volledige artikelen blijven bij de oorspronkelijke uitgever.

## Build
De GitHub Actions-workflow bouwt `app-debug.apk` met Java 17 en Gradle 8.9.
