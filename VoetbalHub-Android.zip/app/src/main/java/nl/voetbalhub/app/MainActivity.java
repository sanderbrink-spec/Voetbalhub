package nl.voetbalhub.app;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private final ExecutorService executor = Executors.newFixedThreadPool(3);
    private final Handler main = new Handler(Looper.getMainLooper());
    private final List<Article> all = new ArrayList<>();
    private LinearLayout feed;
    private TextView status;
    private ProgressBar progress;
    private String filter = "Alles";
    private long lastRefresh;

    private static final FeedSource VI = new FeedSource("VI", "https://www.vi.nl/feed/news.xml");
    private static final FeedSource VP = new FeedSource("VP", "https://www.voetbalprimeur.nl/feed/news.xml");
    private static final FeedSource VZ = new FeedSource("VZ", "https://news.google.com/rss/search?q=site%3Avoetbalzone.nl%20voetbal&hl=nl&gl=NL&ceid=NL:nl");

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        buildUi();
        refresh();
        main.postDelayed(() -> refresh(), 10 * 60 * 1000L);
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(11,13,16));
        root.setPadding(dp(16), dp(10), dp(16), 0);

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView logo = text("VOETBALHUB", 24, Color.WHITE, true);
        header.addView(logo, new LinearLayout.LayoutParams(0, dp(52), 1));
        Button refresh = button("↻");
        refresh.setOnClickListener(v -> refresh());
        header.addView(refresh, new LinearLayout.LayoutParams(dp(52), dp(52)));
        root.addView(header);

        TextView sub = text("Het laatste voetbalnieuws op één plek", 13, Color.rgb(154,163,178), false);
        root.addView(sub);

        LinearLayout tabs = new LinearLayout(this);
        tabs.setPadding(0, dp(14), 0, dp(10));
        String[] names = {"Alles", "VI", "VP", "VZ", "Video"};
        for (String n : names) {
            Button b = button(n);
            b.setOnClickListener(v -> { filter = n; render(); });
            tabs.addView(b, new LinearLayout.LayoutParams(0, dp(42), 1));
        }
        root.addView(tabs);

        status = text("Verbinden...", 12, Color.rgb(154,163,178), false);
        root.addView(status);
        progress = new ProgressBar(this);
        progress.setVisibility(View.GONE);
        root.addView(progress, new LinearLayout.LayoutParams(-1, dp(4)));

        ScrollView scroll = new ScrollView(this);
        feed = new LinearLayout(this);
        feed.setOrientation(LinearLayout.VERTICAL);
        feed.setPadding(0, dp(8), 0, dp(24));
        scroll.addView(feed);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
    }

    private void refresh() {
        if (System.currentTimeMillis() - lastRefresh < 5000) return;
        lastRefresh = System.currentTimeMillis();
        progress.setVisibility(View.VISIBLE);
        status.setText("Nieuws wordt bijgewerkt...");
        executor.submit(() -> {
            List<Article> fresh = new ArrayList<>();
            fetch(VI, fresh); fetch(VP, fresh); fetch(VZ, fresh);
            fresh.sort(Comparator.comparingLong((Article a) -> a.time).reversed());
            main.post(() -> {
                all.clear(); all.addAll(fresh); progress.setVisibility(View.GONE); render();
                status.setText(all.isEmpty() ? "Geen nieuws beschikbaar" : "Laatst bijgewerkt: nu");
            });
        });
    }

    private void fetch(FeedSource source, List<Article> out) {
        HttpURLConnection c = null;
        try {
            URL url = new URL(source.url);
            c = (HttpURLConnection) url.openConnection();
            c.setConnectTimeout(10000); c.setReadTimeout(15000);
            c.setRequestProperty("User-Agent", "VoetbalHub/1.0 Android");
            if (c.getResponseCode() >= 400) return;
            try (InputStream in = c.getInputStream()) {
                XmlPullParser p = XmlPullParserFactory.newInstance().newPullParser();
                p.setInput(in, null);
                boolean item = false; String title = null, link = null, date = null; long time = 0;
                for (int e = p.getEventType(); e != XmlPullParser.END_DOCUMENT; e = p.next()) {
                    if (e == XmlPullParser.START_TAG) {
                        String n = p.getName();
                        if ("item".equalsIgnoreCase(n) || "entry".equalsIgnoreCase(n)) { item = true; title = link = date = null; time = 0; }
                        else if (item && "title".equalsIgnoreCase(n)) title = clean(p.nextText());
                        else if (item && "link".equalsIgnoreCase(n)) {
                            if ("entry".equalsIgnoreCase(p.getName())) { String href = p.getAttributeValue(null, "href"); if (href != null) link = href; }
                            else link = p.nextText();
                        }
                        else if (item && ("pubDate".equalsIgnoreCase(n) || "published".equalsIgnoreCase(n) || "updated".equalsIgnoreCase(n))) { date = p.nextText(); time = System.currentTimeMillis(); }
                    } else if (e == XmlPullParser.END_TAG && ("item".equalsIgnoreCase(p.getName()) || "entry".equalsIgnoreCase(p.getName()))) {
                        if (title != null && link != null) out.add(new Article(source.name, title, link.trim(), time == 0 ? System.currentTimeMillis() : time));
                        item = false;
                    }
                }
            }
        } catch (Exception ignored) { }
        finally { if (c != null) c.disconnect(); }
    }

    private void render() {
        feed.removeAllViews();
        if ("Video".equals(filter)) { renderVideos(); return; }
        int count = 0;
        for (Article a : all) {
            if (!"Alles".equals(filter) && !filter.equals(a.source)) continue;
            feed.addView(card(a)); count++; if (count >= 80) break;
        }
        if (count == 0) {
            TextView empty = text("Nog geen nieuws. Tik op ↻ om opnieuw te proberen.", 15, Color.WHITE, false);
            feed.addView(empty, new LinearLayout.LayoutParams(-1, dp(80)));
        }
    }

    private void renderVideos() {
        addVideo("VI TV", "Nieuws, analyses en voetbalshows van VI", "https://www.vi.nl/pagina/vi-fast-kanaal");
        addVideo("VoetbalPrimeur Video", "Interviews, transfers en voetbalvideo's", "https://www.voetbalprimeur.nl/videos");
        addVideo("VoetbalZone Video", "Video's en voetbalnieuws van VoetbalZone", "https://www.voetbalzone.nl/videos");
    }

    private void addVideo(String title, String desc, String url) {
        TextView t = text("▶  " + title + "\n" + desc, 16, Color.WHITE, true);
        t.setBackgroundResource(nl.voetbalhub.app.R.drawable.card);
        t.setPadding(dp(16), dp(16), dp(16), dp(16));
        t.setOnClickListener(v -> openWeb(url));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(86)); lp.setMargins(0,0,0,dp(10)); feed.addView(t, lp);
    }

    private View card(Article a) {
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setBackgroundResource(R.drawable.card);
        TextView source = text(a.source, 11, Color.rgb(255,107,95), true); box.addView(source);
        TextView title = text(a.title, 17, Color.WHITE, true); title.setPadding(0,dp(5),0,dp(5)); box.addView(title);
        TextView hint = text("Lees verder bij " + a.source + "  ›", 12, Color.rgb(154,163,178), false); box.addView(hint);
        box.setOnClickListener(v -> openWeb(a.url));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT); lp.setMargins(0,0,0,dp(10)); box.setPadding(dp(16),dp(14),dp(16),dp(14)); return box;
    }

    private void openWeb(String url) {
        WebView w = new WebView(this); w.setBackgroundColor(Color.rgb(11,13,16));
        WebSettings s = w.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setMediaPlaybackRequiresUserGesture(false);
        w.setWebViewClient(new WebViewClient()); w.loadUrl(url);
        setContentView(w);
    }

    private Button button(String label) { Button b = new Button(this); b.setText(label); b.setTextColor(Color.WHITE); b.setTextSize(12); b.setAllCaps(false); b.setBackgroundColor(Color.TRANSPARENT); return b; }
    private TextView text(String s, int size, int color, boolean bold) { TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); return t; }
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    private String clean(String s) { return s == null ? "" : s.replace("&amp;", "&").replace("&quot;", "\"").trim(); }
    @Override protected void onDestroy() { executor.shutdownNow(); super.onDestroy(); }

    static class FeedSource { final String name,url; FeedSource(String n,String u){name=n;url=u;} }
    static class Article { final String source,title,url; final long time; Article(String s,String t,String u,long tm){source=s;title=t;url=u;time=tm;} }
}
