# VoetbalHub

Een online Android voetbalnieuws-app die headlines bundelt uit VI, VoetbalPrimeur en Voetbalzone. De app haalt RSS-items automatisch op en opent het volledige artikel bij de oorspronkelijke bron.

## GitHub APK build
1. Upload **de inhoud van deze map** naar de hoofdmap van een nieuwe GitHub repository.
2. Ga naar **Actions**.
3. Kies **Build APK**.
4. Kies **Run workflow**.
5. Download het artifact **VoetbalHub-APK**.

Er is bewust geen `gradlew` nodig. GitHub Actions installeert Gradle 8.7 zelf.
