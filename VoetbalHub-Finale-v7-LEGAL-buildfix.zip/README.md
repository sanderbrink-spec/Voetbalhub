# VoetbalHub 2.2

Juridisch veiligere aggregator-opzet voor een voetbalnieuwsapp.

- Per bericht toont de app alleen titel, bron, datum en een link.
- Volledige artikelen en afbeeldingen worden niet uit de feeds gekopieerd naar de app.
- Het originele artikel wordt in de ingebouwde WebView bij de oorspronkelijke uitgever geopend.
- De app claimt geen officiële samenwerking met VI, VoetbalPrimeur of Voetbalzone.
- De app bevat een pagina met bronnen en auteursrechtelijke uitleg.

## Google Play / release
De GitHub Actions-workflow bouwt naast een debug-APK ook een release-AAB. Als de vier signing secrets zijn ingesteld, wordt de AAB met jouw upload-key ondertekend. Zonder secrets wordt een unsigned release-AAB gebouwd, die nog niet rechtstreeks naar Google Play kan worden geüpload.

Benodigde GitHub Secrets:
- `ANDROID_KEYSTORE_BASE64`
- `ANDROID_KEYSTORE_PASSWORD`
- `ANDROID_KEY_ALIAS`
- `ANDROID_KEY_PASSWORD`

Voor Google Play moet daarnaast de News & Magazine-declaratie worden ingevuld en moet actuele contactinformatie via een URL beschikbaar zijn. Dit project is geen juridische garantie; gebruik van feeds moet ook passen binnen de voorwaarden van de betreffende uitgevers.
