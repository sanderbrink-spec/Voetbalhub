# VoetbalHub v23 — aftraptijden zichtbaar

Deze versie behoudt de bestaande VoetbalHub-opmaak en toont bij geplande wedstrijden de aftraptijd centraal op de wedstrijdkaart in Nederlandse tijd (Europe/Amsterdam). De tijdparser ondersteunt ISO-instanten, tijdstempels met offset en lokale ISO-datum/tijd. Als de feed geen geldige tijd aanlevert, wordt expliciet `AFTRAPTIJD ONBEKEND` getoond in plaats van een misleidend `PROGRAMMA`-label.

Versie: 3.1. Bouw via de bestaande GitHub Actions-workflow. De APK-build en live feed moeten na upload via GitHub Actions en op een Android-toestel worden gecontroleerd.
