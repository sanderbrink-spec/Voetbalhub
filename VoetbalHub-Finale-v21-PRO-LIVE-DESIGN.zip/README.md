# VoetbalHub v21 — PRO LIVE UI

Versie 2.9. Professionelere livewedstrijdkaarten in de bestaande zwart-groene VoetbalHub-stijl.

## Verbeteringen
- Duidelijke LIVE-/wedstrijdstatus bovenaan de kaart.
- Grotere score in het midden, clubs aan weerszijden.
- Compacte clubinitialen-badges in plaats van verzonnen logo's.
- Wedstrijden die nog moeten beginnen tonen geen misleidende 0-0; score blijft een streepje.
- Bestaande scorefeed en Flashscore-ingang behouden.

De live data wordt opgehaald uit de bestaande ESPN scoreboard-feed. Beschikbaarheid en volledigheid kunnen per wedstrijd/dag verschillen. De app moet na het bouwen op een toestel getest worden.

## Build
Gebruik de bestaande GitHub Actions-workflow: Actions → Build VoetbalHub APK.
